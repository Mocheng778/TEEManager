.class public Lair;
.super Ljava/lang/Object;


# instance fields
.field private a:Lami;

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lami;
    .locals 1

    iget-object v0, p0, Lair;->a:Lami;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lair;->b:I

    return-void
.end method

.method public a(Lami;)V
    .locals 0

    iput-object p1, p0, Lair;->a:Lami;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lair;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lair;->c:I

    return-void
.end method
