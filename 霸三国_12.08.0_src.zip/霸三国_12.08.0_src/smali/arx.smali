.class public Larx;
.super Lasc;


# direct methods
.method public constructor <init>(Laqs;DD[Lbyq;)V
    .locals 1

    invoke-direct {p0, p1, p6}, Lasc;-><init>(Laqs;[Lbyq;)V

    invoke-virtual {p0, p2, p3, p4, p5}, Larx;->a(DD)I

    move-result v0

    invoke-virtual {p1, v0}, Laqs;->a(I)V

    invoke-virtual {p0}, Larx;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->b()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-virtual {p0}, Larx;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Larx;->b()Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->s()V

    :cond_0
    return-void
.end method
