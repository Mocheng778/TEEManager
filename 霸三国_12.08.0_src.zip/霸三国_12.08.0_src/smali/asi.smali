.class Lasi;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lapr;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:Lash;


# direct methods
.method constructor <init>(Lash;Ljava/lang/String;Ljava/lang/String;Lapr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lasi;->h:Lash;

    iput-object p2, p0, Lasi;->a:Ljava/lang/String;

    iput-object p3, p0, Lasi;->b:Ljava/lang/String;

    iput-object p4, p0, Lasi;->c:Lapr;

    iput-object p5, p0, Lasi;->d:Ljava/lang/String;

    iput-object p6, p0, Lasi;->e:Ljava/lang/String;

    iput-object p7, p0, Lasi;->f:Ljava/lang/String;

    iput-object p8, p0, Lasi;->g:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u653b\u65b9"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lasi;->a:Ljava/lang/String;

    :goto_0
    return-object v0

    :cond_0
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u73a9\u5bb6\u540d"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lasi;->h:Lash;

    invoke-static {v0}, Lash;->a(Lash;)Laqi;

    move-result-object v0

    invoke-virtual {v0}, Laqi;->b()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u5c06\u9886\u540d"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lasi;->h:Lash;

    invoke-static {v0}, Lash;->a(Lash;)Laqi;

    move-result-object v0

    invoke-virtual {v0}, Laqi;->c()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u7b49\u7ea7"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lasi;->b:Ljava/lang/String;

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u5175\u79cd"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lasi;->c:Lapr;

    invoke-virtual {v0}, Lapr;->c()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_4
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u6570\u91cf"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lasi;->d:Ljava/lang/String;

    goto :goto_0

    :cond_5
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u4f24\u4ea1"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lasi;->e:Ljava/lang/String;

    goto :goto_0

    :cond_6
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u6740\u654c"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, p0, Lasi;->f:Ljava/lang/String;

    goto :goto_0

    :cond_7
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u7ecf\u9a8c"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, p0, Lasi;->g:Ljava/lang/String;

    goto/16 :goto_0

    :cond_8
    const/4 v0, 0x0

    goto/16 :goto_0
.end method
