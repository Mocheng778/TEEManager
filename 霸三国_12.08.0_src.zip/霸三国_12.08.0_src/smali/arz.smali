.class public Larz;
.super Larx;


# instance fields
.field private b:Laqp;

.field private c:D

.field private d:D


# direct methods
.method public constructor <init>(Laqq;DD[Lbyq;Laqp;)V
    .locals 0

    invoke-direct/range {p0 .. p6}, Larx;-><init>(Laqs;DD[Lbyq;)V

    iput-object p7, p0, Larz;->b:Laqp;

    iput-wide p2, p0, Larz;->c:D

    iput-wide p4, p0, Larz;->d:D

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    invoke-virtual {p0}, Larz;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Larz;->b:Laqp;

    invoke-virtual {p0}, Larz;->b()Laqs;

    move-result-object v1

    check-cast v1, Laqq;

    iget-wide v2, p0, Larz;->c:D

    iget-wide v4, p0, Larz;->d:D

    invoke-virtual/range {v0 .. v5}, Laqp;->a(Laqq;DD)V

    invoke-virtual {p0}, Larz;->b()Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->s()V

    :cond_0
    return-void
.end method
