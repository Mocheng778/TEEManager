.class public Lask;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/battle/view/BattleStationJoinView;


# direct methods
.method public constructor <init>(Lcom/lszb/battle/view/BattleStationJoinView;)V
    .locals 0

    iput-object p1, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public e(Laej;)V
    .locals 3

    iget-object v0, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v1}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    const-class v1, Lcom/lszb/map/view/MapView;

    invoke-virtual {v0, v1}, Laok;->b(Ljava/lang/Class;)Laoj;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v1}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1, v0}, Laok;->c(Laoj;)V

    :goto_0
    iget-object v0, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-static {v2}, Lcom/lszb/battle/view/BattleStationJoinView;->a(Lcom/lszb/battle/view/BattleStationJoinView;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_1
    return-void

    :cond_0
    iget-object v0, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    const-class v1, Lcom/lszb/building/view/FieldView;

    invoke-virtual {v0, v1}, Laok;->c(Ljava/lang/Class;)V

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lask;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_1
.end method
