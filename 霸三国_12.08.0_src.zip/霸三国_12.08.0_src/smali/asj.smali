.class public interface abstract Lasj;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lajt;)V
.end method

.method public abstract b(Lajt;)V
.end method
