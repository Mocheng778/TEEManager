.class public Lafc;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:J

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:J

.field private f:Ljava/lang/String;

.field private g:Z

.field private h:[Lalx;

.field private i:[Lalb;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()J
    .locals 2

    iget-wide v0, p0, Lafc;->a:J

    return-wide v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafc;->b:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lafc;->a:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lafc;->d:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lafc;->g:Z

    return-void
.end method

.method public a([Lalb;)V
    .locals 0

    iput-object p1, p0, Lafc;->i:[Lalb;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lafc;->h:[Lalx;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafc;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafc;->c:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lafc;->e:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lafc;->f:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lafc;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Lafc;->e:J

    return-wide v0
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lafc;->f:Ljava/lang/String;

    return-object v0
.end method

.method public f()Z
    .locals 1

    iget-boolean v0, p0, Lafc;->g:Z

    return v0
.end method

.method public g()[Lalx;
    .locals 1

    iget-object v0, p0, Lafc;->h:[Lalx;

    return-object v0
.end method

.method public h()[Lalb;
    .locals 1

    iget-object v0, p0, Lafc;->i:[Lalb;

    return-object v0
.end method
