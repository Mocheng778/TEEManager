.class public abstract Lare;
.super Laqh;

# interfaces
.implements Lbzf;


# instance fields
.field private a:D

.field private b:D

.field private c:D

.field private d:D

.field private e:D

.field private f:D

.field private g:Lbzf;

.field private h:Lbzf;

.field private i:Lbyw;

.field private j:Lbze;

.field private k:I

.field private l:I

.field private m:I

.field private n:I


# direct methods
.method public constructor <init>(Lbze;II)V
    .locals 1

    const/4 v0, -0x1

    invoke-direct {p0}, Laqh;-><init>()V

    iput v0, p0, Lare;->m:I

    iput v0, p0, Lare;->n:I

    iput-object p1, p0, Lare;->j:Lbze;

    iput p2, p0, Lare;->n:I

    iput p3, p0, Lare;->m:I

    return-void
.end method

.method private a(DD)D
    .locals 2

    mul-double v0, p1, p3

    return-wide v0
.end method

.method private c(DDD)D
    .locals 6

    mul-double v0, p1, p5

    mul-double v2, p3, p5

    mul-double/2addr v2, p5

    const-wide/high16 v4, 0x4000000000000000L    # 2.0

    div-double/2addr v2, v4

    add-double/2addr v0, v2

    return-wide v0
.end method


# virtual methods
.method public a(Lbyw;DDDDDI)V
    .locals 8

    iput-object p1, p0, Lare;->i:Lbyw;

    move-wide/from16 v0, p8

    iput-wide v0, p0, Lare;->a:D

    move-wide/from16 v0, p10

    iput-wide v0, p0, Lare;->b:D

    neg-double v2, p6

    move/from16 v0, p12

    int-to-double v4, v0

    div-double/2addr v2, v4

    const-wide/high16 v4, -0x4020000000000000L    # -0.5

    move/from16 v0, p12

    int-to-double v6, v0

    mul-double/2addr v4, v6

    const-wide/high16 v6, 0x4000000000000000L    # 2.0

    div-double/2addr v4, v6

    sub-double/2addr v2, v4

    iput-wide v2, p0, Lare;->c:D

    move/from16 v0, p12

    iput v0, p0, Lare;->k:I

    const/4 v2, 0x0

    iput v2, p0, Lare;->l:I

    iput-wide p2, p0, Lare;->d:D

    iput-wide p4, p0, Lare;->e:D

    iput-wide p6, p0, Lare;->f:D

    invoke-virtual {p0, p2, p3}, Lare;->a(D)V

    invoke-virtual {p0, p4, p5}, Lare;->b(D)V

    invoke-virtual {p0, p6, p7}, Lare;->c(D)V

    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lbyq;->b()V

    :cond_0
    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v2

    iget v3, p0, Lare;->n:I

    invoke-virtual {v2, v3}, Lbmh;->b(I)V

    return-void
.end method

.method public a(Lbzf;)V
    .locals 0

    iput-object p1, p0, Lare;->g:Lbzf;

    return-void
.end method

.method public a(Lcar;II)V
    .locals 2

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->e()I

    move-result v0

    :goto_0
    if-eqz v1, :cond_0

    invoke-virtual {v1, p1, p2, p3, v0}, Lbyq;->a(Lcar;III)V

    :cond_0
    return-void

    :cond_1
    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->g()I

    move-result v0

    goto :goto_0
.end method

.method public b(Lbzf;)V
    .locals 0

    iput-object p1, p0, Lare;->h:Lbzf;

    return-void
.end method

.method protected abstract d()Lbyq;
.end method

.method protected abstract e()I
.end method

.method protected abstract f()Lbyq;
.end method

.method protected abstract g()I
.end method

.method protected h()D
    .locals 12

    const-wide/16 v10, 0x0

    iget-wide v0, p0, Lare;->a:D

    iget-wide v2, p0, Lare;->b:D

    iget-wide v4, p0, Lare;->c:D

    invoke-static/range {v0 .. v5}, Lare;->a(DDD)I

    move-result v0

    int-to-double v8, v0

    iget-wide v0, p0, Lare;->a:D

    iget-wide v2, p0, Lare;->b:D

    iget-wide v4, p0, Lare;->c:D

    invoke-static/range {v0 .. v5}, Lare;->b(DDD)I

    move-result v0

    int-to-double v6, v0

    move-wide v0, v10

    move-wide v2, v10

    move-wide v4, v8

    invoke-static/range {v0 .. v7}, Lbyz;->b(DDDD)D

    move-result-wide v0

    return-wide v0
.end method

.method public i()Lbzf;
    .locals 1

    iget-object v0, p0, Lare;->g:Lbzf;

    return-object v0
.end method

.method public j()Lbzf;
    .locals 1

    iget-object v0, p0, Lare;->h:Lbzf;

    return-object v0
.end method

.method public o()V
    .locals 9

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ne v0, v1, :cond_2

    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v0

    if-eqz v0, :cond_0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    iget-object v0, p0, Lare;->j:Lbze;

    invoke-virtual {v0, p0}, Lbze;->a(Lbzf;)V

    iget-object v0, p0, Lare;->i:Lbyw;

    invoke-virtual {v0, p0}, Lbyw;->b(Lbyx;)V

    :cond_1
    :goto_0
    return-void

    :cond_2
    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Lbyq;->b()V

    :cond_3
    iget v0, p0, Lare;->l:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lare;->l:I

    iget-wide v0, p0, Lare;->d:D

    iget-wide v2, p0, Lare;->a:D

    iget v4, p0, Lare;->l:I

    int-to-double v4, v4

    invoke-direct {p0, v2, v3, v4, v5}, Lare;->a(DD)D

    move-result-wide v2

    add-double/2addr v0, v2

    invoke-virtual {p0, v0, v1}, Lare;->a(D)V

    iget-wide v0, p0, Lare;->e:D

    iget-wide v2, p0, Lare;->b:D

    iget v4, p0, Lare;->l:I

    int-to-double v4, v4

    invoke-direct {p0, v2, v3, v4, v5}, Lare;->a(DD)D

    move-result-wide v2

    add-double/2addr v0, v2

    invoke-virtual {p0, v0, v1}, Lare;->b(D)V

    iget-wide v7, p0, Lare;->f:D

    iget-wide v1, p0, Lare;->c:D

    const-wide/high16 v3, -0x4020000000000000L    # -0.5

    iget v0, p0, Lare;->l:I

    int-to-double v5, v0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lare;->c(DDD)D

    move-result-wide v0

    add-double/2addr v0, v7

    invoke-virtual {p0, v0, v1}, Lare;->c(D)V

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ne v0, v1, :cond_1

    iget v0, p0, Lare;->m:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v0

    iget v1, p0, Lare;->m:I

    invoke-virtual {v0, v1}, Lbmh;->b(I)V

    goto :goto_0
.end method

.method public t()I
    .locals 2

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ge v0, v1, :cond_0

    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->e()I

    move-result v0

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Lbyq;->a(I)I

    move-result v0

    :goto_1
    return v0

    :cond_0
    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->g()I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1
.end method

.method public u()I
    .locals 2

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ge v0, v1, :cond_0

    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->e()I

    move-result v0

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Lbyq;->b(I)I

    move-result v0

    :goto_1
    return v0

    :cond_0
    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->g()I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1
.end method

.method public v()I
    .locals 2

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ge v0, v1, :cond_0

    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->e()I

    move-result v0

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Lbyq;->d(I)I

    move-result v0

    :goto_1
    return v0

    :cond_0
    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->g()I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1
.end method

.method public w()I
    .locals 2

    iget v0, p0, Lare;->l:I

    iget v1, p0, Lare;->k:I

    if-ge v0, v1, :cond_0

    invoke-virtual {p0}, Lare;->d()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->e()I

    move-result v0

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1, v0}, Lbyq;->c(I)I

    move-result v0

    :goto_1
    return v0

    :cond_0
    invoke-virtual {p0}, Lare;->f()Lbyq;

    move-result-object v1

    invoke-virtual {p0}, Lare;->g()I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1
.end method
