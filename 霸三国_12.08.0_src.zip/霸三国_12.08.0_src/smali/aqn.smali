.class public Laqn;
.super Ljava/lang/Object;


# static fields
.field private static b:Laqn;


# instance fields
.field public a:I

.field private c:Laok;

.field private d:Laoj;

.field private e:Lbzg;

.field private f:[Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Laqn;->a:I

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "ui-battle.properties"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf-8"

    invoke-static {v0, v1}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    iput-object v0, p0, Laqn;->e:Lbzg;

    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v1, "battle_situation.\u6807\u7b7e\u5217\u8868"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ","

    invoke-static {v0, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laqn;->f:[Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public static a()Laqn;
    .locals 1

    sget-object v0, Laqn;->b:Laqn;

    if-nez v0, :cond_0

    new-instance v0, Laqn;

    invoke-direct {v0}, Laqn;-><init>()V

    sput-object v0, Laqn;->b:Laqn;

    :cond_0
    sget-object v0, Laqn;->b:Laqn;

    return-object v0
.end method


# virtual methods
.method public a(Lajt;)Ljava/lang/String;
    .locals 6

    const-string v0, ""

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lajt;->e()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Lajt;->b()Laks;

    move-result-object v1

    invoke-virtual {p1}, Lajt;->d()Laju;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Laju;->a()Laks;

    move-result-object v4

    if-eqz v4, :cond_2

    invoke-virtual {v3}, Laju;->a()Laks;

    move-result-object v3

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    invoke-virtual {v3}, Laks;->d()I

    move-result v4

    invoke-virtual {v0, v4}, Latt;->d(I)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v4, "\u6211\u7684\u5c01\u5730\u88ab\u63a0\u593a"

    invoke-virtual {v0, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    const-string v4, "${startName}"

    invoke-static {v0, v4, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "${form}"

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v4

    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-virtual {v4, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${ownName}"

    invoke-virtual {v3}, Laks;->g()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${target}"

    invoke-virtual {v3}, Laks;->e()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    :goto_1
    return-object v0

    :cond_1
    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v4, "\u6211\u7684\u5c01\u5730\u88ab\u63a0\u593a"

    invoke-virtual {v0, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    invoke-virtual {v3}, Laju;->b()Lamx;

    move-result-object v4

    if-eqz v4, :cond_5

    invoke-virtual {v3}, Laju;->b()Lamx;

    move-result-object v3

    invoke-virtual {v3}, Lamx;->c()I

    move-result v0

    invoke-static {}, Latt;->a()Latt;

    move-result-object v4

    invoke-virtual {v4, v0}, Latt;->c(I)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v4, "\u6211\u7684\u57ce\u6c60\u88ab\u653b\u51fb"

    invoke-virtual {v0, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-static {}, Lbku;->a()Lbku;

    move-result-object v4

    invoke-virtual {v4}, Lbku;->b()Z

    move-result v4

    if-eqz v4, :cond_3

    add-int/lit16 v1, v1, -0x499

    :cond_3
    const-string v4, "${startName}"

    invoke-static {v0, v4, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "${form}"

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v4

    invoke-virtual {v4, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${target}"

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v2

    invoke-virtual {v3}, Lamx;->c()I

    move-result v3

    invoke-virtual {v2, v3}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_4
    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v4, "\u4ed6\u4eba\u57ce\u6c60\u88ab\u653b\u51fb"

    invoke-virtual {v0, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_5
    invoke-virtual {v3}, Laju;->c()Lamy;

    move-result-object v4

    if-eqz v4, :cond_6

    invoke-virtual {v3}, Laju;->c()Lamy;

    move-result-object v0

    iget-object v3, p0, Laqn;->e:Lbzg;

    const-string v4, "\u91ce\u5730\u63a0\u593a"

    invoke-virtual {v3, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "${startName}"

    invoke-static {v3, v4, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "${form}"

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v4

    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-virtual {v4, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v3, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "${target}"

    invoke-static {}, Lazo;->a()Lazo;

    move-result-object v3

    invoke-virtual {v0}, Lamy;->a()I

    move-result v0

    invoke-virtual {v3, v0}, Lazo;->b(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_6
    invoke-virtual {v3}, Laju;->d()Lajs;

    move-result-object v4

    if-eqz v4, :cond_8

    invoke-virtual {v3}, Laju;->d()Lajs;

    move-result-object v3

    invoke-virtual {v3}, Lajs;->b()Lams;

    move-result-object v4

    invoke-virtual {v3}, Lajs;->a()Lamy;

    move-result-object v3

    if-eqz v4, :cond_0

    invoke-virtual {v4}, Lams;->a()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_7

    const-string v0, ""

    invoke-virtual {v4}, Lams;->a()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u3010\u5360\u9886\u3011"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "("

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v2

    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-virtual {v2, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")\u5bf9"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lazo;->a()Lazo;

    move-result-object v1

    invoke-virtual {v3}, Lamy;->a()I

    move-result v2

    invoke-virtual {v1, v2}, Lazo;->b(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v4}, Lams;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u53d1\u8d77\u4e86\u5360\u9886"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u3010\u5360\u9886\u3011"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "("

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v2

    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-virtual {v2, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")\u5bf9"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lazo;->a()Lazo;

    move-result-object v1

    invoke-virtual {v3}, Lamy;->a()I

    move-result v2

    invoke-virtual {v1, v2}, Lazo;->b(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u53d1\u8d77\u4e86\u5360\u9886"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1

    :cond_8
    invoke-virtual {v3}, Laju;->e()Lanc;

    move-result-object v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Laju;->e()Lanc;

    move-result-object v0

    invoke-static {}, Lbuw;->a()Lbuw;

    move-result-object v3

    invoke-virtual {v0}, Lanc;->a()I

    move-result v0

    invoke-virtual {v3, v0}, Lbuw;->a(I)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u3010\u626b\u8361\u3011"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v3

    invoke-virtual {v1}, Laks;->c()I

    move-result v1

    invoke-virtual {v3, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")\u5bf9"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u53d1\u8d77\u4e86\u626b\u8361"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_1
.end method

.method public a(Lald;)Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Laqn;->e:Lbzg;

    const-string v1, "\u519b\u56e2\u6218"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${attack.legion}"

    invoke-virtual {p1}, Lald;->e()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${defend.legion}"

    invoke-virtual {p1}, Lald;->f()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a(Laln;)Ljava/lang/String;
    .locals 5

    const/4 v0, 0x0

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Laln;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Laln;->d()Laju;

    move-result-object v1

    if-eqz v1, :cond_7

    invoke-virtual {v1}, Laju;->a()Laks;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v1}, Laju;->a()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Laks;->g()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-virtual {p1}, Laln;->g()I

    move-result v2

    const/4 v4, 0x2

    if-ne v2, v4, :cond_2

    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u9a7b\u624e"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_1
    const-string v4, "${startName}"

    invoke-static {v2, v4, v3}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "${target}"

    invoke-static {v2, v3, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v0, :cond_8

    const-string v2, "${ownName}"

    invoke-static {v1, v2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_2
    return-object v0

    :cond_0
    invoke-virtual {v1}, Laju;->b()Lamx;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Laju;->b()Lamx;

    move-result-object v1

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v2

    invoke-virtual {v1}, Lamx;->c()I

    move-result v1

    invoke-virtual {v2, v1}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Laju;->c()Lamy;

    move-result-object v2

    if-eqz v2, :cond_9

    invoke-virtual {v1}, Laju;->c()Lamy;

    move-result-object v1

    invoke-static {}, Lazo;->a()Lazo;

    move-result-object v2

    invoke-virtual {v1}, Lamy;->a()I

    move-result v1

    invoke-virtual {v2, v1}, Lazo;->b(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, Laln;->g()I

    move-result v2

    const/4 v4, 0x1

    if-ne v2, v4, :cond_3

    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u6d3e\u9063"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_3
    invoke-virtual {p1}, Laln;->g()I

    move-result v2

    const/4 v4, 0x4

    if-ne v2, v4, :cond_5

    if-eqz v0, :cond_4

    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u5c01\u5730\u53ec\u56de"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_4
    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u53ec\u56de"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_5
    if-eqz v0, :cond_6

    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u5c01\u5730\u53c2\u6218"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_6
    iget-object v2, p0, Laqn;->e:Lbzg;

    const-string v4, "\u53c2\u6218"

    invoke-virtual {v2, v4}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_1

    :cond_7
    const-string v0, ""

    goto :goto_2

    :cond_8
    move-object v0, v1

    goto :goto_2

    :cond_9
    move-object v1, v0

    goto/16 :goto_0
.end method

.method public a(Laok;I)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0, p2}, Laqn;->a(Laok;Laoj;I)V

    return-void
.end method

.method public a(Laok;Laoj;I)V
    .locals 4

    iput-object p1, p0, Laqn;->c:Laok;

    iput-object p2, p0, Laqn;->d:Laoj;

    iput p3, p0, Laqn;->a:I

    if-eqz p2, :cond_0

    invoke-virtual {p1, p2}, Laok;->b(Laoj;)V

    :cond_0
    packed-switch p3, :pswitch_data_0

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Laqn;->c:Laok;

    new-instance v1, Lcom/lszb/battle/view/SituationView;

    invoke-direct {v1}, Lcom/lszb/battle/view/SituationView;-><init>()V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :pswitch_1
    iget-object v0, p0, Laqn;->c:Laok;

    new-instance v1, Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {}, Laql;->a()Laql;

    move-result-object v2

    invoke-virtual {v2}, Laql;->e()[Laln;

    move-result-object v2

    iget-object v3, p0, Laqn;->e:Lbzg;

    invoke-direct {v1, v2, v3}, Lcom/lszb/battle/view/ArmyDefendedView;-><init>([Laln;Lbzg;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public b()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqn;->f:[Ljava/lang/String;

    return-object v0
.end method
