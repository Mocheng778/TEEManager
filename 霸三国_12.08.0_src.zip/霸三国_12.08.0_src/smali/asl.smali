.class public Lasl;
.super Lbwj;


# instance fields
.field final synthetic a:Lcom/lszb/battle/view/BattleStationJoinView;


# direct methods
.method public constructor <init>(Lcom/lszb/battle/view/BattleStationJoinView;)V
    .locals 0

    iput-object p1, p0, Lasl;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-direct {p0}, Lbwj;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lasl;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-static {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->b(Lcom/lszb/battle/view/BattleStationJoinView;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a(Lcom/lszb/view/ConfirmDialogView;)V
    .locals 3

    invoke-static {}, Lbtl;->a()Lbtl;

    move-result-object v0

    invoke-virtual {v0}, Lbtl;->c()Lamq;

    move-result-object v0

    invoke-virtual {v0}, Lamq;->e()I

    move-result v0

    invoke-static {}, Laql;->a()Laql;

    move-result-object v1

    invoke-virtual {v1}, Laql;->k()Lajy;

    move-result-object v1

    invoke-virtual {v1}, Lajy;->b()I

    move-result v1

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lasl;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-static {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->c(Lcom/lszb/battle/view/BattleStationJoinView;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lasl;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/BattleStationJoinView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lasl;->a:Lcom/lszb/battle/view/BattleStationJoinView;

    invoke-static {v2}, Lcom/lszb/battle/view/BattleStationJoinView;->d(Lcom/lszb/battle/view/BattleStationJoinView;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method
