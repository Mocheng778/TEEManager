.class public Lafr;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lamu;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lamu;)V
    .locals 0

    iput-object p1, p0, Lafr;->a:[Lamu;

    return-void
.end method

.method public a()[Lamu;
    .locals 1

    iget-object v0, p0, Lafr;->a:[Lamu;

    return-object v0
.end method
