.class public Laqt;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lbyr;Ljava/util/Hashtable;Laqg;Laqo;Ljava/lang/String;)Laqs;
    .locals 17

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v3, 0x0

    const-string v2, "_"

    move-object/from16 v0, p4

    invoke-static {v0, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    const/4 v2, 0x0

    move/from16 v16, v2

    move v2, v3

    move v3, v4

    move/from16 v4, v16

    :goto_0
    :try_start_0
    array-length v11, v10

    if-ge v4, v11, :cond_0

    packed-switch v4, :pswitch_data_0

    :goto_1
    :pswitch_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :pswitch_1
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    goto :goto_1

    :pswitch_2
    aget-object v6, v10, v4

    goto :goto_1

    :pswitch_3
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    goto :goto_1

    :pswitch_4
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    goto :goto_1

    :pswitch_5
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    goto :goto_1

    :pswitch_6
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    goto :goto_1

    :pswitch_7
    aget-object v11, v10, v4

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v2

    goto :goto_1

    :catch_0
    move-exception v4

    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v4

    invoke-virtual {v4, v3}, Laqj;->a(I)[[Ljava/lang/String;

    move-result-object v12

    array-length v4, v12

    new-array v10, v4, [[Lbyq;

    const/4 v4, 0x0

    :goto_2
    array-length v11, v10

    if-ge v4, v11, :cond_3

    aget-object v11, v12, v4

    array-length v11, v11

    new-array v11, v11, [Lbyq;

    aput-object v11, v10, v4

    const/4 v11, 0x0

    :goto_3
    aget-object v13, v10, v4

    array-length v13, v13

    if-ge v11, v13, :cond_2

    aget-object v13, v12, v4

    aget-object v13, v13, v11

    if-eqz v13, :cond_1

    aget-object v13, v12, v4

    aget-object v13, v13, v11

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v13

    if-lez v13, :cond_1

    aget-object v13, v10, v4

    new-instance v14, Lbyq;

    aget-object v15, v12, v4

    aget-object v15, v15, v11

    move-object/from16 v0, p0

    invoke-virtual {v0, v15}, Lbyr;->b(Ljava/lang/String;)I

    move-result v15

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v14, v15, v0, v1}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    aput-object v14, v13, v11

    aget-object v13, v10, v4

    aget-object v13, v13, v11

    move-object/from16 v0, p1

    invoke-static {v13, v0}, Lbvy;->a(Lbyq;Ljava/util/Hashtable;)V

    :cond_1
    add-int/lit8 v11, v11, 0x1

    goto :goto_3

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_3
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v4

    invoke-virtual {v4, v2}, Laqj;->b(I)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_4

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lbyr;->b(Ljava/lang/String;)I

    move-result v4

    const/4 v11, -0x1

    if-eq v4, v11, :cond_4

    new-instance v11, Lbyq;

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lbyr;->b(Ljava/lang/String;)I

    move-result v2

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v11, v2, v0, v1}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    move-object/from16 v0, p1

    invoke-static {v11, v0}, Lbvy;->a(Lbyq;Ljava/util/Hashtable;)V

    :goto_4
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, v3}, Laqj;->c(I)I

    move-result v2

    move-object/from16 v0, p2

    invoke-virtual {v0, v5, v2}, Laqg;->a(II)Laqr;

    move-result-object v13

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, v3}, Laqj;->d(I)I

    move-result v2

    move-object/from16 v0, p2

    invoke-virtual {v0, v5, v2}, Laqg;->a(II)Laqr;

    move-result-object v12

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, v3}, Laqj;->e(I)I

    move-result v2

    if-nez v2, :cond_5

    new-instance v2, Laqs;

    invoke-virtual/range {p2 .. p2}, Laqg;->l()Lbyw;

    move-result-object v3

    move-object/from16 v4, p3

    invoke-direct/range {v2 .. v13}, Laqs;-><init>(Lbyw;Laqo;ILjava/lang/String;III[[Lbyq;Lbyq;Laqr;Laqr;)V

    :goto_5
    return-object v2

    :cond_4
    const/4 v11, 0x0

    goto :goto_4

    :cond_5
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, v3}, Laqj;->f(I)I

    move-result v14

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, v3}, Laqj;->g(I)I

    move-result v15

    new-instance v2, Laqq;

    invoke-virtual/range {p2 .. p2}, Laqg;->l()Lbyw;

    move-result-object v3

    move-object/from16 v4, p3

    invoke-direct/range {v2 .. v15}, Laqq;-><init>(Lbyw;Laqo;ILjava/lang/String;III[[Lbyq;Lbyq;Laqr;Laqr;II)V

    goto :goto_5

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_6
        :pswitch_7
    .end packed-switch
.end method
