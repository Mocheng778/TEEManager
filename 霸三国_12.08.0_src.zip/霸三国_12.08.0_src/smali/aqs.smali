.class public Laqs;
.super Laqh;


# static fields
.field private static final o:I


# instance fields
.field private a:Lasc;

.field private b:I

.field private c:[[Lbyq;

.field private d:Lbyq;

.field private e:Lbyq;

.field private f:Laqr;

.field private g:Laqr;

.field private h:I

.field private i:Ljava/lang/String;

.field private j:I

.field private k:I

.field private l:I

.field private m:Laqo;

.field private n:Lbyw;

.field private p:I

.field private q:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/16 v0, 0x1388

    sget v1, Laoe;->a:I

    div-int/2addr v0, v1

    sput v0, Laqs;->o:I

    return-void
.end method

.method public constructor <init>(Lbyw;Laqo;ILjava/lang/String;III[[Lbyq;Lbyq;Laqr;Laqr;)V
    .locals 1

    invoke-direct {p0}, Laqh;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Laqs;->b:I

    iput-object p1, p0, Laqs;->n:Lbyw;

    iput-object p2, p0, Laqs;->m:Laqo;

    iput p3, p0, Laqs;->h:I

    iput-object p4, p0, Laqs;->i:Ljava/lang/String;

    iput p5, p0, Laqs;->j:I

    iput p6, p0, Laqs;->k:I

    iput p6, p0, Laqs;->l:I

    iput p7, p0, Laqs;->q:I

    iput-object p8, p0, Laqs;->c:[[Lbyq;

    iput-object p9, p0, Laqs;->d:Lbyq;

    iput-object p10, p0, Laqs;->f:Laqr;

    iput-object p11, p0, Laqs;->g:Laqr;

    new-instance v0, Lasb;

    invoke-direct {v0, p0}, Lasb;-><init>(Laqs;)V

    iput-object v0, p0, Laqs;->a:Lasc;

    return-void
.end method


# virtual methods
.method public a(DDI)V
    .locals 7

    new-instance v0, Lasa;

    move-object v1, p0

    move-wide v2, p1

    move-wide v4, p3

    move v6, p5

    invoke-direct/range {v0 .. v6}, Lasa;-><init>(Laqs;DDI)V

    invoke-virtual {p0, v0}, Laqs;->a(Lasc;)V

    return-void
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laqs;->b:I

    return-void
.end method

.method public a(Laqr;DD)V
    .locals 7

    new-instance v0, Larx;

    invoke-virtual {p1}, Laqr;->a()[Lbyq;

    move-result-object v6

    move-object v1, p0

    move-wide v2, p2

    move-wide v4, p4

    invoke-direct/range {v0 .. v6}, Larx;-><init>(Laqs;DD[Lbyq;)V

    invoke-virtual {p0, v0}, Laqs;->a(Lasc;)V

    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v0

    invoke-virtual {p1}, Laqr;->d()I

    move-result v1

    invoke-virtual {v0, v1}, Lbmh;->b(I)V

    return-void
.end method

.method public a(Lasc;)V
    .locals 0

    iput-object p1, p0, Laqs;->a:Lasc;

    return-void
.end method

.method public a(Lbyq;I)V
    .locals 1

    iput-object p1, p0, Laqs;->e:Lbyq;

    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v0

    invoke-virtual {v0, p2}, Lbmh;->b(I)V

    return-void
.end method

.method public a(Lcar;II)V
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Laqs;->d:Lbyq;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->d:Lbyq;

    add-int/lit8 v1, p2, -0x3c

    add-int/lit8 v2, p3, -0x54

    invoke-virtual {v0, p1, v1, v2, v3}, Lbyq;->a(Lcar;III)V

    :cond_0
    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0, p1, p2, p3}, Lasc;->a(Lcar;II)V

    :cond_1
    iget-object v0, p0, Laqs;->e:Lbyq;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laqs;->e:Lbyq;

    invoke-virtual {v0, p1, p2, p3, v3}, Lbyq;->a(Lcar;III)V

    :cond_2
    return-void
.end method

.method public b(I)[Lbyq;
    .locals 1

    iget-object v0, p0, Laqs;->c:[[Lbyq;

    aget-object v0, v0, p1

    return-object v0
.end method

.method public c(I)V
    .locals 1

    sget v0, Laqs;->o:I

    iput v0, p0, Laqs;->p:I

    iput p1, p0, Laqs;->l:I

    if-nez p1, :cond_0

    new-instance v0, Lary;

    invoke-direct {v0, p0}, Lary;-><init>(Laqs;)V

    invoke-virtual {p0, v0}, Laqs;->a(Lasc;)V

    :cond_0
    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Laqs;->h:I

    return v0
.end method

.method public g()I
    .locals 1

    iget v0, p0, Laqs;->q:I

    return v0
.end method

.method public h()Laqr;
    .locals 1

    iget-object v0, p0, Laqs;->g:Laqr;

    return-object v0
.end method

.method public i()Laqr;
    .locals 1

    iget-object v0, p0, Laqs;->f:Laqr;

    return-object v0
.end method

.method public j()Laqo;
    .locals 1

    iget-object v0, p0, Laqs;->m:Laqo;

    return-object v0
.end method

.method public k()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqs;->i:Ljava/lang/String;

    return-object v0
.end method

.method public l()I
    .locals 1

    iget v0, p0, Laqs;->j:I

    return v0
.end method

.method public m()I
    .locals 1

    iget v0, p0, Laqs;->k:I

    return v0
.end method

.method public n()I
    .locals 1

    iget v0, p0, Laqs;->l:I

    return v0
.end method

.method public o()V
    .locals 1

    iget-object v0, p0, Laqs;->d:Lbyq;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->d:Lbyq;

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->d:Lbyq;

    invoke-virtual {v0}, Lbyq;->b()V

    :cond_0
    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0}, Lasc;->a()V

    :cond_1
    iget-object v0, p0, Laqs;->e:Lbyq;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laqs;->e:Lbyq;

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    iput-object v0, p0, Laqs;->e:Lbyq;

    :cond_2
    iget v0, p0, Laqs;->p:I

    if-lez v0, :cond_3

    iget v0, p0, Laqs;->p:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Laqs;->p:I

    :cond_3
    return-void
.end method

.method public p()V
    .locals 1

    iget-object v0, p0, Laqs;->n:Lbyw;

    invoke-virtual {v0, p0}, Lbyw;->b(Lbyx;)V

    return-void
.end method

.method public q()Z
    .locals 1

    iget v0, p0, Laqs;->p:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public r()I
    .locals 1

    iget v0, p0, Laqs;->b:I

    return v0
.end method

.method public s()V
    .locals 1

    new-instance v0, Lasb;

    invoke-direct {v0, p0}, Lasb;-><init>(Laqs;)V

    invoke-virtual {p0, v0}, Laqs;->a(Lasc;)V

    return-void
.end method

.method public t()I
    .locals 1

    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0}, Lasc;->f()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public u()I
    .locals 1

    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0}, Lasc;->g()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public v()I
    .locals 1

    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0}, Lasc;->i()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public w()I
    .locals 1

    iget-object v0, p0, Laqs;->a:Lasc;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqs;->a:Lasc;

    invoke-virtual {v0}, Lasc;->h()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method
