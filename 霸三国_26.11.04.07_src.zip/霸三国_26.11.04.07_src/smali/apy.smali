.class public Lapy;
.super Lbwj;


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/lszb/barracks/view/BarracksProduceListView;


# direct methods
.method public constructor <init>(Lcom/lszb/barracks/view/BarracksProduceListView;I)V
    .locals 0

    iput-object p1, p0, Lapy;->b:Lcom/lszb/barracks/view/BarracksProduceListView;

    iput p2, p0, Lapy;->a:I

    invoke-direct {p0}, Lbwj;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapy;->b:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->h(Lcom/lszb/barracks/view/BarracksProduceListView;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a(Lcom/lszb/view/ConfirmDialogView;)V
    .locals 4

    iget-object v0, p0, Lapy;->b:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/LoadingView;

    invoke-direct {v1}, Lcom/lszb/view/LoadingView;-><init>()V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Lapy;->b:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->i(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v1

    invoke-virtual {v1}, Latv;->j()I

    move-result v1

    iget-object v2, p0, Lapy;->b:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarracksProduceListView;->j(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v2

    invoke-virtual {v2}, Latv;->h()Lajw;

    move-result-object v2

    invoke-virtual {v2}, Lajw;->g()I

    move-result v2

    iget v3, p0, Lapy;->a:I

    invoke-virtual {v0, v1, v2, v3}, Lmm;->k(III)V

    return-void
.end method
