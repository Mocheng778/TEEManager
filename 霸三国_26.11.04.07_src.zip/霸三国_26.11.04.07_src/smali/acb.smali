.class public Lacb;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lamr;Ljava/io/DataInputStream;)V
    .locals 1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lamr;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lakj;

    invoke-direct {v0}, Lakj;-><init>()V

    invoke-static {v0, p1}, Lzu;->a(Lakj;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lamr;->a(Lakj;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lamr;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lamr;->a(I)V

    return-void
.end method
