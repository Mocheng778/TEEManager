.class public Lahw;
.super Ljava/lang/Object;


# instance fields
.field private a:Laks;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Laks;
    .locals 1

    iget-object v0, p0, Lahw;->a:Laks;

    return-object v0
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Lahw;->a:Laks;

    return-void
.end method
