.class public Lasd;
.super Latd;


# instance fields
.field private a:Lbxr;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private final g:Ljava/lang/String;

.field private h:Lbxf;

.field private i:Lbxf;

.field private j:Ljava/lang/Object;

.field private k:Laln;

.field private l:Lasv;


# direct methods
.method public constructor <init>(Lasv;Laln;)V
    .locals 1

    invoke-direct {p0}, Latd;-><init>()V

    const-string v0, "\u9a7b\u9632\u884c"

    iput-object v0, p0, Lasd;->b:Ljava/lang/String;

    const-string v0, "\u4fe1\u606f"

    iput-object v0, p0, Lasd;->c:Ljava/lang/String;

    const-string v0, "\u72b6\u6001"

    iput-object v0, p0, Lasd;->d:Ljava/lang/String;

    const-string v0, "\u53ec\u56de"

    iput-object v0, p0, Lasd;->e:Ljava/lang/String;

    const-string v0, "\u67e5\u770b"

    iput-object v0, p0, Lasd;->f:Ljava/lang/String;

    const-string v0, "\u9762"

    iput-object v0, p0, Lasd;->g:Ljava/lang/String;

    iput-object p1, p0, Lasd;->l:Lasv;

    iput-object p2, p0, Lasd;->k:Laln;

    return-void
.end method

.method static synthetic a(Lasd;)Laln;
    .locals 1

    iget-object v0, p0, Lasd;->k:Laln;

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 1

    iget-object v0, p0, Lasd;->i:Lbxf;

    invoke-virtual {v0}, Lbxf;->b()I

    move-result v0

    return v0
.end method

.method public a(II)V
    .locals 3

    iget-object v0, p0, Lasd;->i:Lbxf;

    iget-object v1, p0, Lasd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lasd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Lasd;->j:Ljava/lang/Object;

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->m()V

    :cond_0
    return-void
.end method

.method public a(Lcar;IIZ)V
    .locals 3

    if-eqz p4, :cond_0

    iget-object v0, p0, Lasd;->h:Lbxf;

    invoke-virtual {v0}, Lbxf;->m()V

    :goto_0
    iget-object v0, p0, Lasd;->i:Lbxf;

    iget-object v1, p0, Lasd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Lasd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void

    :cond_0
    iget-object v0, p0, Lasd;->h:Lbxf;

    invoke-virtual {v0}, Lbxf;->n()V

    goto :goto_0
.end method

.method public a(Ljava/util/Hashtable;I)V
    .locals 3

    :try_start_0
    new-instance v0, Lbxr;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "army_defended_row.bin"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v2

    invoke-direct {v0, v1, p1, v2}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    iput-object v0, p0, Lasd;->a:Lbxr;

    iget-object v0, p0, Lasd;->a:Lbxr;

    invoke-static {v0, p1}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    new-instance v1, Lase;

    invoke-direct {v1, p0}, Lase;-><init>(Lasd;)V

    iget-object v0, p0, Lasd;->a:Lbxr;

    const-string v2, "\u4fe1\u606f"

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lasd;->a:Lbxr;

    const-string v2, "\u72b6\u6001"

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lasd;->a:Lbxr;

    const-string v1, "\u53ec\u56de"

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    iget-object v1, p0, Lasd;->k:Laln;

    invoke-virtual {v1}, Laln;->g()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/lzlm/component/ButtonComponent;->b(Z)V

    :cond_0
    iget-object v0, p0, Lasd;->a:Lbxr;

    const-string v1, "\u9762"

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lasd;->h:Lbxf;

    iget-object v0, p0, Lasd;->a:Lbxr;

    const-string v1, "\u9a7b\u9632\u884c"

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lasd;->i:Lbxf;

    iget-object v0, p0, Lasd;->i:Lbxf;

    invoke-virtual {v0, p2}, Lbxf;->e(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public b()V
    .locals 0

    return-void
.end method

.method public b(II)V
    .locals 3

    iget-object v0, p0, Lasd;->i:Lbxf;

    iget-object v1, p0, Lasd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lasd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Lasd;->j:Ljava/lang/Object;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u53ec\u56de"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "\u53ec\u56de"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    iget-object v0, p0, Lasd;->l:Lasv;

    iget-object v1, p0, Lasd;->k:Laln;

    invoke-interface {v0, v1}, Lasv;->b(Laln;)V

    :cond_0
    :goto_0
    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->n()V

    :cond_1
    return-void

    :cond_2
    iget-object v0, p0, Lasd;->j:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u67e5\u770b"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "\u67e5\u770b"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    iget-object v0, p0, Lasd;->l:Lasv;

    iget-object v1, p0, Lasd;->k:Laln;

    invoke-interface {v0, v1}, Lasv;->c(Laln;)V

    goto :goto_0
.end method
