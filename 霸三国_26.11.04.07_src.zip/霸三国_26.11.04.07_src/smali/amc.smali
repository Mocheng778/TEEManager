.class public Lamc;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:[Lanu;

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lamc;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamc;->a:I

    return-void
.end method

.method public a([Lanu;)V
    .locals 0

    iput-object p1, p0, Lamc;->e:[Lanu;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamc;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamc;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamc;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamc;->c:I

    return-void
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamc;->d:I

    return-void
.end method

.method public d()[Lanu;
    .locals 1

    iget-object v0, p0, Lamc;->e:[Lanu;

    return-object v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamc;->d:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamc;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamc;->f:I

    return v0
.end method
