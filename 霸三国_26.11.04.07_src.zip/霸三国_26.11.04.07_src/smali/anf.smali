.class public Lanf;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lanf;->b:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lanf;->a:I

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lanf;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lanf;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lanf;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lanf;->c:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lanf;->e:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lanf;->d:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lanf;->f:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lanf;->e:I

    return-void
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lanf;->f:I

    return-void
.end method
