.class public Laik;
.super Ljava/lang/Object;


# instance fields
.field private a:Lama;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lama;
    .locals 1

    iget-object v0, p0, Laik;->a:Lama;

    return-object v0
.end method

.method public a(Lama;)V
    .locals 0

    iput-object p1, p0, Laik;->a:Lama;

    return-void
.end method
