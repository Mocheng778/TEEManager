.class public Lame;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:J

.field private e:J

.field private f:J

.field private g:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lame;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lame;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lame;->d:J

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lame;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lame;->b:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lame;->e:J

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lame;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lame;->c:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lame;->f:J

    return-void
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Lame;->e:J

    return-wide v0
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lame;->g:J

    return-void
.end method

.method public e()J
    .locals 2

    iget-wide v0, p0, Lame;->g:J

    return-wide v0
.end method
