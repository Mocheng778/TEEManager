.class public Laro;
.super Lars;


# instance fields
.field private b:Laks;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Laks;[Lamz;)V
    .locals 1

    const/4 v0, 0x1

    invoke-direct {p0, v0, p2}, Lars;-><init>(I[Lamz;)V

    iput-object p1, p0, Laro;->b:Laks;

    iget-object v0, p0, Laro;->b:Laks;

    invoke-virtual {v0}, Laks;->e()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laro;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laro;->c:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 4

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Laro;->b:Laks;

    invoke-virtual {v1}, Laks;->d()I

    move-result v1

    const/4 v2, 0x0

    aget-object v2, p1, v2

    invoke-virtual {v2}, Lakw;->x()I

    move-result v2

    invoke-virtual {p0, p1}, Laro;->c([Lakw;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Lmm;->a(IILjava/lang/String;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-static {}, Latt;->a()Latt;

    move-result-object v1

    invoke-virtual {v1}, Latt;->h()I

    move-result v1

    iget-object v2, p0, Laro;->b:Laks;

    invoke-virtual {v2}, Laks;->i()I

    move-result v2

    iget-object v3, p0, Laro;->b:Laks;

    invoke-virtual {v3}, Laks;->j()I

    move-result v3

    invoke-virtual {v0, v1, v2, v3}, Lmm;->g(III)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 7

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v1}, Lakw;->x()I

    move-result v1

    invoke-virtual {v0, v1}, Latt;->a(I)Lakr;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->i()I

    move-result v2

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->j()I

    move-result v3

    iget-object v0, p0, Laro;->b:Laks;

    invoke-virtual {v0}, Laks;->i()I

    move-result v4

    iget-object v0, p0, Laro;->b:Laks;

    invoke-virtual {v0}, Laks;->j()I

    move-result v5

    move-object v0, p0

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Laro;->a(ZIIII[Lakw;)I

    move-result v0

    return v0
.end method

.method public d()I
    .locals 1

    iget-object v0, p0, Laro;->b:Laks;

    invoke-virtual {v0}, Laks;->i()I

    move-result v0

    return v0
.end method

.method public e()I
    .locals 1

    iget-object v0, p0, Laro;->b:Laks;

    invoke-virtual {v0}, Laks;->j()I

    move-result v0

    return v0
.end method
