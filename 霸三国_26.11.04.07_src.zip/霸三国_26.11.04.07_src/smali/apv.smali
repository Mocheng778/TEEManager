.class public Lapv;
.super Laqc;


# instance fields
.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:Ljava/lang/String;

.field private k:Lbxf;

.field private l:I

.field private m:I

.field private n:I

.field private o:Ljava/lang/String;

.field private p:Ljava/lang/String;

.field private q:Z

.field private r:Latv;

.field private s:I


# direct methods
.method public constructor <init>(Latv;II)V
    .locals 1

    invoke-direct {p0, p2}, Laqc;-><init>(I)V

    const-string v0, "\u5f53\u524d\u6570\u91cf"

    iput-object v0, p0, Lapv;->d:Ljava/lang/String;

    const-string v0, "\u4eba\u53e3\u53ef\u62db"

    iput-object v0, p0, Lapv;->e:Ljava/lang/String;

    const-string v0, "\u8d44\u6e90\u53ef\u62db"

    iput-object v0, p0, Lapv;->f:Ljava/lang/String;

    const-string v0, "\u83dc\u5355"

    iput-object v0, p0, Lapv;->g:Ljava/lang/String;

    const-string v0, "\u62db\u52df"

    iput-object v0, p0, Lapv;->h:Ljava/lang/String;

    const-string v0, "\u6025\u62db"

    iput-object v0, p0, Lapv;->i:Ljava/lang/String;

    const-string v0, "\u53d6\u6d88"

    iput-object v0, p0, Lapv;->j:Ljava/lang/String;

    const/4 v0, 0x2

    iput v0, p0, Lapv;->s:I

    iput-object p1, p0, Lapv;->r:Latv;

    iput p3, p0, Lapv;->l:I

    invoke-direct {p0, p2}, Lapv;->a(I)V

    return-void
.end method

.method static synthetic a(Lapv;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapv;->d:Ljava/lang/String;

    return-object v0
.end method

.method private a(I)V
    .locals 8

    const/4 v0, 0x0

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v1

    invoke-virtual {v1, p1}, Lapp;->a(I)Lanq;

    move-result-object v3

    invoke-static {}, Lbtl;->a()Lbtl;

    move-result-object v1

    invoke-virtual {v1}, Lbtl;->c()Lamq;

    move-result-object v1

    invoke-virtual {v1}, Lamq;->d()I

    move-result v2

    invoke-virtual {v1}, Lamq;->c()I

    move-result v4

    sub-int/2addr v2, v4

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v3}, Lanq;->j()I

    move-result v4

    div-int/2addr v2, v4

    iput v2, p0, Lapv;->m:I

    invoke-virtual {v1}, Lamq;->h()J

    move-result-wide v4

    invoke-virtual {v3}, Lanq;->l()I

    move-result v2

    int-to-long v6, v2

    div-long/2addr v4, v6

    invoke-virtual {v1}, Lamq;->g()J

    move-result-wide v1

    invoke-virtual {v3}, Lanq;->m()I

    move-result v6

    int-to-long v6, v6

    div-long/2addr v1, v6

    invoke-static {v4, v5, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    invoke-virtual {v3}, Lanq;->n()I

    move-result v4

    if-lez v4, :cond_1

    invoke-static {}, Lbgb;->a()Lbgb;

    move-result-object v4

    invoke-virtual {v4}, Lbgb;->b()Lbgi;

    move-result-object v4

    if-eqz v4, :cond_0

    invoke-virtual {v4}, Lbgi;->b()Lalx;

    move-result-object v0

    invoke-virtual {v0}, Lalx;->a()I

    move-result v0

    :cond_0
    invoke-virtual {v3}, Lanq;->n()I

    move-result v3

    div-int/2addr v0, v3

    int-to-long v3, v0

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    :goto_0
    const-wide/16 v2, 0x0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    long-to-int v0, v0

    iput v0, p0, Lapv;->n:I

    return-void

    :cond_1
    move-wide v0, v1

    goto :goto_0
.end method

.method static synthetic b(Lapv;)I
    .locals 1

    iget v0, p0, Lapv;->l:I

    return v0
.end method

.method static synthetic c(Lapv;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapv;->e:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic d(Lapv;)I
    .locals 1

    iget v0, p0, Lapv;->m:I

    return v0
.end method

.method static synthetic e(Lapv;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapv;->f:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic f(Lapv;)I
    .locals 1

    iget v0, p0, Lapv;->n:I

    return v0
.end method


# virtual methods
.method protected a(II)Ljava/lang/Object;
    .locals 3

    iget-boolean v0, p0, Lapv;->q:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapv;->k:Lbxf;

    iget-object v1, p0, Lapv;->k:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lapv;->k:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    invoke-super {p0, p1, p2}, Laqc;->a(II)Ljava/lang/Object;

    move-result-object v0

    goto :goto_0
.end method

.method protected a()Ljava/lang/String;
    .locals 1

    const-string v0, "barracks_row.bin"

    return-object v0
.end method

.method protected a(Lbxr;II)V
    .locals 2

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "ui_barracks.properties"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "UTF-8"

    invoke-static {v0, v1}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    const-string v1, "ui_barracks.\u8d44\u6e90\u4e0d\u8db3"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lapv;->o:Ljava/lang/String;

    const-string v1, "ui_barracks.\u4eba\u53e3\u4e0d\u8db3"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapv;->p:Ljava/lang/String;

    iget-object v0, p0, Lapv;->g:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lapv;->k:Lbxf;

    iget-object v0, p0, Lapv;->k:Lbxf;

    invoke-virtual {v0, p2}, Lbxf;->e(I)V

    iget-object v0, p0, Lapv;->k:Lbxf;

    invoke-virtual {v0, p3}, Lbxf;->f(I)V

    new-instance v1, Lapw;

    invoke-direct {v1, p0}, Lapw;-><init>(Lapv;)V

    iget-object v0, p0, Lapv;->d:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lapv;->e:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lapv;->f:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public a(Lcar;IIZ)V
    .locals 3

    invoke-super {p0, p1, p2, p3, p4}, Laqc;->a(Lcar;IIZ)V

    if-eqz p4, :cond_0

    iget-boolean v0, p0, Lapv;->q:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapv;->k:Lbxf;

    iget-object v1, p0, Lapv;->k:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Lapv;->k:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    :goto_0
    return-void

    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lapv;->q:Z

    goto :goto_0
.end method

.method protected a(Ljava/lang/Object;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    instance-of v0, p1, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_7

    move-object v0, p1

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    iget-object v1, p0, Lapv;->h:Ljava/lang/String;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget v0, p0, Lapv;->n:I

    if-gtz v0, :cond_1

    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lapv;->o:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :cond_0
    :goto_0
    invoke-super {p0, p1}, Laqc;->a(Ljava/lang/Object;)V

    return-void

    :cond_1
    iget v0, p0, Lapv;->m:I

    if-gtz v0, :cond_2

    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lapv;->p:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/barracks/view/BarrackRecruitView;

    iget v2, p0, Lapv;->b:I

    iget-object v3, p0, Lapv;->r:Latv;

    iget v4, p0, Lapv;->l:I

    invoke-direct {v1, v2, v3, v4, v5}, Lcom/lszb/barracks/view/BarrackRecruitView;-><init>(ILatv;IZ)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :cond_3
    iget-object v1, p0, Lapv;->i:Ljava/lang/String;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    iget v0, p0, Lapv;->n:I

    iget v1, p0, Lapv;->s:I

    div-int/2addr v0, v1

    if-gtz v0, :cond_4

    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lapv;->o:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :cond_4
    iget v0, p0, Lapv;->m:I

    if-gtz v0, :cond_5

    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lapv;->p:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :cond_5
    iget-object v0, p0, Lapv;->c:Laok;

    new-instance v1, Lcom/lszb/barracks/view/BarrackRecruitView;

    iget v2, p0, Lapv;->b:I

    iget-object v3, p0, Lapv;->r:Latv;

    iget v4, p0, Lapv;->l:I

    invoke-direct {v1, v2, v3, v4, v6}, Lcom/lszb/barracks/view/BarrackRecruitView;-><init>(ILatv;IZ)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0

    :cond_6
    iget-object v1, p0, Lapv;->j:Ljava/lang/String;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iput-boolean v5, p0, Lapv;->q:Z

    goto :goto_0

    :cond_7
    iput-boolean v6, p0, Lapv;->q:Z

    goto :goto_0
.end method
