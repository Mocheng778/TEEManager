.class public Lard;
.super Lbze;


# instance fields
.field private a:Lbyr;

.field private b:Ljava/util/Hashtable;

.field private c:[Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>(Lbyr;Ljava/util/Hashtable;[Ljava/lang/String;Ljava/lang/String;II)V
    .locals 0

    invoke-direct {p0}, Lbze;-><init>()V

    iput-object p1, p0, Lard;->a:Lbyr;

    iput-object p2, p0, Lard;->b:Ljava/util/Hashtable;

    iput-object p3, p0, Lard;->c:[Ljava/lang/String;

    iput-object p4, p0, Lard;->d:Ljava/lang/String;

    iput p5, p0, Lard;->f:I

    iput p6, p0, Lard;->e:I

    return-void
.end method


# virtual methods
.method public a()Lbzf;
    .locals 6

    iget-object v0, p0, Lard;->c:[Ljava/lang/String;

    array-length v0, v0

    new-array v4, v0, [Lbyq;

    const/4 v0, 0x0

    :goto_0
    array-length v1, v4

    if-ge v0, v1, :cond_0

    new-instance v1, Lbyq;

    iget-object v2, p0, Lard;->a:Lbyr;

    iget-object v3, p0, Lard;->c:[Ljava/lang/String;

    aget-object v3, v3, v0

    invoke-virtual {v2, v3}, Lbyr;->b(Ljava/lang/String;)I

    move-result v2

    iget-object v3, p0, Lard;->a:Lbyr;

    iget-object v5, p0, Lard;->b:Ljava/util/Hashtable;

    invoke-direct {v1, v2, v3, v5}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    aput-object v1, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    iget-object v0, p0, Lard;->d:Ljava/lang/String;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lard;->d:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    new-instance v5, Lbyq;

    iget-object v0, p0, Lard;->a:Lbyr;

    iget-object v1, p0, Lard;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Lard;->a:Lbyr;

    iget-object v2, p0, Lard;->b:Ljava/util/Hashtable;

    invoke-direct {v5, v0, v1, v2}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    :cond_1
    new-instance v0, Larc;

    iget v2, p0, Lard;->f:I

    iget v3, p0, Lard;->e:I

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Larc;-><init>(Lbze;II[Lbyq;Lbyq;)V

    return-object v0
.end method
