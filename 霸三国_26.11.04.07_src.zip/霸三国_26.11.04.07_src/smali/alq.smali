.class public Lalq;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lalq;->j:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lalq;->j:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalq;->j:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalq;->c:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lalq;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lalq;->a:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalq;->d:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalq;->c:Ljava/lang/String;

    return-object v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lalq;->b:I

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalq;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lalq;->e:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lalq;->e:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lalq;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lalq;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lalq;->g:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lalq;->g:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lalq;->h:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lalq;->h:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lalq;->i:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lalq;->i:I

    return v0
.end method
