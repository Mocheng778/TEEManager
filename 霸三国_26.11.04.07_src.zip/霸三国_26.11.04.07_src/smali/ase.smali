.class Lase;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Lasd;


# direct methods
.method constructor <init>(Lasd;)V
    .locals 0

    iput-object p1, p0, Lase;->a:Lasd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u4fe1\u606f"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Laqn;->a()Laqn;

    move-result-object v0

    iget-object v1, p0, Lase;->a:Lasd;

    invoke-static {v1}, Lasd;->a(Lasd;)Laln;

    move-result-object v1

    invoke-virtual {v0, v1}, Laqn;->a(Laln;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u72b6\u6001"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    iget-object v1, p0, Lase;->a:Lasd;

    invoke-static {v1}, Lasd;->a(Lasd;)Laln;

    move-result-object v1

    invoke-virtual {v1}, Laln;->g()I

    move-result v1

    invoke-virtual {v0, v1}, Laqj;->v(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const-string v0, ""

    goto :goto_0
.end method
