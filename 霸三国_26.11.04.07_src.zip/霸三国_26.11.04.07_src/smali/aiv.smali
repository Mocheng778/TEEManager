.class public Laiv;
.super Ljava/lang/Object;


# instance fields
.field private a:Lamq;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lamq;
    .locals 1

    iget-object v0, p0, Laiv;->a:Lamq;

    return-object v0
.end method

.method public a(Lamq;)V
    .locals 0

    iput-object p1, p0, Laiv;->a:Lamq;

    return-void
.end method
