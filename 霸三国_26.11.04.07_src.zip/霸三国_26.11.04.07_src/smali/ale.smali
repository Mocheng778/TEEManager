.class public Lale;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:J

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:Ljava/lang/String;

.field private k:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lale;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lale;->e:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lale;->c:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lale;->k:Z

    return-void
.end method

.method public a()Z
    .locals 1

    iget-boolean v0, p0, Lale;->k:Z

    return v0
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lale;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lale;->b:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lale;->d:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lale;->b:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lale;->f:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lale;->j:Ljava/lang/String;

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lale;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lale;->g:I

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lale;->d:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lale;->h:I

    return-void
.end method

.method public f()J
    .locals 2

    iget-wide v0, p0, Lale;->e:J

    return-wide v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lale;->i:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lale;->f:I

    return v0
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lale;->g:I

    return v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lale;->h:I

    return v0
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lale;->i:I

    return v0
.end method

.method public k()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lale;->j:Ljava/lang/String;

    return-object v0
.end method
