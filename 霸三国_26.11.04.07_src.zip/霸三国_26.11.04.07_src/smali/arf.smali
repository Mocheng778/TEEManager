.class public Larf;
.super Lare;


# instance fields
.field private a:Lbyq;

.field private b:Lbyq;


# direct methods
.method public constructor <init>(Lbze;IILbyq;Lbyq;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lare;-><init>(Lbze;II)V

    iput-object p4, p0, Larf;->a:Lbyq;

    iput-object p5, p0, Larf;->b:Lbyq;

    return-void
.end method


# virtual methods
.method protected d()Lbyq;
    .locals 1

    iget-object v0, p0, Larf;->a:Lbyq;

    return-object v0
.end method

.method protected e()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method protected f()Lbyq;
    .locals 1

    iget-object v0, p0, Larf;->b:Lbyq;

    return-object v0
.end method

.method protected g()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
