.class public abstract Lars;
.super Ljava/lang/Object;


# instance fields
.field protected a:[Lakw;

.field private b:[Lamz;

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;


# direct methods
.method public constructor <init>(I[Lamz;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lars;->c:I

    iput-object p2, p0, Lars;->b:[Lamz;

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->s(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lars;->d:Ljava/lang/String;

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->t(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lars;->e:Ljava/lang/String;

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->u(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lars;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected a(ZIIII[Lakw;)I
    .locals 11

    const-wide v2, 0x41dfffffffc00000L    # 2.147483647E9

    const/4 v1, 0x0

    move-wide v9, v2

    :goto_0
    move-object/from16 v0, p6

    array-length v2, v0

    if-ge v1, v2, :cond_1

    aget-object v2, p6, v1

    invoke-virtual {v2}, Lakw;->c()I

    move-result v2

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v3

    invoke-virtual {v3, v2}, Lapp;->a(I)Lanq;

    move-result-object v4

    invoke-virtual {v4}, Lanq;->h()I

    move-result v2

    int-to-double v2, v2

    invoke-virtual {v4}, Lanq;->d()I

    move-result v4

    const/4 v5, 0x4

    if-ne v4, v5, :cond_0

    invoke-static {}, Lbvh;->a()Lbvh;

    move-result-object v4

    const/16 v5, 0xe

    invoke-virtual {v4, v5}, Lbvh;->a(I)Lbvf;

    move-result-object v4

    invoke-static {}, Lbvh;->a()Lbvh;

    move-result-object v5

    const/16 v6, 0xe

    invoke-virtual {v4}, Lbvf;->b()Lane;

    move-result-object v4

    invoke-virtual {v4}, Lane;->b()I

    move-result v4

    invoke-virtual {v5, v6, v4}, Lbvh;->a(II)Lanf;

    move-result-object v4

    if-eqz v4, :cond_0

    invoke-virtual {v4}, Lanf;->e()I

    move-result v4

    add-int/lit8 v4, v4, 0x64

    int-to-double v4, v4

    mul-double/2addr v2, v4

    const-wide/high16 v4, 0x4059000000000000L    # 100.0

    div-double/2addr v2, v4

    :cond_0
    cmpg-double v4, v2, v9

    if-gez v4, :cond_3

    :goto_1
    add-int/lit8 v1, v1, 0x1

    move-wide v9, v2

    goto :goto_0

    :cond_1
    int-to-double v1, p2

    int-to-double v3, p3

    int-to-double v5, p4

    move/from16 v0, p5

    int-to-double v7, v0

    invoke-static/range {v1 .. v8}, Lbyz;->a(DDDD)D

    move-result-wide v2

    iget v1, p0, Lars;->c:I

    packed-switch v1, :pswitch_data_0

    :pswitch_0
    const/4 v1, 0x0

    :goto_2
    int-to-double v4, v1

    mul-double v1, v2, v4

    const-wide/high16 v3, 0x4059000000000000L    # 100.0

    div-double v3, v9, v3

    div-double/2addr v1, v3

    double-to-int v1, v1

    if-eqz p1, :cond_2

    iget v2, p0, Lars;->c:I

    packed-switch v2, :pswitch_data_1

    :cond_2
    :goto_3
    :pswitch_1
    return v1

    :pswitch_2
    sget v1, Latt;->a:I

    goto :goto_2

    :pswitch_3
    sget v1, Latt;->b:I

    goto :goto_2

    :pswitch_4
    sget v1, Latt;->c:I

    goto :goto_2

    :pswitch_5
    sget v2, Latt;->d:I

    add-int/2addr v1, v2

    goto :goto_3

    :pswitch_6
    sget v2, Latt;->e:I

    add-int/2addr v1, v2

    goto :goto_3

    :pswitch_7
    sget v2, Latt;->f:I

    add-int/2addr v1, v2

    goto :goto_3

    :cond_3
    move-wide v2, v9

    goto :goto_1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_2
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_5
        :pswitch_7
        :pswitch_6
        :pswitch_6
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_5
    .end packed-switch
.end method

.method public abstract a()Ljava/lang/String;
.end method

.method public abstract a([Lakw;)V
.end method

.method public abstract b([Lakw;)I
.end method

.method public b()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lars;->d:Ljava/lang/String;

    return-object v0
.end method

.method public c([Lakw;)Ljava/lang/String;
    .locals 3

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v0, 0x0

    :goto_0
    array-length v2, p1

    if-ge v0, v2, :cond_1

    aget-object v2, p1, v0

    invoke-virtual {v2}, Lakw;->k()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    array-length v2, p1

    add-int/lit8 v2, v2, -0x1

    if-ge v0, v2, :cond_0

    const/16 v2, 0x2c

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public d()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public e()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public f()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lars;->e:Ljava/lang/String;

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lars;->f:Ljava/lang/String;

    return-object v0
.end method

.method public h()[Lakw;
    .locals 1

    iget-object v0, p0, Lars;->a:[Lakw;

    return-object v0
.end method
