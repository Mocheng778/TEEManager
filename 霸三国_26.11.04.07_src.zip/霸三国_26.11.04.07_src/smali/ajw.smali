.class public Lajw;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:J

.field private d:I

.field private e:I

.field private f:I

.field private g:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lajw;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lajw;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lajw;->c:J

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lajw;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lajw;->b:I

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Lajw;->c:J

    return-wide v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lajw;->d:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lajw;->d:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lajw;->e:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lajw;->e:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lajw;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lajw;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lajw;->g:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lajw;->g:I

    return v0
.end method
