.class public Laqy;
.super Laqu;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 6

    const/4 v1, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Laqu;-><init>()V

    iput v5, p0, Laqy;->d:I

    const-string v0, "_"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_0

    packed-switch v0, :pswitch_data_0

    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :pswitch_0
    aget-object v3, v2, v0

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Laqy;->a:I

    goto :goto_1

    :pswitch_1
    aget-object v3, v2, v0

    const-string v4, ","

    invoke-static {v3, v4}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v4, v3, v1

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    iput v4, p0, Laqy;->b:I

    aget-object v3, v3, v5

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Laqy;->c:I

    goto :goto_1

    :pswitch_2
    aget-object v3, v2, v0

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    packed-switch v3, :pswitch_data_1

    goto :goto_1

    :pswitch_3
    iput v5, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_4
    const/16 v3, 0x9

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_5
    const/16 v3, 0x8

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_6
    const/16 v3, 0xa

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_7
    const/4 v3, 0x2

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_8
    const/4 v3, 0x6

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_9
    const/4 v3, 0x4

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :pswitch_a
    const/4 v3, 0x5

    iput v3, p0, Laqy;->d:I

    goto :goto_1

    :cond_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
    .end packed-switch
.end method


# virtual methods
.method public a(Laqg;)V
    .locals 4

    iget v0, p0, Laqy;->a:I

    iget v1, p0, Laqy;->b:I

    iget v2, p0, Laqy;->c:I

    iget v3, p0, Laqy;->d:I

    invoke-virtual {p1, v0, v1, v2, v3}, Laqg;->a(IIII)V

    return-void
.end method
