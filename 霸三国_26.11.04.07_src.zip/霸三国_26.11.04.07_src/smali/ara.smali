.class public Lara;
.super Laqu;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Laqu;-><init>()V

    const-string v0, "_"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v1, v0, v3

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Lara;->a:I

    aget-object v1, v0, v4

    const-string v2, ","

    invoke-static {v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v2, v1, v3

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Lara;->b:I

    aget-object v1, v1, v4

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Lara;->c:I

    const/4 v1, 0x2

    aget-object v0, v0, v1

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x64

    sget v1, Laoe;->a:I

    div-int/2addr v0, v1

    iput v0, p0, Lara;->d:I

    return-void
.end method


# virtual methods
.method public a(Laqg;)V
    .locals 4

    iget v0, p0, Lara;->a:I

    iget v1, p0, Lara;->b:I

    iget v2, p0, Lara;->c:I

    iget v3, p0, Lara;->d:I

    invoke-virtual {p1, v0, v1, v2, v3}, Laqg;->b(IIII)V

    return-void
.end method
