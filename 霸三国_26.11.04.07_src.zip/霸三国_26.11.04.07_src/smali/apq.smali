.class Lapq;
.super Lbol;


# instance fields
.field final synthetic a:Lapp;


# direct methods
.method constructor <init>(Lapp;)V
    .locals 0

    iput-object p1, p0, Lapq;->a:Lapp;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public c(Laha;)V
    .locals 0

    invoke-virtual {p0, p1}, Lapq;->d(Laha;)V

    return-void
.end method

.method public d(Laha;)V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, -0x1

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Laha;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_2

    invoke-virtual {p1}, Laha;->am()[Lanq;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Laha;->am()[Lanq;

    move-result-object v2

    invoke-static {}, Lany;->b()Lany;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->k()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "icon.bin"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lany;->b(Ljava/lang/String;)Lbyr;

    move-result-object v3

    iget-object v0, p0, Lapq;->a:Lapp;

    invoke-static {v0}, Lapp;->a(Lapp;)Ljava/util/Hashtable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    iget-object v0, p0, Lapq;->a:Lapp;

    invoke-static {v0}, Lapp;->b(Lapp;)Ljava/util/Hashtable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-eqz v2, :cond_2

    array-length v0, v2

    if-ge v1, v0, :cond_2

    aget-object v0, v2, v1

    invoke-virtual {v0}, Lanq;->c()I

    move-result v4

    iget-object v0, p0, Lapq;->a:Lapp;

    invoke-static {v0}, Lapp;->a(Lapp;)Ljava/util/Hashtable;

    move-result-object v0

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    aget-object v6, v2, v1

    invoke-virtual {v0, v5, v6}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5175\u79cd_"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    if-ne v0, v9, :cond_0

    const-string v0, "\u5175\u79cd\u9ed8\u8ba4"

    invoke-virtual {v3, v0}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    :cond_0
    new-instance v5, Lbyq;

    invoke-direct {v5, v0, v3, v10}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u5175\u79cd\u5c0f\u56fe\u6807_"

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    if-ne v0, v9, :cond_1

    const-string v0, "\u5175\u79cd\u9ed8\u8ba4\u5c0f\u56fe\u6807"

    invoke-virtual {v3, v0}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    :cond_1
    new-instance v6, Lbyq;

    invoke-direct {v6, v0, v3, v10}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    invoke-static {}, Lapo;->a()Lapo;

    move-result-object v0

    invoke-virtual {v0, v4}, Lapo;->a(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lapo;->a()Lapo;

    move-result-object v7

    invoke-virtual {v7, v4}, Lapo;->b(I)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lapr;

    invoke-direct {v8, v5, v6, v0, v7}, Lapr;-><init>(Lbyq;Lbyq;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lapq;->a:Lapp;

    invoke-static {v0}, Lapp;->b(Lapp;)Ljava/util/Hashtable;

    move-result-object v0

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4, v8}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto/16 :goto_0

    :cond_2
    return-void
.end method
