.class public Larg;
.super Lbze;


# instance fields
.field private a:Lbyr;

.field private b:Ljava/util/Hashtable;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>(Lbyr;Ljava/util/Hashtable;Ljava/lang/String;Ljava/lang/String;II)V
    .locals 0

    invoke-direct {p0}, Lbze;-><init>()V

    iput-object p1, p0, Larg;->a:Lbyr;

    iput-object p2, p0, Larg;->b:Ljava/util/Hashtable;

    iput-object p3, p0, Larg;->c:Ljava/lang/String;

    iput-object p4, p0, Larg;->d:Ljava/lang/String;

    iput p5, p0, Larg;->f:I

    iput p6, p0, Larg;->e:I

    return-void
.end method


# virtual methods
.method public a()Lbzf;
    .locals 6

    new-instance v4, Lbyq;

    iget-object v0, p0, Larg;->a:Lbyr;

    iget-object v1, p0, Larg;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Larg;->a:Lbyr;

    iget-object v2, p0, Larg;->b:Ljava/util/Hashtable;

    invoke-direct {v4, v0, v1, v2}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    new-instance v5, Lbyq;

    iget-object v0, p0, Larg;->a:Lbyr;

    iget-object v1, p0, Larg;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbyr;->b(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Larg;->a:Lbyr;

    iget-object v2, p0, Larg;->b:Ljava/util/Hashtable;

    invoke-direct {v5, v0, v1, v2}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    new-instance v0, Larf;

    iget v2, p0, Larg;->f:I

    iget v3, p0, Larg;->e:I

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Larf;-><init>(Lbze;IILbyq;Lbyq;)V

    return-object v0
.end method
