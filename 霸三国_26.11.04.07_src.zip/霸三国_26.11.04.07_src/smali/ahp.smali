.class public Lahp;
.super Ljava/lang/Object;


# instance fields
.field private a:Lakd;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lakd;)V
    .locals 0

    iput-object p1, p0, Lahp;->a:Lakd;

    return-void
.end method
