.class public Laqr;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lbyq;

.field private b:Laqp;

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I


# direct methods
.method public constructor <init>(ILaqg;Lbyr;Ljava/util/Hashtable;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->h(I)[Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    array-length v0, v1

    new-array v0, v0, [Lbyq;

    iput-object v0, p0, Laqr;->a:[Lbyq;

    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Laqr;->a:[Lbyq;

    array-length v2, v2

    if-ge v0, v2, :cond_0

    iget-object v2, p0, Laqr;->a:[Lbyq;

    new-instance v3, Lbyq;

    aget-object v4, v1, v0

    invoke-virtual {p3, v4}, Lbyr;->b(Ljava/lang/String;)I

    move-result v4

    invoke-direct {v3, v4, p3, p4}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    aput-object v3, v2, v0

    iget-object v2, p0, Laqr;->a:[Lbyq;

    aget-object v2, v2, v0

    invoke-static {v2, p4}, Lbvy;->a(Lbyq;Ljava/util/Hashtable;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->i(I)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p2, v0}, Laqg;->a(I)Laqp;

    move-result-object v0

    iput-object v0, p0, Laqr;->b:Laqp;

    :cond_1
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->j(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laqr;->c:Ljava/lang/String;

    iget-object v0, p0, Laqr;->c:Ljava/lang/String;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laqr;->c:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_2

    iget-object v0, p0, Laqr;->c:Ljava/lang/String;

    invoke-static {v0, p3, p4}, Lbvy;->a(Ljava/lang/String;Lbyr;Ljava/util/Hashtable;)V

    :cond_2
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->k(I)I

    move-result v0

    iput v0, p0, Laqr;->d:I

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p1}, Laqj;->l(I)I

    move-result v0

    iput v0, p0, Laqr;->e:I

    return-void
.end method


# virtual methods
.method public a()[Lbyq;
    .locals 1

    iget-object v0, p0, Laqr;->a:[Lbyq;

    return-object v0
.end method

.method public b()Laqp;
    .locals 1

    iget-object v0, p0, Laqr;->b:Laqp;

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqr;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d()I
    .locals 1

    iget v0, p0, Laqr;->d:I

    return v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Laqr;->e:I

    return v0
.end method
