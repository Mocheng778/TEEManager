.class public Laed;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lalo;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lalo;)V
    .locals 0

    iput-object p1, p0, Laed;->a:[Lalo;

    return-void
.end method

.method public a()[Lalo;
    .locals 1

    iget-object v0, p0, Laed;->a:[Lalo;

    return-object v0
.end method
