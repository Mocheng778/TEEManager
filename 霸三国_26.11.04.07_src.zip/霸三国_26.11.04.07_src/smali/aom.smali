.class public Laom;
.super Ljava/lang/Object;

# interfaces
.implements Lbzx;


# instance fields
.field protected a:Ljava/net/Socket;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v0

    new-instance v1, Ljava/net/Socket;

    invoke-direct {v1, v0, p2}, Ljava/net/Socket;-><init>(Ljava/net/InetAddress;I)V

    iput-object v1, p0, Laom;->a:Ljava/net/Socket;

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    return-void
.end method

.method public a(BI)V
    .locals 4

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isClosed()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    throw v0

    :cond_0
    packed-switch p1, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    :pswitch_0
    if-nez p2, :cond_1

    move v0, v1

    :goto_0
    iget-object v3, p0, Laom;->a:Ljava/net/Socket;

    if-eqz v0, :cond_8

    :goto_1
    invoke-virtual {v3, v2}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    :goto_2
    return-void

    :cond_1
    move v0, v2

    goto :goto_0

    :pswitch_1
    if-gez p2, :cond_2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    :cond_2
    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    if-eqz p2, :cond_7

    :goto_3
    invoke-virtual {v0, v2, p2}, Ljava/net/Socket;->setSoLinger(ZI)V

    goto :goto_2

    :pswitch_2
    if-nez p2, :cond_3

    move v0, v1

    :goto_4
    iget-object v3, p0, Laom;->a:Ljava/net/Socket;

    if-eqz v0, :cond_6

    :goto_5
    invoke-virtual {v3, v2}, Ljava/net/Socket;->setKeepAlive(Z)V

    goto :goto_2

    :cond_3
    move v0, v2

    goto :goto_4

    :pswitch_3
    if-gtz p2, :cond_4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    :cond_4
    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0, p2}, Ljava/net/Socket;->setReceiveBufferSize(I)V

    goto :goto_2

    :pswitch_4
    if-gtz p2, :cond_5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    :cond_5
    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0, p2}, Ljava/net/Socket;->setSendBufferSize(I)V

    goto :goto_2

    :cond_6
    move v2, v1

    goto :goto_5

    :cond_7
    move v2, v1

    goto :goto_3

    :cond_8
    move v2, v1

    goto :goto_1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public b()Ljava/io/DataInputStream;
    .locals 2

    invoke-virtual {p0}, Laom;->d()Ljava/io/InputStream;

    move-result-object v0

    new-instance v1, Ljava/io/DataInputStream;

    invoke-direct {v1, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    return-object v1
.end method

.method public c()Ljava/io/DataOutputStream;
    .locals 2

    invoke-virtual {p0}, Laom;->e()Ljava/io/OutputStream;

    move-result-object v0

    new-instance v1, Ljava/io/DataOutputStream;

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    return-object v1
.end method

.method public d()Ljava/io/InputStream;
    .locals 1

    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    return-object v0
.end method

.method public e()Ljava/io/OutputStream;
    .locals 1

    iget-object v0, p0, Laom;->a:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    return-object v0
.end method
