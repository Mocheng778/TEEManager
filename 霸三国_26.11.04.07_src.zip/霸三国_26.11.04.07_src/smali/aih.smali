.class public Laih;
.super Ljava/lang/Object;


# instance fields
.field private a:Lalv;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalv;
    .locals 1

    iget-object v0, p0, Laih;->a:Lalv;

    return-object v0
.end method

.method public a(Lalv;)V
    .locals 0

    iput-object p1, p0, Laih;->a:Lalv;

    return-void
.end method
