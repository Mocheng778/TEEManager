.class public Lags;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:J

.field private b:J

.field private c:I

.field private d:J

.field private e:J

.field private f:I

.field private g:I

.field private h:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lags;->c:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lags;->a:J

    return-void
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lags;->f:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lags;->b:J

    return-void
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lags;->g:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lags;->d:J

    return-void
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lags;->h:I

    return-void
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lags;->e:J

    return-void
.end method
