.class public Laou;
.super Ljava/lang/Object;

# interfaces
.implements Lbov;
.implements Lcom/plugin/ReceiveCallBack;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Lbow;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Laov;

    invoke-direct {v0, p0}, Laov;-><init>(Laou;)V

    iput-object v0, p0, Laou;->e:Lbow;

    return-void
.end method

.method static synthetic a(Laou;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laou;->d:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public a()V
    .locals 2

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------connectionFail()"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public b()V
    .locals 3

    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    invoke-virtual {v0}, Lboo;->a()Ladg;

    move-result-object v0

    sget-object v1, Lcom/lszb/GameMIDlet;->a:Ljava/lang/String;

    iget v2, p0, Laou;->a:I

    invoke-virtual {v0, v1, v2}, Ladg;->a(Ljava/lang/String;I)V

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------connectionSuccess()"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public c()V
    .locals 2

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------connectionBroken()"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method

.method public destroy()V
    .locals 2

    invoke-static {}, Ladr;->a()Lframework/server/game/IPlatHandlerManager;

    move-result-object v0

    iget-object v1, p0, Laou;->e:Lbow;

    invoke-interface {v0, v1}, Lframework/server/game/IPlatHandlerManager;->removeHandler(Ladf;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    invoke-virtual {v0, p0}, Lboo;->b(Lbov;)V

    return-void
.end method

.method public init()V
    .locals 0

    return-void
.end method

.method public register(Ljava/lang/String;)V
    .locals 3

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "DataReceive----------------------registerId:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    iput-object p1, p0, Laou;->d:Ljava/lang/String;

    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    invoke-virtual {v0, p0}, Lboo;->a(Lbov;)V

    invoke-static {}, Ladr;->a()Lframework/server/game/IPlatHandlerManager;

    move-result-object v0

    iget-object v1, p0, Laou;->e:Lbow;

    invoke-interface {v0, v1}, Lframework/server/game/IPlatHandlerManager;->addHandler(Ladf;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    invoke-virtual {v0}, Lboo;->h()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------connect success"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    invoke-virtual {p0}, Laou;->b()V

    :goto_0
    return-void

    :cond_0
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->m()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "ip.txt"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf-8"

    invoke-static {v0, v1}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    const-string v1, "ip"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Laou;->b:Ljava/lang/String;

    const-string v1, "port"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laou;->c:I

    const-string v1, "cp"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laou;->a:I

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------connect to server"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    iget-object v1, p0, Laou;->b:Ljava/lang/String;

    iget v2, p0, Laou;->c:I

    invoke-virtual {v0, v1, v2}, Lboo;->a(Ljava/lang/String;I)V

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1
.end method

.method public unregister(Ljava/lang/String;)V
    .locals 0

    return-void
.end method
