.class public Lahl;
.super Ljava/lang/Object;


# instance fields
.field private a:Lajw;

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lajw;
    .locals 1

    iget-object v0, p0, Lahl;->a:Lajw;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lahl;->b:I

    return-void
.end method

.method public a(Lajw;)V
    .locals 0

    iput-object p1, p0, Lahl;->a:Lajw;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lahl;->b:I

    return v0
.end method
