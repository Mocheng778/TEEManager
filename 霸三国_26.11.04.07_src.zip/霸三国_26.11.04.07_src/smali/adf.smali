.class public interface abstract Ladf;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Laej;)V
.end method

.method public abstract a(Lafz;)V
.end method

.method public abstract a(Lahe;)V
.end method

.method public abstract b(Laej;)V
.end method

.method public abstract b(Lafz;)V
.end method

.method public abstract c(Laej;)V
.end method

.method public abstract c(Lafz;)V
.end method

.method public abstract d(Lafz;)V
.end method

.method public abstract e(Lafz;)V
.end method

.method public abstract f(Lafz;)V
.end method
