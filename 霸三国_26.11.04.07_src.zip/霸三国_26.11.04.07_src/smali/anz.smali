.class Lanz;
.super Laod;


# instance fields
.field final synthetic a:Lany;


# direct methods
.method constructor <init>(Lany;I)V
    .locals 0

    iput-object p1, p0, Lanz;->a:Lany;

    invoke-direct {p0, p2}, Laod;-><init>(I)V

    return-void
.end method


# virtual methods
.method protected a(Ljava/lang/String;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p1}, Lcas;->a(Ljava/lang/String;)Lcas;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v0

    :goto_0
    return-object v0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method
