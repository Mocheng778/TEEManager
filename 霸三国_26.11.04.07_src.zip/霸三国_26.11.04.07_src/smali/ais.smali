.class public Lais;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Lalj;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lais;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lais;->a:I

    return-void
.end method

.method public a(Lalj;)V
    .locals 0

    iput-object p1, p0, Lais;->b:Lalj;

    return-void
.end method

.method public b()Lalj;
    .locals 1

    iget-object v0, p0, Lais;->b:Lalj;

    return-object v0
.end method
