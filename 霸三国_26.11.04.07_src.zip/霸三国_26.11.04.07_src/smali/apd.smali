.class public Lapd;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private final g:Ljava/lang/String;

.field private final h:Ljava/lang/String;

.field private i:Lbxf;

.field private j:Lcom/lzlm/component/ButtonComponent;

.field private k:Ljava/lang/Object;

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;

.field private o:Ljava/lang/String;

.field private p:Ljava/lang/String;

.field private q:Lbyq;

.field private r:Lapf;

.field private s:Lajn;


# direct methods
.method public constructor <init>(Lajn;Lapf;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "\u884c"

    iput-object v0, p0, Lapd;->a:Ljava/lang/String;

    const-string v0, "\u5934\u50cf"

    iput-object v0, p0, Lapd;->b:Ljava/lang/String;

    const-string v0, "\u56fd\u5bb6"

    iput-object v0, p0, Lapd;->c:Ljava/lang/String;

    const-string v0, "\u540d\u5b57"

    iput-object v0, p0, Lapd;->d:Ljava/lang/String;

    const-string v0, "\u7b49\u7ea7"

    iput-object v0, p0, Lapd;->e:Ljava/lang/String;

    const-string v0, "\u519b\u56e2"

    iput-object v0, p0, Lapd;->f:Ljava/lang/String;

    const-string v0, "\u6392\u884c"

    iput-object v0, p0, Lapd;->g:Ljava/lang/String;

    const-string v0, "\u6311\u6218"

    iput-object v0, p0, Lapd;->h:Ljava/lang/String;

    iput-object p1, p0, Lapd;->s:Lajn;

    iput-object p2, p0, Lapd;->r:Lapf;

    return-void
.end method

.method static synthetic a(Lapd;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapd;->l:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic b(Lapd;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapd;->n:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic c(Lapd;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapd;->m:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic d(Lapd;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapd;->o:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic e(Lapd;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapd;->p:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public a(II)V
    .locals 3

    iget-object v0, p0, Lapd;->i:Lbxf;

    iget-object v1, p0, Lapd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lapd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Lapd;->k:Ljava/lang/Object;

    iget-object v0, p0, Lapd;->k:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapd;->k:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->m()V

    :cond_0
    return-void
.end method

.method public a(IILjava/util/Hashtable;Lbxl;Lanx;)V
    .locals 4

    :try_start_0
    new-instance v1, Lbxr;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "arena_main_row.bin"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p3, p4}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    invoke-static {v1, p3}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    iget-object v0, p0, Lapd;->s:Lajn;

    invoke-virtual {v0}, Lajn;->h()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapd;->l:Ljava/lang/String;

    iget-object v0, p0, Lapd;->s:Lajn;

    invoke-virtual {v0}, Lajn;->e()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapd;->o:Ljava/lang/String;

    iget-object v0, p0, Lapd;->o:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, ""

    iput-object v0, p0, Lapd;->o:Ljava/lang/String;

    :cond_0
    iget-object v0, p0, Lapd;->s:Lajn;

    invoke-virtual {v0}, Lajn;->d()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapd;->m:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->h()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "ui-arena.properties"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "UTF-8"

    invoke-static {v0, v2}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    const-string v2, "\u7b49\u7ea7"

    invoke-virtual {v0, v2}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "${level}"

    iget-object v3, p0, Lapd;->s:Lajn;

    invoke-virtual {v3}, Lajn;->g()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v2, v3}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapd;->n:Ljava/lang/String;

    iget-object v0, p0, Lapd;->s:Lajn;

    invoke-virtual {v0}, Lajn;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapd;->p:Ljava/lang/String;

    new-instance v2, Lape;

    invoke-direct {v2, p0}, Lape;-><init>(Lapd;)V

    const-string v0, "\u884c"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lapd;->i:Lbxf;

    iget-object v0, p0, Lapd;->i:Lbxf;

    invoke-virtual {v0, p1}, Lbxf;->e(I)V

    iget-object v0, p0, Lapd;->i:Lbxf;

    invoke-virtual {v0, p2}, Lbxf;->f(I)V

    const-string v0, "\u6311\u6218"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    iput-object v0, p0, Lapd;->j:Lcom/lzlm/component/ButtonComponent;

    const-string v0, "\u540d\u5b57"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v0, "\u7b49\u7ea7"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v0, "\u56fd\u5bb6"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v0, "\u519b\u56e2"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v0, "\u6392\u884c"

    invoke-virtual {v1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    invoke-static {}, Lbtn;->a()Lbtn;

    move-result-object v0

    iget-object v2, p0, Lapd;->s:Lajn;

    invoke-virtual {v2}, Lajn;->b()I

    move-result v2

    invoke-virtual {v0, v2, p3}, Lbtn;->a(ILjava/util/Hashtable;)Lbyq;

    move-result-object v0

    iput-object v0, p0, Lapd;->q:Lbyq;

    iget-object v0, p0, Lapd;->q:Lbyq;

    invoke-static {v0, p3}, Lbvy;->a(Lbyq;Ljava/util/Hashtable;)V

    const-string v0, "\u5934\u50cf"

    iget-object v2, p0, Lapd;->q:Lbyq;

    invoke-static {p3, v1, v0, v2, p5}, Lbvw;->a(Ljava/util/Hashtable;Lbxr;Ljava/lang/String;Lbyq;Lanx;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public a(Lcar;II)V
    .locals 3

    iget-object v0, p0, Lapd;->i:Lbxf;

    iget-object v1, p0, Lapd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Lapd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void
.end method

.method public a(Z)V
    .locals 1

    iget-object v0, p0, Lapd;->j:Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0, p1}, Lcom/lzlm/component/ButtonComponent;->a(Z)V

    return-void
.end method

.method public b(II)V
    .locals 3

    iget-object v0, p0, Lapd;->i:Lbxf;

    iget-object v1, p0, Lapd;->i:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lapd;->i:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Lapd;->k:Ljava/lang/Object;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lapd;->k:Ljava/lang/Object;

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lapd;->k:Ljava/lang/Object;

    instance-of v1, v1, Lcom/lzlm/component/ButtonComponent;

    if-eqz v1, :cond_0

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    const-string v1, "\u6311\u6218"

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapd;->r:Lapf;

    iget-object v1, p0, Lapd;->s:Lajn;

    invoke-interface {v0, v1}, Lapf;->a(Lajn;)V

    :cond_0
    iget-object v0, p0, Lapd;->k:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lapd;->k:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->n()V

    :cond_1
    return-void
.end method
