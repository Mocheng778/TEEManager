.class Laoc;
.super Ljava/lang/Object;

# interfaces
.implements Lanx;


# instance fields
.field final synthetic a:Lany;


# direct methods
.method constructor <init>(Lany;)V
    .locals 0

    iput-object p1, p0, Laoc;->a:Lany;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
