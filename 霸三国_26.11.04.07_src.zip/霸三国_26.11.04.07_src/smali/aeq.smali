.class public Laeq;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Laku;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Laku;)V
    .locals 0

    iput-object p1, p0, Laeq;->a:[Laku;

    return-void
.end method

.method public a()[Laku;
    .locals 1

    iget-object v0, p0, Laeq;->a:[Laku;

    return-object v0
.end method
