.class public Lagz;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:Lank;

.field private j:I

.field private k:I

.field private l:I

.field private m:Z

.field private n:Z

.field private o:Z

.field private p:Z

.field private q:Z

.field private r:Z

.field private s:[Ljava/lang/String;

.field private t:[I

.field private u:[Lank;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagz;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagz;->a:I

    return-void
.end method

.method public a(Lank;)V
    .locals 0

    iput-object p1, p0, Lagz;->i:Lank;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->m:Z

    return-void
.end method

.method public a([I)V
    .locals 0

    iput-object p1, p0, Lagz;->t:[I

    return-void
.end method

.method public a([Lank;)V
    .locals 0

    iput-object p1, p0, Lagz;->u:[Lank;

    return-void
.end method

.method public a([Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagz;->s:[Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lagz;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagz;->b:I

    return-void
.end method

.method public b(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->n:Z

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lagz;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lagz;->c:I

    return-void
.end method

.method public c(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->o:Z

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lagz;->d:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lagz;->d:I

    return-void
.end method

.method public d(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->p:Z

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lagz;->e:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lagz;->e:I

    return-void
.end method

.method public e(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->q:Z

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lagz;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lagz;->f:I

    return-void
.end method

.method public f(Z)V
    .locals 0

    iput-boolean p1, p0, Lagz;->r:Z

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lagz;->g:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lagz;->g:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lagz;->h:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lagz;->h:I

    return-void
.end method

.method public i()Lank;
    .locals 1

    iget-object v0, p0, Lagz;->i:Lank;

    return-object v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lagz;->j:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lagz;->j:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lagz;->k:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lagz;->k:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lagz;->l:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lagz;->l:I

    return v0
.end method

.method public m()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->m:Z

    return v0
.end method

.method public n()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->n:Z

    return v0
.end method

.method public o()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->o:Z

    return v0
.end method

.method public p()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->p:Z

    return v0
.end method

.method public q()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->q:Z

    return v0
.end method

.method public r()Z
    .locals 1

    iget-boolean v0, p0, Lagz;->r:Z

    return v0
.end method

.method public s()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagz;->s:[Ljava/lang/String;

    return-object v0
.end method

.method public t()[I
    .locals 1

    iget-object v0, p0, Lagz;->t:[I

    return-object v0
.end method

.method public u()[Lank;
    .locals 1

    iget-object v0, p0, Lagz;->u:[Lank;

    return-object v0
.end method
