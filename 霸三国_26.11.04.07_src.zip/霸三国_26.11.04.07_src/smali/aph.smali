.class public Laph;
.super Lbwj;


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:I

.field final synthetic c:Lcom/lszb/arena/view/ArenaMainView;


# direct methods
.method public constructor <init>(Lcom/lszb/arena/view/ArenaMainView;Ljava/lang/String;I)V
    .locals 0

    iput-object p1, p0, Laph;->c:Lcom/lszb/arena/view/ArenaMainView;

    iput-object p2, p0, Laph;->a:Ljava/lang/String;

    iput p3, p0, Laph;->b:I

    invoke-direct {p0}, Lbwj;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laph;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(Lcom/lszb/view/ConfirmDialogView;)V
    .locals 3

    invoke-static {}, Lbtl;->a()Lbtl;

    move-result-object v0

    invoke-virtual {v0}, Lbtl;->c()Lamq;

    move-result-object v0

    invoke-virtual {v0}, Lamq;->e()I

    move-result v0

    iget v1, p0, Laph;->b:I

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Laph;->c:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Laph;->c:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v2}, Lcom/lszb/arena/view/ArenaMainView;->d(Lcom/lszb/arena/view/ArenaMainView;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Laph;->c:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/LoadingView;

    invoke-direct {v1}, Lcom/lszb/view/LoadingView;-><init>()V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-virtual {v0}, Lmm;->e()V

    goto :goto_0
.end method
