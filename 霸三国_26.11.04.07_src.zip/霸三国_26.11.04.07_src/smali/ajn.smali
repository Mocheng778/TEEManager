.class public Lajn;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:I

.field private g:I

.field private h:Ljava/lang/String;

.field private i:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lajn;->i:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lajn;->i:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lajn;->d:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lajn;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lajn;->b:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lajn;->e:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lajn;->b:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lajn;->a:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lajn;->h:Ljava/lang/String;

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lajn;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lajn;->c:I

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lajn;->e:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lajn;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lajn;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lajn;->g:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lajn;->g:I

    return v0
.end method

.method public h()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lajn;->h:Ljava/lang/String;

    return-object v0
.end method
