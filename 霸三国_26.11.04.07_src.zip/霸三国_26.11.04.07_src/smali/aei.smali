.class public Laei;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:J

.field private b:I

.field private c:J

.field private d:J

.field private e:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()J
    .locals 2

    iget-wide v0, p0, Laei;->a:J

    return-wide v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laei;->b:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laei;->a:J

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laei;->b:I

    return v0
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Laei;->c:J

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Laei;->c:J

    return-wide v0
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Laei;->d:J

    return-void
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Laei;->d:J

    return-wide v0
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Laei;->e:J

    return-void
.end method

.method public e()J
    .locals 2

    iget-wide v0, p0, Laei;->e:J

    return-wide v0
.end method
