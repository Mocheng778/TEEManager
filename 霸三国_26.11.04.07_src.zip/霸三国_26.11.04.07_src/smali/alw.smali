.class public Lalw;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:I

.field private k:I

.field private l:I

.field private m:I

.field private n:Ljava/lang/String;

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalw;->b:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalw;->c:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalw;->b:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lalw;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lalw;->d:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalw;->h:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lalw;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lalw;->e:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalw;->n:Ljava/lang/String;

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalw;->h:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lalw;->f:I

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalw;->i:Ljava/lang/String;

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalw;->n:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lalw;->a:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lalw;->e:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lalw;->g:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lalw;->f:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lalw;->j:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lalw;->a:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lalw;->k:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lalw;->g:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lalw;->l:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lalw;->j:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lalw;->m:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lalw;->k:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lalw;->o:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lalw;->l:I

    return v0
.end method

.method public l(I)V
    .locals 0

    iput p1, p0, Lalw;->q:I

    return-void
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lalw;->m:I

    return v0
.end method

.method public m(I)V
    .locals 0

    iput p1, p0, Lalw;->p:I

    return-void
.end method

.method public n()I
    .locals 1

    iget v0, p0, Lalw;->o:I

    return v0
.end method

.method public n(I)V
    .locals 0

    iput p1, p0, Lalw;->r:I

    return-void
.end method

.method public o()I
    .locals 1

    iget v0, p0, Lalw;->q:I

    return v0
.end method

.method public o(I)V
    .locals 0

    iput p1, p0, Lalw;->s:I

    return-void
.end method

.method public p()I
    .locals 1

    iget v0, p0, Lalw;->r:I

    return v0
.end method

.method public p(I)V
    .locals 0

    iput p1, p0, Lalw;->t:I

    return-void
.end method

.method public q()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalw;->i:Ljava/lang/String;

    return-object v0
.end method

.method public q(I)V
    .locals 0

    iput p1, p0, Lalw;->u:I

    return-void
.end method

.method public r()I
    .locals 1

    iget v0, p0, Lalw;->s:I

    return v0
.end method
