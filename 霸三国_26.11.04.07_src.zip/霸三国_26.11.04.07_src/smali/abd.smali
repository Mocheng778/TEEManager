.class public Labd;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lalt;Ljava/io/DataInputStream;)V
    .locals 2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lajp;

    invoke-direct {v0}, Lajp;-><init>()V

    invoke-static {v0, p1}, Lza;->a(Lajp;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lalt;->a(Lajp;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lajt;

    invoke-direct {v0}, Lajt;-><init>()V

    invoke-static {v0, p1}, Lze;->a(Lajt;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lalt;->a(Lajt;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lalt;->a(J)V

    return-void
.end method
