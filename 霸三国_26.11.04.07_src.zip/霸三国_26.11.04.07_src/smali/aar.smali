.class public Laar;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lalh;Ljava/io/DataInputStream;)V
    .locals 4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Laka;

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_0

    new-instance v3, Laka;

    invoke-direct {v3}, Laka;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Lzl;->a(Laka;Ljava/io/DataInputStream;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v2}, Lalh;->a([Laka;)V

    :cond_2
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v0, v0, [Lakt;

    :goto_1
    array-length v2, v0

    if-ge v1, v2, :cond_4

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_3

    new-instance v2, Lakt;

    invoke-direct {v2}, Lakt;-><init>()V

    aput-object v2, v0, v1

    aget-object v2, v0, v1

    invoke-static {v2, p1}, Laae;->a(Lakt;Ljava/io/DataInputStream;)V

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    invoke-virtual {p0, v0}, Lalh;->a([Lakt;)V

    :cond_5
    return-void
.end method
