.class public Laqq;
.super Laqs;


# instance fields
.field private a:D

.field private b:D


# direct methods
.method public constructor <init>(Lbyw;Laqo;ILjava/lang/String;III[[Lbyq;Lbyq;Laqr;Laqr;II)V
    .locals 2

    invoke-direct/range {p0 .. p11}, Laqs;-><init>(Lbyw;Laqo;ILjava/lang/String;III[[Lbyq;Lbyq;Laqr;Laqr;)V

    int-to-double v0, p12

    iput-wide v0, p0, Laqq;->a:D

    int-to-double v0, p13

    iput-wide v0, p0, Laqq;->b:D

    return-void
.end method


# virtual methods
.method public a(Laqr;DD)V
    .locals 8

    new-instance v0, Larz;

    invoke-virtual {p1}, Laqr;->a()[Lbyq;

    move-result-object v6

    invoke-virtual {p1}, Laqr;->b()Laqp;

    move-result-object v7

    move-object v1, p0

    move-wide v2, p2

    move-wide v4, p4

    invoke-direct/range {v0 .. v7}, Larz;-><init>(Laqq;DD[Lbyq;Laqp;)V

    invoke-virtual {p0, v0}, Laqq;->a(Lasc;)V

    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v0

    invoke-virtual {p1}, Laqr;->d()I

    move-result v1

    invoke-virtual {v0, v1}, Lbmh;->b(I)V

    return-void
.end method

.method public d()D
    .locals 2

    iget-wide v0, p0, Laqq;->a:D

    return-wide v0
.end method

.method public e()D
    .locals 2

    iget-wide v0, p0, Laqq;->b:D

    return-wide v0
.end method
