.class public Laju;
.super Ljava/lang/Object;


# instance fields
.field private a:Laks;

.field private b:Lamx;

.field private c:Lamy;

.field private d:Lajs;

.field private e:Lanc;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Laks;
    .locals 1

    iget-object v0, p0, Laju;->a:Laks;

    return-object v0
.end method

.method public a(Lajs;)V
    .locals 0

    iput-object p1, p0, Laju;->d:Lajs;

    return-void
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Laju;->a:Laks;

    return-void
.end method

.method public a(Lamx;)V
    .locals 0

    iput-object p1, p0, Laju;->b:Lamx;

    return-void
.end method

.method public a(Lamy;)V
    .locals 0

    iput-object p1, p0, Laju;->c:Lamy;

    return-void
.end method

.method public a(Lanc;)V
    .locals 0

    iput-object p1, p0, Laju;->e:Lanc;

    return-void
.end method

.method public b()Lamx;
    .locals 1

    iget-object v0, p0, Laju;->b:Lamx;

    return-object v0
.end method

.method public c()Lamy;
    .locals 1

    iget-object v0, p0, Laju;->c:Lamy;

    return-object v0
.end method

.method public d()Lajs;
    .locals 1

    iget-object v0, p0, Laju;->d:Lajs;

    return-object v0
.end method

.method public e()Lanc;
    .locals 1

    iget-object v0, p0, Laju;->e:Lanc;

    return-object v0
.end method
