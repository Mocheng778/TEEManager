.class public Ladv;
.super Ljava/lang/Object;

# interfaces
.implements Lframework/server/game/IReader;


# instance fields
.field final synthetic a:Ladt;


# direct methods
.method public constructor <init>(Ladt;)V
    .locals 0

    iput-object p1, p0, Ladv;->a:Ladt;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public read(Ljava/io/DataInputStream;)V
    .locals 2

    new-instance v0, Laej;

    invoke-direct {v0}, Laej;-><init>()V

    invoke-static {v0, p1}, Lframework/server/game/ControllerResponse;->read(Lframework/server/game/ControllerResponse;Ljava/io/DataInputStream;)V

    iget-object v1, p0, Ladv;->a:Ladt;

    invoke-static {v1}, Ladt;->a(Ladt;)Lads;

    move-result-object v1

    invoke-interface {v1, v0}, Lads;->a(Laej;)V

    return-void
.end method
