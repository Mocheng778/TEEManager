.class public Lakn;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lakn;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakn;->a:I

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lakn;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakn;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakn;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakn;->c:I

    return-void
.end method
