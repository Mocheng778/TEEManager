.class public LCrossServerBattleOverviewReader;
.super Ljava/lang/Object;

# interfaces
.implements Lframework/server/game/IReader;


# instance fields
.field final synthetic a:Lmm;


# direct methods
.method public constructor <init>(Lmm;)V
    .locals 0

    iput-object p1, p0, LCrossServerBattleOverviewReader;->a:Lmm;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public read(Ljava/io/DataInputStream;)V
    .locals 5

    new-instance v0, Lafc;

    invoke-direct {v0}, Lafc;-><init>()V

    invoke-static {v0, p1}, Lframework/server/game/ControllerResponse;->read(Lframework/server/game/ControllerResponse;Ljava/io/DataInputStream;)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lafc;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    invoke-virtual {v0, v1}, Lafc;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    invoke-virtual {v0, v1}, Lafc;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lafc;->b(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lafc;->b(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v1

    invoke-virtual {v0, v1}, Lafc;->a(Z)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lafc;->a(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    new-array v2, v1, [Lalb;

    const/4 v1, 0x0

    :goto_0
    array-length v3, v2

    if-ge v1, v3, :cond_3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_2

    new-instance v3, Lalb;

    invoke-direct {v3}, Lalb;-><init>()V

    aput-object v3, v2, v1

    invoke-static {v3, p1}, Laam;->a(Lalb;Ljava/io/DataInputStream;)V

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {v0, v2}, Lafc;->a([Lalb;)V

    :cond_4
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    new-array v2, v1, [Lalb;

    const/4 v1, 0x0

    :goto_1
    array-length v3, v2

    if-ge v1, v3, :cond_6

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_5

    new-instance v3, Lalb;

    invoke-direct {v3}, Lalb;-><init>()V

    aput-object v3, v2, v1

    invoke-static {v3, p1}, Laam;->a(Lalb;Ljava/io/DataInputStream;)V

    :cond_5
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_6
    invoke-virtual {v0, v2}, Lafc;->b([Lalb;)V

    :cond_7
    iget-object v1, p0, LCrossServerBattleOverviewReader;->a:Lmm;

    invoke-static {v1}, Lmm;->a(Lmm;)Lyv;

    move-result-object v1

    invoke-interface {v1, v0}, Lyv;->b(Lafc;)V

    return-void
.end method
