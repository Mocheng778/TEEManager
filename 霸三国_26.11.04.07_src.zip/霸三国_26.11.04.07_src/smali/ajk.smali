.class public Lajk;
.super Ljava/lang/Object;


# direct methods
.method public static final a(I)I
    .locals 0

    return p0
.end method
