.class public Lasb;
.super Lasc;


# direct methods
.method public constructor <init>(Laqs;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Laqs;->b(I)[Lbyq;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lasc;-><init>(Laqs;[Lbyq;)V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    invoke-virtual {p0}, Lasb;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lbyq;->b()V

    :cond_0
    return-void
.end method
