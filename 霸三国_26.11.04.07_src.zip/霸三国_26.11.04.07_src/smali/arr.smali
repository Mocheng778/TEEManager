.class public Larr;
.super Lars;


# instance fields
.field private b:Lajt;

.field private c:Z

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>([Lamz;Lajt;Z)V
    .locals 2

    invoke-virtual {p2}, Lajt;->d()Laju;

    move-result-object v0

    invoke-static {v0}, Larr;->a(Laju;)I

    move-result v0

    invoke-direct {p0, v0, p1}, Lars;-><init>(I[Lamz;)V

    iput-object p2, p0, Larr;->b:Lajt;

    iput-boolean p3, p0, Larr;->c:Z

    invoke-virtual {p2}, Lajt;->d()Laju;

    move-result-object v0

    invoke-virtual {v0}, Laju;->b()Lamx;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-static {}, Laxc;->a()Laxc;

    move-result-object v1

    invoke-virtual {v0}, Laju;->b()Lamx;

    move-result-object v0

    invoke-virtual {v0}, Lamx;->c()I

    move-result v0

    invoke-virtual {v1, v0}, Laxc;->a(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Larr;->d:Ljava/lang/String;

    :cond_0
    :goto_0
    return-void

    :cond_1
    invoke-virtual {v0}, Laju;->a()Laks;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Laju;->a()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->e()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Larr;->d:Ljava/lang/String;

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Laju;->c()Lamy;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-static {}, Lazo;->a()Lazo;

    move-result-object v1

    invoke-virtual {v0}, Laju;->c()Lamy;

    move-result-object v0

    invoke-virtual {v0}, Lamy;->a()I

    move-result v0

    invoke-virtual {v1, v0}, Lazo;->b(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Larr;->d:Ljava/lang/String;

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Laju;->d()Lajs;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Laju;->d()Lajs;

    move-result-object v0

    invoke-virtual {v0}, Lajs;->b()Lams;

    move-result-object v0

    invoke-virtual {v0}, Lams;->b()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Larr;->d:Ljava/lang/String;

    goto :goto_0
.end method

.method private static a(Laju;)I
    .locals 1

    invoke-virtual {p0}, Laju;->b()Lamx;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    return v0

    :cond_0
    invoke-virtual {p0}, Laju;->a()Laks;

    move-result-object v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Laju;->c()Lamy;

    move-result-object v0

    if-eqz v0, :cond_2

    const/4 v0, 0x2

    goto :goto_0

    :cond_2
    const/4 v0, 0x3

    goto :goto_0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larr;->d:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 5

    invoke-static {}, Lbku;->a()Lbku;

    move-result-object v0

    invoke-virtual {v0}, Lbku;->b()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Larr;->b:Lajt;

    invoke-virtual {v1}, Lajt;->i()I

    move-result v1

    iget-boolean v2, p0, Larr;->c:Z

    invoke-static {}, Latt;->a()Latt;

    move-result-object v3

    invoke-virtual {v3}, Latt;->k()Laks;

    move-result-object v3

    invoke-virtual {v3}, Laks;->d()I

    move-result v3

    invoke-virtual {p0, p1}, Larr;->c([Lakw;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lmm;->a(IZILjava/lang/String;)V

    :goto_0
    return-void

    :cond_0
    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Larr;->b:Lajt;

    invoke-virtual {v1}, Lajt;->i()I

    move-result v1

    iget-boolean v2, p0, Larr;->c:Z

    invoke-static {}, Latt;->a()Latt;

    move-result-object v3

    invoke-virtual {v3}, Latt;->h()I

    move-result v3

    invoke-virtual {p0, p1}, Larr;->c([Lakw;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lmm;->a(IZILjava/lang/String;)V

    goto :goto_0
.end method

.method public b([Lakw;)I
    .locals 7

    const/4 v1, 0x0

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    aget-object v2, p1, v1

    invoke-virtual {v2}, Lakw;->x()I

    move-result v2

    invoke-virtual {v0, v2}, Latt;->a(I)Lakr;

    move-result-object v0

    iget-object v2, p0, Larr;->b:Lajt;

    invoke-virtual {v2}, Lajt;->d()Laju;

    move-result-object v2

    invoke-virtual {v2}, Laju;->b()Lamx;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {v2}, Laju;->b()Lamx;

    move-result-object v3

    invoke-virtual {v3}, Lamx;->h()I

    move-result v4

    invoke-virtual {v2}, Laju;->b()Lamx;

    move-result-object v2

    invoke-virtual {v2}, Lamx;->i()I

    move-result v5

    :goto_0
    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->i()I

    move-result v2

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->j()I

    move-result v3

    move-object v0, p0

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Larr;->a(ZIIII[Lakw;)I

    move-result v0

    return v0

    :cond_0
    invoke-virtual {v2}, Laju;->a()Laks;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Laju;->a()Laks;

    move-result-object v3

    invoke-virtual {v3}, Laks;->i()I

    move-result v4

    invoke-virtual {v2}, Laju;->a()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->j()I

    move-result v5

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, Laju;->c()Lamy;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v2}, Laju;->c()Lamy;

    move-result-object v3

    invoke-virtual {v3}, Lamy;->b()I

    move-result v4

    invoke-virtual {v2}, Laju;->c()Lamy;

    move-result-object v2

    invoke-virtual {v2}, Lamy;->c()I

    move-result v5

    goto :goto_0

    :cond_2
    invoke-virtual {v2}, Laju;->d()Lajs;

    move-result-object v3

    if-eqz v3, :cond_3

    invoke-virtual {v2}, Laju;->d()Lajs;

    move-result-object v3

    invoke-virtual {v3}, Lajs;->a()Lamy;

    move-result-object v3

    invoke-virtual {v3}, Lamy;->b()I

    move-result v4

    invoke-virtual {v2}, Laju;->d()Lajs;

    move-result-object v2

    invoke-virtual {v2}, Lajs;->a()Lamy;

    move-result-object v2

    invoke-virtual {v2}, Lamy;->c()I

    move-result v5

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->i()I

    move-result v4

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->j()I

    move-result v5

    goto :goto_0
.end method
