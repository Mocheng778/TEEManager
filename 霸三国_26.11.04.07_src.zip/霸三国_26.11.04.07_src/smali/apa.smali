.class public interface abstract Lapa;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Laoj;)V
.end method
