.class public Lafj;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:J

.field private c:I

.field private d:I

.field private e:I

.field private f:[Lali;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lafj;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafj;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lafj;->b:J

    return-void
.end method

.method public a([Lali;)V
    .locals 0

    iput-object p1, p0, Lafj;->f:[Lali;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafj;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafj;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lafj;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lafj;->d:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lafj;->e:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lafj;->e:I

    return-void
.end method

.method public e()[Lali;
    .locals 1

    iget-object v0, p0, Lafj;->f:[Lali;

    return-object v0
.end method
