.class public Lagg;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lakf;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lakf;)V
    .locals 0

    iput-object p1, p0, Lagg;->a:[Lakf;

    return-void
.end method

.method public a()[Lakf;
    .locals 1

    iget-object v0, p0, Lagg;->a:[Lakf;

    return-object v0
.end method
