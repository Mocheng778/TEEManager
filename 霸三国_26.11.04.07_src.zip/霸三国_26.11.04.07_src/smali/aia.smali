.class public Laia;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Lakw;

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laia;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laia;->a:I

    return-void
.end method

.method public a(Lakw;)V
    .locals 0

    iput-object p1, p0, Laia;->b:Lakw;

    return-void
.end method

.method public b()Lakw;
    .locals 1

    iget-object v0, p0, Laia;->b:Lakw;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Laia;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Laia;->c:I

    return v0
.end method
