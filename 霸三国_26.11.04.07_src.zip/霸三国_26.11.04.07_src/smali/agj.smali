.class public Lagj;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Laml;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Laml;)V
    .locals 0

    iput-object p1, p0, Lagj;->a:[Laml;

    return-void
.end method
