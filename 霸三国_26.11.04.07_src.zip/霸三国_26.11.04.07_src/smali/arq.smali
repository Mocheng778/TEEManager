.class public Larq;
.super Lars;


# instance fields
.field private b:Lald;

.field private c:Z


# direct methods
.method public constructor <init>([Lamz;Lald;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Larq;-><init>([Lamz;Lald;Z)V

    return-void
.end method

.method public constructor <init>([Lamz;Lald;Z)V
    .locals 1

    const/16 v0, 0xc

    invoke-direct {p0, v0, p1}, Lars;-><init>(I[Lamz;)V

    iput-object p2, p0, Larq;->b:Lald;

    iput-boolean p3, p0, Larq;->c:Z

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    invoke-super {p0}, Lars;->f()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 5

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Larq;->b:Lald;

    invoke-virtual {v1}, Lald;->a()I

    move-result v1

    invoke-static {}, Latt;->a()Latt;

    move-result-object v2

    invoke-virtual {v2}, Latt;->h()I

    move-result v2

    invoke-virtual {p0, p1}, Larq;->c([Lakw;)Ljava/lang/String;

    move-result-object v3

    iget-boolean v4, p0, Larq;->c:Z

    if-eqz v4, :cond_0

    invoke-virtual {v0, v1, v2, v3}, Lmm;->crossServerBattleJoin(IILjava/lang/String;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, v2, v3}, Lmm;->h(IILjava/lang/String;)V

    :goto_0
    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
