.class public Lano;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lano;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lano;->a:I

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lano;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lano;->b:I

    return-void
.end method
