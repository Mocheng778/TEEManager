.class public Lagb;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lamg;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lamg;
    .locals 1

    iget-object v0, p0, Lagb;->a:Lamg;

    return-object v0
.end method

.method public a(Lamg;)V
    .locals 0

    iput-object p1, p0, Lagb;->a:Lamg;

    return-void
.end method
