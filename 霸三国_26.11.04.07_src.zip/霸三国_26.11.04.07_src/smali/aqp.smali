.class public Laqp;
.super Ljava/lang/Object;


# instance fields
.field private a:Lbze;

.field private b:I

.field private c:Lbyw;


# direct methods
.method public constructor <init>(Lbyw;Lbze;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laqp;->c:Lbyw;

    iput-object p2, p0, Laqp;->a:Lbze;

    mul-int/lit8 v0, p3, 0x64

    sget v1, Laoe;->a:I

    div-int/2addr v0, v1

    iput v0, p0, Laqp;->b:I

    return-void
.end method


# virtual methods
.method public a(Laqq;DDLaqs;D)V
    .locals 14

    iget-object v0, p0, Laqp;->a:Lbze;

    invoke-virtual {v0}, Lbze;->b()Lbzf;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lare;

    move-object/from16 v0, p6

    iput-object v0, v13, Lare;->guanghanTarget:Laqs;

    move-wide/from16 v0, p7

    iput-wide v0, v13, Lare;->targetHeight:D

    move-object/from16 v0, p1

    iget-boolean v0, v0, Laqs;->zhuqueForm:Z

    iput-boolean v0, v13, Lare;->zhuqueFireball:Z

    move-object/from16 v0, p1

    iget-boolean v0, v0, Laqs;->qinglongForm:Z

    iput-boolean v0, v13, Lare;->qinglongPearl:Z

    invoke-virtual {p1}, Laqq;->a()D

    move-result-wide v0

    invoke-virtual {p1}, Laqq;->b()D

    move-result-wide v2

    move-wide/from16 v4, p2

    move-wide/from16 v6, p4

    invoke-static/range {v0 .. v7}, Lbyz;->b(DDDD)D

    move-result-wide v0

    invoke-virtual {p1}, Laqq;->a()D

    move-result-wide v2

    invoke-virtual {p1}, Laqq;->d()D

    move-result-wide v4

    invoke-static {v4, v5, v0, v1}, Lbyz;->c(DD)D

    move-result-wide v4

    add-double/2addr v2, v4

    invoke-virtual {p1}, Laqq;->b()D

    move-result-wide v4

    invoke-virtual {p1}, Laqq;->d()D

    move-result-wide v6

    invoke-static {v6, v7, v0, v1}, Lbyz;->d(DD)D

    move-result-wide v0

    add-double/2addr v4, v0

    invoke-virtual {p1}, Laqq;->c()D

    move-result-wide v0

    invoke-virtual {p1}, Laqq;->e()D

    move-result-wide v6

    add-double/2addr v6, v0

    move-object/from16 v0, p1

    iget-boolean v0, v0, Laqs;->qinglongForm:Z

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Laqq;->a()D

    move-result-wide v2

    invoke-static {p1}, LSmoothFacing;->dragonMuzzleX(Laqs;)D

    move-result-wide v0

    add-double/2addr v2, v0

    invoke-virtual {p1}, Laqq;->b()D

    move-result-wide v4

    invoke-virtual {p1}, Laqq;->c()D

    move-result-wide v6

    invoke-static {p1}, LSmoothFacing;->dragonMuzzleHeight(Laqs;)D

    move-result-wide v0

    add-double/2addr v6, v0

    :cond_0
    sub-double v0, p2, v2

    iget v8, p0, Laqp;->b:I

    int-to-double v8, v8

    div-double v8, v0, v8

    sub-double v0, p4, v4

    iget v10, p0, Laqp;->b:I

    int-to-double v10, v10

    div-double v10, v0, v10

    iget-object v1, p0, Laqp;->c:Lbyw;

    iget v12, p0, Laqp;->b:I

    move-object v0, v13

    invoke-virtual/range {v0 .. v12}, Lare;->a(Lbyw;DDDDDI)V

    iget-object v0, p0, Laqp;->c:Lbyw;

    invoke-virtual {v0, v13}, Lbyw;->a(Lbyx;)V

    return-void
.end method
