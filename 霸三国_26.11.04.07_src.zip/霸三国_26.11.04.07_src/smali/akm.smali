.class public Lakm;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:[Lalx;

.field private c:I

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakm;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakm;->c:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakm;->a:Ljava/lang/String;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lakm;->b:[Lalx;

    return-void
.end method

.method public b()[Lalx;
    .locals 1

    iget-object v0, p0, Lakm;->b:[Lalx;

    return-object v0
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakm;->c:I

    return v0
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakm;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakm;->d:Ljava/lang/String;

    return-void
.end method
