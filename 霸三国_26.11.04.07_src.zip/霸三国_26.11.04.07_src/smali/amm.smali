.class public Lamm;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamm;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamm;->c:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamm;->a:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamm;->d:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamm;->d:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamm;->b:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamm;->f:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamm;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamm;->g:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamm;->f:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamm;->h:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamm;->g:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamm;->i:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lamm;->h:I

    return-void
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lamm;->i:I

    return-void
.end method
