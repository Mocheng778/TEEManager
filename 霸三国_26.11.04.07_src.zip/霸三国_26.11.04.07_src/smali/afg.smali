.class public Lafg;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lalw;

.field private b:I

.field private c:I

.field private d:[Lalp;

.field private e:[Lalw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalw;
    .locals 1

    iget-object v0, p0, Lafg;->a:Lalw;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafg;->b:I

    return-void
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Lafg;->a:Lalw;

    return-void
.end method

.method public a([Lalp;)V
    .locals 0

    iput-object p1, p0, Lafg;->d:[Lalp;

    return-void
.end method

.method public a([Lalw;)V
    .locals 0

    iput-object p1, p0, Lafg;->e:[Lalw;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafg;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafg;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lafg;->c:I

    return v0
.end method

.method public d()[Lalp;
    .locals 1

    iget-object v0, p0, Lafg;->d:[Lalp;

    return-object v0
.end method

.method public e()[Lalw;
    .locals 1

    iget-object v0, p0, Lafg;->e:[Lalw;

    return-object v0
.end method
