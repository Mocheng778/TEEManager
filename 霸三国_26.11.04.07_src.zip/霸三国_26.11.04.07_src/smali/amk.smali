.class public Lamk;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lamk;->j:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lamk;->j:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamk;->j:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamk;->a:Ljava/lang/String;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamk;->a:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamk;->c:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamk;->b:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamk;->b:Ljava/lang/String;

    return-object v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamk;->d:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamk;->c:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamk;->e:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamk;->d:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamk;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamk;->e:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lamk;->g:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lamk;->f:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lamk;->h:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lamk;->g:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lamk;->i:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lamk;->h:I

    return v0
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lamk;->i:I

    return v0
.end method
