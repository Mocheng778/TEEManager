.class public Lany;
.super Ljava/lang/Object;


# static fields
.field private static f:Lany;


# instance fields
.field private a:Laod;

.field private b:Laod;

.field private c:Ljava/util/Hashtable;

.field private d:Lanw;

.field private e:Laod;


# direct methods
.method private constructor <init>(IIILanw;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lanz;

    invoke-direct {v0, p0, p1}, Lanz;-><init>(Lany;I)V

    iput-object v0, p0, Lany;->a:Laod;

    new-instance v0, Laoa;

    invoke-direct {v0, p0, p2}, Laoa;-><init>(Lany;I)V

    iput-object v0, p0, Lany;->b:Laod;

    new-instance v0, Laob;

    invoke-direct {v0, p0, p3}, Laob;-><init>(Lany;I)V

    iput-object v0, p0, Lany;->e:Laod;

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Lany;->c:Ljava/util/Hashtable;

    iput-object p4, p0, Lany;->d:Lanw;

    if-eqz p4, :cond_0

    new-instance v0, Laoc;

    invoke-direct {v0, p0}, Laoc;-><init>(Lany;)V

    invoke-virtual {p4, v0}, Lanw;->a(Lanx;)V

    :cond_0
    return-void
.end method

.method public static a(IIILanw;)V
    .locals 1

    new-instance v0, Lany;

    invoke-direct {v0, p0, p1, p2, p3}, Lany;-><init>(IIILanw;)V

    sput-object v0, Lany;->f:Lany;

    return-void
.end method

.method public static b()Lany;
    .locals 1

    sget-object v0, Lany;->f:Lany;

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/String;)Lcas;
    .locals 1

    iget-object v0, p0, Lany;->a:Laod;

    invoke-virtual {v0, p1}, Laod;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcas;

    return-object v0
.end method

.method public a()V
    .locals 1

    sget-object v0, Lany;->f:Lany;

    iget-object v0, v0, Lany;->a:Laod;

    invoke-virtual {v0}, Laod;->a()V

    return-void
.end method

.method public a(Ljava/lang/String;Lanx;)V
    .locals 2

    iget-object v0, p0, Lany;->c:Ljava/util/Hashtable;

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lany;->c:Ljava/util/Hashtable;

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Vector;

    invoke-virtual {v0, p2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :goto_0
    return-void

    :cond_0
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iget-object v1, p0, Lany;->c:Ljava/util/Hashtable;

    invoke-virtual {v1, p1, v0}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, p2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object v0, p0, Lany;->d:Lanw;

    invoke-virtual {v0, p1}, Lanw;->a(Ljava/lang/String;)V

    goto :goto_0
.end method

.method public a(Ljava/util/Hashtable;)V
    .locals 1

    sget-object v0, Lany;->f:Lany;

    iget-object v0, v0, Lany;->a:Laod;

    invoke-virtual {v0, p1}, Laod;->a(Ljava/util/Hashtable;)V

    return-void
.end method

.method public b(Ljava/lang/String;)Lbyr;
    .locals 1

    iget-object v0, p0, Lany;->b:Laod;

    invoke-virtual {v0, p1}, Laod;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbyr;

    return-object v0
.end method

.method public b(Ljava/lang/String;Lanx;)Lcas;
    .locals 1

    invoke-virtual {p0, p1}, Lany;->a(Ljava/lang/String;)Lcas;

    move-result-object v0

    if-eqz v0, :cond_0

    :goto_0
    return-object v0

    :cond_0
    invoke-virtual {p0, p1, p2}, Lany;->a(Ljava/lang/String;Lanx;)V

    const/4 v0, 0x0

    goto :goto_0
.end method

.method public c(Ljava/lang/String;)Lbzk;
    .locals 1

    iget-object v0, p0, Lany;->e:Laod;

    invoke-virtual {v0, p1}, Laod;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbzk;

    return-object v0
.end method
