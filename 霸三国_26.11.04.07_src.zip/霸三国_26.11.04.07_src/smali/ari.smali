.class public Lari;
.super Lars;


# instance fields
.field private b:Lajn;


# direct methods
.method public constructor <init>(Lajn;[Lamz;)V
    .locals 1

    const/16 v0, 0x8

    invoke-direct {p0, v0, p2}, Lars;-><init>(I[Lamz;)V

    iput-object p1, p0, Lari;->b:Lajn;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lari;->b:Lajn;

    invoke-virtual {v0}, Lajn;->h()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 3

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Lari;->b:Lajn;

    invoke-virtual {v1}, Lajn;->c()I

    move-result v1

    invoke-virtual {p0, p1}, Lari;->c([Lakw;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lmm;->a(ILjava/lang/String;)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public b()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
