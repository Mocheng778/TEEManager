.class public Laim;
.super Ljava/lang/Object;


# instance fields
.field private a:Lamc;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lamc;
    .locals 1

    iget-object v0, p0, Laim;->a:Lamc;

    return-object v0
.end method

.method public a(Lamc;)V
    .locals 0

    iput-object p1, p0, Laim;->a:Lamc;

    return-void
.end method
