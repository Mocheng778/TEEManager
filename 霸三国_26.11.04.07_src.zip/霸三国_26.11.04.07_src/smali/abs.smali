.class public Labs;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lami;Ljava/io/DataInputStream;)V
    .locals 4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lami;->d(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lami;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lami;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lami;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lami;->c(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lami;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lami;->b(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lana;

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_2

    new-instance v3, Lana;

    invoke-direct {v3}, Lana;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Lack;->a(Lana;Ljava/io/DataInputStream;)V

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {p0, v2}, Lami;->a([Lana;)V

    :cond_4
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v0, v0, [Lana;

    :goto_1
    array-length v2, v0

    if-ge v1, v2, :cond_6

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_5

    new-instance v2, Lana;

    invoke-direct {v2}, Lana;-><init>()V

    aput-object v2, v0, v1

    aget-object v2, v0, v1

    invoke-static {v2, p1}, Lack;->a(Lana;Ljava/io/DataInputStream;)V

    :cond_5
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_6
    invoke-virtual {p0, v0}, Lami;->b([Lana;)V

    :cond_7
    return-void
.end method
