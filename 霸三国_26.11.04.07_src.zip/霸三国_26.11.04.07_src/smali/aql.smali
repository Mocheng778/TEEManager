.class public Laql;
.super Ljava/lang/Object;


# static fields
.field private static a:Laql;


# instance fields
.field private b:[Lajt;

.field private c:[Laln;

.field private d:[Laln;

.field private e:[Lajt;

.field private f:Lajt;

.field private g:Ljava/lang/String;

.field private h:I

.field private i:Lajy;

.field private j:Lbol;


# direct methods
.method private constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Laqm;

    invoke-direct {v0, p0}, Laqm;-><init>(Laql;)V

    iput-object v0, p0, Laql;->j:Lbol;

    invoke-static {}, Lyu;->a()Lframework/server/game/IEventHandlerManager;

    move-result-object v0

    iget-object v1, p0, Laql;->j:Lbol;

    invoke-interface {v0, v1}, Lframework/server/game/IEventHandlerManager;->addHandler(Lyv;)V

    return-void
.end method

.method static synthetic a(Laql;I)I
    .locals 0

    iput p1, p0, Laql;->h:I

    return p1
.end method

.method static synthetic a(Laql;Lajt;)Lajt;
    .locals 0

    iput-object p1, p0, Laql;->f:Lajt;

    return-object p1
.end method

.method static synthetic a(Laql;Lajy;)Lajy;
    .locals 0

    iput-object p1, p0, Laql;->i:Lajy;

    return-object p1
.end method

.method public static a()Laql;
    .locals 1

    sget-object v0, Laql;->a:Laql;

    if-nez v0, :cond_0

    new-instance v0, Laql;

    invoke-direct {v0}, Laql;-><init>()V

    sput-object v0, Laql;->a:Laql;

    :cond_0
    sget-object v0, Laql;->a:Laql;

    return-object v0
.end method

.method static synthetic a(Laql;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Laql;->g:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic a(Laql;[Lajt;)[Lajt;
    .locals 0

    iput-object p1, p0, Laql;->b:[Lajt;

    return-object p1
.end method

.method static synthetic a(Laql;)[Laln;
    .locals 1

    iget-object v0, p0, Laql;->d:[Laln;

    return-object v0
.end method

.method static synthetic a(Laql;[Laln;)[Laln;
    .locals 0

    iput-object p1, p0, Laql;->d:[Laln;

    return-object p1
.end method

.method static synthetic b(Laql;[Lajt;)[Lajt;
    .locals 0

    iput-object p1, p0, Laql;->e:[Lajt;

    return-object p1
.end method

.method static synthetic b(Laql;)[Laln;
    .locals 1

    iget-object v0, p0, Laql;->c:[Laln;

    return-object v0
.end method

.method static synthetic b(Laql;[Laln;)[Laln;
    .locals 0

    iput-object p1, p0, Laql;->c:[Laln;

    return-object p1
.end method

.method static synthetic c(Laql;)[Lajt;
    .locals 1

    iget-object v0, p0, Laql;->e:[Lajt;

    return-object v0
.end method

.method static synthetic d(Laql;)Lajt;
    .locals 1

    iget-object v0, p0, Laql;->f:Lajt;

    return-object v0
.end method

.method static synthetic e(Laql;)[Lajt;
    .locals 1

    iget-object v0, p0, Laql;->b:[Lajt;

    return-object v0
.end method


# virtual methods
.method public b()[Lajt;
    .locals 1

    iget-object v0, p0, Laql;->e:[Lajt;

    return-object v0
.end method

.method public c()[Laln;
    .locals 5

    const/4 v1, 0x0

    iget-object v0, p0, Laql;->c:[Laln;

    array-length v0, v0

    move v2, v0

    move v0, v1

    :goto_0
    iget-object v3, p0, Laql;->c:[Laln;

    array-length v3, v3

    if-ge v0, v3, :cond_1

    iget-object v3, p0, Laql;->c:[Laln;

    aget-object v3, v3, v0

    invoke-virtual {v3}, Laln;->a()Laks;

    move-result-object v3

    invoke-virtual {v3}, Laks;->k()Z

    move-result v3

    if-eqz v3, :cond_0

    add-int/lit8 v2, v2, -0x1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-array v3, v2, [Laln;

    move v0, v1

    :goto_1
    iget-object v2, p0, Laql;->c:[Laln;

    array-length v2, v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Laql;->c:[Laln;

    aget-object v2, v2, v1

    invoke-virtual {v2}, Laln;->a()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->k()Z

    move-result v2

    if-nez v2, :cond_2

    add-int/lit8 v2, v0, 0x1

    iget-object v4, p0, Laql;->c:[Laln;

    aget-object v4, v4, v1

    aput-object v4, v3, v0

    move v0, v2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    return-object v3
.end method

.method public d()[Laln;
    .locals 5

    const/4 v1, 0x0

    move v0, v1

    move v2, v1

    :goto_0
    iget-object v3, p0, Laql;->c:[Laln;

    array-length v3, v3

    if-ge v0, v3, :cond_1

    iget-object v3, p0, Laql;->c:[Laln;

    aget-object v3, v3, v0

    invoke-virtual {v3}, Laln;->a()Laks;

    move-result-object v3

    invoke-virtual {v3}, Laks;->k()Z

    move-result v3

    if-eqz v3, :cond_0

    add-int/lit8 v2, v2, 0x1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-array v3, v2, [Laln;

    move v0, v1

    :goto_1
    iget-object v2, p0, Laql;->c:[Laln;

    array-length v2, v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Laql;->c:[Laln;

    aget-object v2, v2, v1

    invoke-virtual {v2}, Laln;->a()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->k()Z

    move-result v2

    if-eqz v2, :cond_2

    add-int/lit8 v2, v0, 0x1

    iget-object v4, p0, Laql;->c:[Laln;

    aget-object v4, v4, v1

    aput-object v4, v3, v0

    move v0, v2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    iget-object v0, p0, Laql;->c:[Laln;

    if-eqz v0, :cond_4

    move-object v0, v3

    :goto_2
    return-object v0

    :cond_4
    const/4 v0, 0x0

    goto :goto_2
.end method

.method public e()[Laln;
    .locals 1

    iget-object v0, p0, Laql;->d:[Laln;

    return-object v0
.end method

.method public f()Z
    .locals 1

    iget-object v0, p0, Laql;->g:Ljava/lang/String;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public g()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Laql;->g:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, p0, Laql;->g:Ljava/lang/String;

    return-object v0
.end method

.method public h()Z
    .locals 1

    iget-object v0, p0, Laql;->f:Lajt;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public i()Lajt;
    .locals 2

    iget-object v0, p0, Laql;->f:Lajt;

    const/4 v1, 0x0

    iput-object v1, p0, Laql;->f:Lajt;

    return-object v0
.end method

.method public j()I
    .locals 1

    iget v0, p0, Laql;->h:I

    return v0
.end method

.method public k()Lajy;
    .locals 1

    iget-object v0, p0, Laql;->i:Lajy;

    return-object v0
.end method
