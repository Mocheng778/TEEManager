.class public interface abstract Laoh;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method
