.class public Lakv;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x2710

    iput v0, p0, Lakv;->g:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lakv;->g:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakv;->g:I

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lakv;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakv;->a:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakv;->b:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakv;->b:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lakv;->c:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lakv;->c:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lakv;->d:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lakv;->d:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lakv;->e:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lakv;->e:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lakv;->f:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lakv;->f:I

    return-void
.end method
