.class public Larz;
.super Larx;


# instance fields
.field private b:Laqp;

.field private c:D

.field private d:D

.field private e:Z

.field private projectileTarget:Laqs;

.field private projectileTargetHeight:D


# direct methods
.method public constructor <init>(Laqq;DD[Lbyq;Laqp;)V
    .locals 2

    invoke-direct/range {p0 .. p6}, Larx;-><init>(Laqs;DD[Lbyq;)V

    iput-object p7, p0, Larz;->b:Laqp;

    iput-wide p2, p0, Larz;->c:D

    iput-wide p4, p0, Larz;->d:D

    iget-object v0, p1, Laqs;->guanghanTarget:Laqs;

    iput-object v0, p0, Larz;->projectileTarget:Laqs;

    iget-wide v0, p1, Laqs;->projectileTargetHeight:D

    iput-wide v0, p0, Larz;->projectileTargetHeight:D

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-virtual {p0}, Larz;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Larz;->j()V

    invoke-virtual {p0}, Larz;->b()Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->s()V

    :cond_0
    return-void
.end method

.method public j()V
    .locals 9

    iget-boolean v0, p0, Larz;->e:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Larz;->e:Z

    iget-object v0, p0, Larz;->b:Laqp;

    invoke-virtual {p0}, Larz;->b()Laqs;

    move-result-object v1

    check-cast v1, Laqq;

    iget-wide v2, p0, Larz;->c:D

    iget-wide v4, p0, Larz;->d:D

    iget-object v6, p0, Larz;->projectileTarget:Laqs;

    iget-wide v7, p0, Larz;->projectileTargetHeight:D

    invoke-virtual/range {v0 .. v8}, Laqp;->a(Laqq;DDLaqs;D)V

    :cond_0
    return-void
.end method
