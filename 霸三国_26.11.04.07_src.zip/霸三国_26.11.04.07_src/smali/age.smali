.class public Lage;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lajl;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lajl;)V
    .locals 0

    iput-object p1, p0, Lage;->a:[Lajl;

    return-void
.end method

.method public a()[Lajl;
    .locals 1

    iget-object v0, p0, Lage;->a:[Lajl;

    return-object v0
.end method
