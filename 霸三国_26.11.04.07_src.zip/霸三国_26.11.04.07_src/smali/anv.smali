.class public interface abstract Lanv;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)I
.end method
