.class public Lafo;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:[Lamd;

.field private d:[Lall;

.field private e:[Lalm;

.field private f:[Lanc;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lafo;->a:I

    return-void
.end method

.method public a([Lall;)V
    .locals 0

    iput-object p1, p0, Lafo;->d:[Lall;

    return-void
.end method

.method public a([Lalm;)V
    .locals 0

    iput-object p1, p0, Lafo;->e:[Lalm;

    return-void
.end method

.method public a([Lamd;)V
    .locals 0

    iput-object p1, p0, Lafo;->c:[Lamd;

    return-void
.end method

.method public a([Lanc;)V
    .locals 0

    iput-object p1, p0, Lafo;->f:[Lanc;

    return-void
.end method

.method public a()[Lamd;
    .locals 1

    iget-object v0, p0, Lafo;->c:[Lamd;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafo;->b:I

    return-void
.end method

.method public b()[Lall;
    .locals 1

    iget-object v0, p0, Lafo;->d:[Lall;

    return-object v0
.end method

.method public c()[Lalm;
    .locals 1

    iget-object v0, p0, Lafo;->e:[Lalm;

    return-object v0
.end method
