.class Laov;
.super Lbow;


# instance fields
.field final synthetic a:Laou;


# direct methods
.method constructor <init>(Laou;)V
    .locals 0

    iput-object p1, p0, Laov;->a:Laou;

    invoke-direct {p0}, Lbow;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lahe;)V
    .locals 3

    invoke-virtual {p1}, Lahe;->c()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Laov;->a:Laou;

    invoke-static {v0}, Laou;->a(Laou;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laov;->a:Laou;

    invoke-static {v0}, Laou;->a(Laou;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_0

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------onPlatVersionRes() success"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->f()Lboo;

    move-result-object v0

    invoke-virtual {v0}, Lboo;->a()Ladg;

    move-result-object v0

    const-string v1, ""

    iget-object v2, p0, Laov;->a:Laou;

    invoke-static {v2}, Laou;->a(Laou;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ladg;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public b(Laej;)V
    .locals 3

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Laov;->a:Laou;

    invoke-virtual {v0}, Laou;->destroy()V

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "DataReceive----------------------Google RegisterId Success"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :goto_0
    return-void

    :cond_0
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "DataReceive----------------------Google RegisterId Fail,"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_0
.end method
