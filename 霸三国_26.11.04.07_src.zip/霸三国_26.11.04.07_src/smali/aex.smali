.class public Laex;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lakz;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lakz;)V
    .locals 0

    iput-object p1, p0, Laex;->a:[Lakz;

    return-void
.end method
