.class public Lasg;
.super Lbwj;


# instance fields
.field final synthetic a:Laln;

.field final synthetic b:Lcom/lszb/battle/view/ArmyDefendedView;


# direct methods
.method public constructor <init>(Lcom/lszb/battle/view/ArmyDefendedView;Laln;)V
    .locals 0

    iput-object p1, p0, Lasg;->b:Lcom/lszb/battle/view/ArmyDefendedView;

    iput-object p2, p0, Lasg;->a:Laln;

    invoke-direct {p0}, Lbwj;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lasg;->b:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->d(Lcom/lszb/battle/view/ArmyDefendedView;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a(Lcom/lszb/view/ConfirmDialogView;)V
    .locals 3

    iget-object v0, p0, Lasg;->b:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/LoadingView;

    invoke-direct {v1}, Lcom/lszb/view/LoadingView;-><init>()V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Lasg;->a:Laln;

    invoke-virtual {v1}, Laln;->a()Laks;

    move-result-object v1

    invoke-virtual {v1}, Laks;->d()I

    move-result v1

    iget-object v2, p0, Lasg;->a:Laln;

    invoke-virtual {v2}, Laln;->f()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lmm;->p(II)V

    return-void
.end method
