.class public Lals;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:J

.field private l:J

.field private m:I

.field private n:I

.field private o:I

.field private p:Ljava/lang/String;

.field private q:I

.field private r:I

.field private s:J

.field private t:J

.field private u:Ljava/lang/String;

.field private v:F


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()F
    .locals 1

    iget v0, p0, Lals;->v:F

    return v0
.end method

.method public a(F)V
    .locals 0

    iput p1, p0, Lals;->v:F

    return-void
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lals;->f:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lals;->k:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->u:Ljava/lang/String;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lals;->e:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lals;->b:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lals;->l:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->e:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lals;->c:Ljava/lang/String;

    return-object v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lals;->g:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lals;->s:J

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->c:Ljava/lang/String;

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lals;->b:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lals;->h:I

    return-void
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lals;->t:J

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->a:Ljava/lang/String;

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lals;->d:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lals;->i:I

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->d:Ljava/lang/String;

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lals;->j:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lals;->j:I

    return-void
.end method

.method public f(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lals;->p:Ljava/lang/String;

    return-void
.end method

.method public g()J
    .locals 2

    iget-wide v0, p0, Lals;->k:J

    return-wide v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lals;->m:I

    return-void
.end method

.method public h()J
    .locals 2

    iget-wide v0, p0, Lals;->l:J

    return-wide v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lals;->n:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lals;->n:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lals;->o:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lals;->o:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lals;->q:I

    return-void
.end method

.method public k()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lals;->p:Ljava/lang/String;

    return-object v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lals;->r:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lals;->q:I

    return v0
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lals;->r:I

    return v0
.end method

.method public n()J
    .locals 2

    iget-wide v0, p0, Lals;->s:J

    return-wide v0
.end method

.method public o()J
    .locals 2

    iget-wide v0, p0, Lals;->t:J

    return-wide v0
.end method
