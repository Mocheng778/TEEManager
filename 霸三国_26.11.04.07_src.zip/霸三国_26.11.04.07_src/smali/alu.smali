.class public Lalu;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:I

.field private m:Ljava/lang/String;

.field private n:Z

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:Lakg;

.field private v:I

.field private w:I

.field private x:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lakg;
    .locals 1

    iget-object v0, p0, Lalu;->u:Lakg;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalu;->k:I

    return-void
.end method

.method public a(Lakg;)V
    .locals 0

    iput-object p1, p0, Lalu;->u:Lakg;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalu;->m:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lalu;->n:Z

    return-void
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lalu;->l:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalu;->b:Ljava/lang/String;

    return-void
.end method

.method public b()Z
    .locals 1

    iget-boolean v0, p0, Lalu;->n:Z

    return v0
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lalu;->k:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lalu;->a:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lalu;->l:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lalu;->c:I

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalu;->m:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lalu;->d:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lalu;->a:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lalu;->e:I

    return-void
.end method

.method public g()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalu;->b:Ljava/lang/String;

    return-object v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lalu;->f:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lalu;->c:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lalu;->g:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lalu;->d:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lalu;->h:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lalu;->e:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lalu;->i:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lalu;->f:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lalu;->j:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lalu;->g:I

    return v0
.end method

.method public l(I)V
    .locals 0

    iput p1, p0, Lalu;->o:I

    return-void
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lalu;->h:I

    return v0
.end method

.method public m(I)V
    .locals 0

    iput p1, p0, Lalu;->p:I

    return-void
.end method

.method public n()I
    .locals 1

    iget v0, p0, Lalu;->i:I

    return v0
.end method

.method public n(I)V
    .locals 0

    iput p1, p0, Lalu;->q:I

    return-void
.end method

.method public o()I
    .locals 1

    iget v0, p0, Lalu;->j:I

    return v0
.end method

.method public o(I)V
    .locals 0

    iput p1, p0, Lalu;->r:I

    return-void
.end method

.method public p()I
    .locals 1

    iget v0, p0, Lalu;->o:I

    return v0
.end method

.method public p(I)V
    .locals 0

    iput p1, p0, Lalu;->s:I

    return-void
.end method

.method public q()I
    .locals 1

    iget v0, p0, Lalu;->p:I

    return v0
.end method

.method public q(I)V
    .locals 0

    iput p1, p0, Lalu;->t:I

    return-void
.end method

.method public r()I
    .locals 1

    iget v0, p0, Lalu;->q:I

    return v0
.end method

.method public r(I)V
    .locals 0

    iput p1, p0, Lalu;->v:I

    return-void
.end method

.method public s()I
    .locals 1

    iget v0, p0, Lalu;->r:I

    return v0
.end method

.method public s(I)V
    .locals 0

    iput p1, p0, Lalu;->w:I

    return-void
.end method

.method public t()I
    .locals 1

    iget v0, p0, Lalu;->s:I

    return v0
.end method

.method public t(I)V
    .locals 0

    iput p1, p0, Lalu;->x:I

    return-void
.end method

.method public u()I
    .locals 1

    iget v0, p0, Lalu;->t:I

    return v0
.end method

.method public v()I
    .locals 1

    iget v0, p0, Lalu;->v:I

    return v0
.end method

.method public w()I
    .locals 1

    iget v0, p0, Lalu;->w:I

    return v0
.end method

.method public x()I
    .locals 1

    iget v0, p0, Lalu;->x:I

    return v0
.end method
