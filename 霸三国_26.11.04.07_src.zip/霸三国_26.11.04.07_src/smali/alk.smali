.class public Lalk;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I

.field private f:I

.field private g:[Lala;

.field private h:[Lala;

.field private i:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lalk;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalk;->a:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalk;->b:Ljava/lang/String;

    return-void
.end method

.method public a([Lala;)V
    .locals 0

    iput-object p1, p0, Lalk;->g:[Lala;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalk;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lalk;->d:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalk;->c:Ljava/lang/String;

    return-void
.end method

.method public b([Lala;)V
    .locals 0

    iput-object p1, p0, Lalk;->h:[Lala;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lalk;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lalk;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lalk;->e:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lalk;->i:I

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalk;->c:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lalk;->f:I

    return-void
.end method

.method public f()[Lala;
    .locals 1

    iget-object v0, p0, Lalk;->g:[Lala;

    return-object v0
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lalk;->i:I

    return v0
.end method

.method public h()[Lala;
    .locals 1

    iget-object v0, p0, Lalk;->h:[Lala;

    return-object v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lalk;->f:I

    return v0
.end method
