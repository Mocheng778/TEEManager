.class public Laho;
.super Ljava/lang/Object;


# instance fields
.field private a:Lakc;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lakc;
    .locals 1

    iget-object v0, p0, Laho;->a:Lakc;

    return-object v0
.end method

.method public a(Lakc;)V
    .locals 0

    iput-object p1, p0, Laho;->a:Lakc;

    return-void
.end method
