.class public Laga;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Laga;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laga;->c:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Laga;->b:Ljava/lang/String;

    return-void
.end method
