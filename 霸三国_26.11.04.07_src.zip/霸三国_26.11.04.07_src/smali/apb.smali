.class public Lapb;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/arena/view/ArenaAddTimesView;


# direct methods
.method public constructor <init>(Lcom/lszb/arena/view/ArenaAddTimesView;)V
    .locals 0

    iput-object p1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ladz;)V
    .locals 3

    iget-object v0, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-static {}, Laoy;->a()Laoy;

    move-result-object v0

    invoke-virtual {v0}, Laoy;->b()I

    move-result v0

    iget-object v1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->a(Lcom/lszb/arena/view/ArenaAddTimesView;)I

    move-result v1

    mul-int/2addr v0, v1

    iget-object v1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->b(Lcom/lszb/arena/view/ArenaAddTimesView;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "${gold}"

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${num}"

    iget-object v2, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v2}, Lcom/lszb/arena/view/ArenaAddTimesView;->a(Lcom/lszb/arena/view/ArenaAddTimesView;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v1

    new-instance v2, Lcom/lszb/view/InfoDialogView;

    invoke-direct {v2, v0}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lapb;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Ladz;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method
