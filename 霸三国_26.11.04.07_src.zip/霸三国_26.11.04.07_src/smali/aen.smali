.class public Laen;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lamz;

.field private b:[Lalz;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lalz;)V
    .locals 0

    iput-object p1, p0, Laen;->b:[Lalz;

    return-void
.end method

.method public a([Lamz;)V
    .locals 0

    iput-object p1, p0, Laen;->a:[Lamz;

    return-void
.end method

.method public a()[Lamz;
    .locals 1

    iget-object v0, p0, Laen;->a:[Lamz;

    return-object v0
.end method

.method public b()[Lalz;
    .locals 1

    iget-object v0, p0, Laen;->b:[Lalz;

    return-object v0
.end method
