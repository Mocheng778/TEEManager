.class public Lait;
.super Ljava/lang/Object;


# instance fields
.field private a:Lant;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lant;
    .locals 1

    iget-object v0, p0, Lait;->a:Lant;

    return-object v0
.end method

.method public a(Lant;)V
    .locals 0

    iput-object p1, p0, Lait;->a:Lant;

    return-void
.end method
