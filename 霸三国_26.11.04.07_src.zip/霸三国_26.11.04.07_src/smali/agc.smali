.class public Lagc;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Ljava/lang/String;

.field private b:[Lamh;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagc;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagc;->a:Ljava/lang/String;

    return-void
.end method

.method public a([Lamh;)V
    .locals 0

    iput-object p1, p0, Lagc;->b:[Lamh;

    return-void
.end method

.method public b()[Lamh;
    .locals 1

    iget-object v0, p0, Lagc;->b:[Lamh;

    return-object v0
.end method
