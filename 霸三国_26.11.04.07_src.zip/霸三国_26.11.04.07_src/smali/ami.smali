.class public Lami;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I

.field private g:J

.field private h:[Lana;

.field private i:[Lana;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lami;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lami;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lami;->g:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lami;->b:Ljava/lang/String;

    return-void
.end method

.method public a([Lana;)V
    .locals 0

    iput-object p1, p0, Lami;->h:[Lana;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lami;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lami;->c:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lami;->d:Ljava/lang/String;

    return-void
.end method

.method public b([Lana;)V
    .locals 0

    iput-object p1, p0, Lami;->i:[Lana;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lami;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lami;->e:I

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lami;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lami;->f:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lami;->e:I

    return v0
.end method

.method public f()J
    .locals 2

    iget-wide v0, p0, Lami;->g:J

    return-wide v0
.end method

.method public g()[Lana;
    .locals 1

    iget-object v0, p0, Lami;->h:[Lana;

    return-object v0
.end method

.method public h()[Lana;
    .locals 1

    iget-object v0, p0, Lami;->i:[Lana;

    return-object v0
.end method
