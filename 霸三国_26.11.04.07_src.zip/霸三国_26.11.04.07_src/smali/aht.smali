.class public Laht;
.super Ljava/lang/Object;


# instance fields
.field private a:Lalu;

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalu;
    .locals 1

    iget-object v0, p0, Laht;->a:Lalu;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laht;->b:I

    return-void
.end method

.method public a(Lalu;)V
    .locals 0

    iput-object p1, p0, Laht;->a:Lalu;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laht;->b:I

    return v0
.end method
