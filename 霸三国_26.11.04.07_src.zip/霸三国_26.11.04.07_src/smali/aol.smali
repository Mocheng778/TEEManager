.class public interface abstract Laol;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Z
.end method
