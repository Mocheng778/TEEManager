.class public Larb;
.super Laqu;


# instance fields
.field private a:J

.field private b:J


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    invoke-direct {p0}, Laqu;-><init>()V

    const-string v0, "_"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, v0, v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    iput-wide v1, p0, Larb;->a:J

    const/4 v1, 0x1

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    iput-wide v0, p0, Larb;->b:J

    return-void
.end method


# virtual methods
.method public a(Laqg;)V
    .locals 2

    iget-wide v0, p0, Larb;->a:J

    invoke-virtual {p1, v0, v1}, Laqg;->b(J)V

    iget-wide v0, p0, Larb;->b:J

    invoke-virtual {p1, v0, v1}, Laqg;->d(J)V

    return-void
.end method
