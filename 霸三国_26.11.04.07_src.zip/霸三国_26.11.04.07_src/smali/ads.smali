.class public interface abstract Lads;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Laej;)V
.end method

.method public abstract a(Lagr;)V
.end method
