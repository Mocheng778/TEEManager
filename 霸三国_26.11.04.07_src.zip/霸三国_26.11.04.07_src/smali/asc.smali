.class public abstract Lasc;
.super Ljava/lang/Object;


# static fields
.field private static final b:[I


# instance fields
.field protected a:[Lbyq;

.field private c:Laqs;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lasc;->b:[I

    return-void

    :array_0
    .array-data 4
        0x8
        0xa
        0x2
        0x6
        0x4
        0x5
        0x1
        0x9
    .end array-data
.end method

.method public constructor <init>(Laqs;[Lbyq;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lasc;->c:Laqs;

    iput-object p2, p0, Lasc;->a:[Lbyq;

    return-void
.end method


# virtual methods
.method protected a(DD)I
    .locals 14

    iget-object v0, p0, Lasc;->c:Laqs;

    invoke-virtual {v0}, Laqs;->y()I

    move-result v0

    int-to-double v8, v0

    iget-object v0, p0, Lasc;->c:Laqs;

    invoke-virtual {v0}, Laqs;->z()I

    move-result v0

    int-to-double v10, v0

    const-wide/16 v4, 0x0

    move-wide v0, p1

    move-wide/from16 v2, p3

    invoke-static/range {v0 .. v5}, Laqh;->a(DDD)I

    move-result v0

    int-to-double v12, v0

    const-wide/16 v4, 0x0

    move-wide v0, p1

    move-wide/from16 v2, p3

    invoke-static/range {v0 .. v5}, Laqh;->b(DDD)I

    move-result v0

    int-to-double v6, v0

    move-wide v0, v8

    move-wide v2, v10

    move-wide v4, v12

    invoke-static/range {v0 .. v7}, Lbyz;->b(DDDD)D

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmpg-double v2, v0, v2

    if-gez v2, :cond_0

    const-wide v2, 0x4076800000000000L    # 360.0

    add-double/2addr v0, v2

    :cond_0
    const/16 v2, 0x2d

    const-wide v3, 0x4076800000000000L    # 360.0

    add-double/2addr v0, v3

    const/16 v3, 0x152

    int-to-double v3, v3

    sub-double/2addr v0, v3

    const-wide v3, 0x4076800000000000L    # 360.0

    rem-double/2addr v0, v3

    int-to-double v2, v2

    div-double/2addr v0, v2

    double-to-int v0, v0

    sget-object v1, Lasc;->b:[I

    aget v0, v1, v0

    return v0
.end method

.method public abstract a()V
.end method

.method public a(Lcar;II)V
    .locals 6

    iget-object v5, p0, Lasc;->c:Laqs;

    iget-object v0, v5, Laqs;->smoothFacing:LSmoothFacing;

    if-eqz v0, :cond_0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    invoke-virtual/range {v0 .. v5}, LSmoothFacing;->draw(Lasc;Lcar;IILaqs;)V

    return-void

    :cond_0
    invoke-virtual {p0}, Lasc;->d()I

    move-result v0

    invoke-virtual {p0}, Lasc;->e()Lbyq;

    move-result-object v1

    if-nez v0, :cond_1

    add-int/lit8 v2, p2, -0x3c

    add-int/lit8 v3, p3, -0x54

    invoke-virtual {v1, p1, v2, v3, v0}, Lbyq;->a(Lcar;III)V

    :goto_0
    return-void

    :cond_1
    add-int/lit8 v2, p2, 0x3c

    add-int/lit8 v3, p3, -0x54

    invoke-virtual {v1, p1, v2, v3, v0}, Lbyq;->a(Lcar;III)V

    goto :goto_0
.end method

.method protected b()Laqs;
    .locals 1

    iget-object v0, p0, Lasc;->c:Laqs;

    return-object v0
.end method

.method protected c()I
    .locals 1

    iget-object v0, p0, Lasc;->c:Laqs;

    invoke-virtual {v0}, Laqs;->r()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    const/4 v0, -0x1

    :goto_0
    return v0

    :pswitch_1
    const/4 v0, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v0, 0x1

    goto :goto_0

    :pswitch_3
    const/4 v0, 0x2

    goto :goto_0

    :pswitch_4
    const/4 v0, 0x3

    goto :goto_0

    :pswitch_5
    const/4 v0, 0x4

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_5
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_4
    .end packed-switch
.end method

.method protected d()I
    .locals 1

    iget-object v0, p0, Lasc;->c:Laqs;

    invoke-virtual {v0}, Laqs;->r()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    const/4 v0, -0x1

    :goto_0
    return v0

    :pswitch_1
    const/4 v0, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v0, 0x4

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_2
        :pswitch_2
        :pswitch_2
    .end packed-switch
.end method

.method protected e()Lbyq;
    .locals 2

    iget-object v0, p0, Lasc;->a:[Lbyq;

    invoke-virtual {p0}, Lasc;->c()I

    move-result v1

    aget-object v0, v0, v1

    return-object v0
.end method

.method public f()I
    .locals 2

    invoke-virtual {p0}, Lasc;->d()I

    move-result v0

    invoke-virtual {p0}, Lasc;->e()Lbyq;

    move-result-object v1

    invoke-virtual {v1, v0}, Lbyq;->e(I)I

    move-result v0

    return v0
.end method

.method public g()I
    .locals 2

    invoke-virtual {p0}, Lasc;->d()I

    move-result v0

    invoke-virtual {p0}, Lasc;->e()Lbyq;

    move-result-object v1

    invoke-virtual {v1, v0}, Lbyq;->f(I)I

    move-result v0

    return v0
.end method

.method public h()I
    .locals 2

    invoke-virtual {p0}, Lasc;->d()I

    move-result v0

    invoke-virtual {p0}, Lasc;->e()Lbyq;

    move-result-object v1

    invoke-virtual {v1, v0}, Lbyq;->g(I)I

    move-result v0

    add-int/lit8 v0, v0, -0x54

    return v0
.end method

.method public i()I
    .locals 2

    invoke-virtual {p0}, Lasc;->d()I

    move-result v0

    invoke-virtual {p0}, Lasc;->e()Lbyq;

    move-result-object v1

    if-nez v0, :cond_0

    invoke-virtual {v1, v0}, Lbyq;->h(I)I

    move-result v0

    add-int/lit8 v0, v0, -0x3c

    :goto_0
    return v0

    :cond_0
    invoke-virtual {v1, v0}, Lbyq;->h(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x3c

    goto :goto_0
.end method
