.class public Lagw;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:Lang;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:J

.field private g:Z

.field private h:[Lanh;

.field private i:[Lang;

.field private j:[Lani;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagw;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagw;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lagw;->f:J

    return-void
.end method

.method public a(Lang;)V
    .locals 0

    iput-object p1, p0, Lagw;->c:Lang;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagw;->d:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lagw;->g:Z

    return-void
.end method

.method public a([Lang;)V
    .locals 0

    iput-object p1, p0, Lagw;->i:[Lang;

    return-void
.end method

.method public a([Lanh;)V
    .locals 0

    iput-object p1, p0, Lagw;->h:[Lanh;

    return-void
.end method

.method public a([Lani;)V
    .locals 0

    iput-object p1, p0, Lagw;->j:[Lani;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lagw;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagw;->b:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagw;->e:Ljava/lang/String;

    return-void
.end method

.method public c()Lang;
    .locals 1

    iget-object v0, p0, Lagw;->c:Lang;

    return-object v0
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagw;->d:Ljava/lang/String;

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagw;->e:Ljava/lang/String;

    return-object v0
.end method

.method public f()J
    .locals 2

    iget-wide v0, p0, Lagw;->f:J

    return-wide v0
.end method

.method public g()Z
    .locals 1

    iget-boolean v0, p0, Lagw;->g:Z

    return v0
.end method

.method public h()[Lanh;
    .locals 1

    iget-object v0, p0, Lagw;->h:[Lanh;

    return-object v0
.end method

.method public i()[Lang;
    .locals 1

    iget-object v0, p0, Lagw;->i:[Lang;

    return-object v0
.end method

.method public j()[Lani;
    .locals 1

    iget-object v0, p0, Lagw;->j:[Lani;

    return-object v0
.end method
