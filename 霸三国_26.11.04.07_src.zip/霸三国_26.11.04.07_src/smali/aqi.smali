.class public Laqi;
.super Ljava/lang/Object;


# instance fields
.field private a:Z

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private final j:I

.field private final k:I

.field private final l:I

.field private final m:I

.field private final n:I

.field private final o:I

.field private final p:I


# direct methods
.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput v1, p0, Laqi;->j:I

    iput v2, p0, Laqi;->k:I

    iput v3, p0, Laqi;->l:I

    iput v4, p0, Laqi;->m:I

    iput v5, p0, Laqi;->n:I

    const/4 v0, 0x7

    iput v0, p0, Laqi;->o:I

    const/16 v0, 0x8

    iput v0, p0, Laqi;->p:I

    iput-boolean p1, p0, Laqi;->a:Z

    iput-object p2, p0, Laqi;->b:Ljava/lang/String;

    const-string v0, "_"

    invoke-static {p3, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v1, v0, v1

    iput-object v1, p0, Laqi;->c:Ljava/lang/String;

    aget-object v1, v0, v5

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqi;->d:I

    aget-object v1, v0, v2

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqi;->e:I

    aget-object v1, v0, v3

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqi;->f:I

    iget v1, p0, Laqi;->f:I

    aget-object v2, v0, v4

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    sub-int/2addr v1, v2

    iput v1, p0, Laqi;->g:I

    const/4 v1, 0x7

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqi;->h:I

    const/16 v1, 0x8

    aget-object v0, v0, v1

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laqi;->i:I

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 1

    iget-boolean v0, p0, Laqi;->a:Z

    return v0
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqi;->b:Ljava/lang/String;

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqi;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d()I
    .locals 1

    iget v0, p0, Laqi;->d:I

    return v0
.end method

.method public e()I
    .locals 2

    iget v0, p0, Laqi;->e:I

    const/16 v1, 0x28

    if-eq v0, v1, :cond_0

    const/16 v1, 0x29

    if-eq v0, v1, :cond_1

    const/16 v1, 0x2a

    if-eq v0, v1, :cond_1

    const/16 v1, 0x2b

    if-eq v0, v1, :cond_0

    const/16 v1, 0x2c

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    const/16 v0, 0x8

    return v0

    :cond_1
    const/4 v0, 0x4

    return v0
.end method

.method public f()I
    .locals 1

    iget v0, p0, Laqi;->f:I

    return v0
.end method

.method public g()I
    .locals 1

    iget v0, p0, Laqi;->g:I

    return v0
.end method

.method public h()I
    .locals 1

    iget v0, p0, Laqi;->h:I

    return v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Laqi;->i:I

    return v0
.end method
