.class public Lamq;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:J

.field private d:J

.field private e:J

.field private f:J

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:J

.field private l:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lamq;->g:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamq;->g:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->c:J

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamq;->h:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamq;->h:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->d:J

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamq;->i:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamq;->i:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->e:J

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamq;->j:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamq;->j:I

    return-void
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->f:J

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamq;->a:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamq;->a:I

    return-void
.end method

.method public e(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->k:J

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamq;->b:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lamq;->b:I

    return-void
.end method

.method public f(J)V
    .locals 0

    iput-wide p1, p0, Lamq;->l:J

    return-void
.end method

.method public g()J
    .locals 2

    iget-wide v0, p0, Lamq;->c:J

    return-wide v0
.end method

.method public h()J
    .locals 2

    iget-wide v0, p0, Lamq;->d:J

    return-wide v0
.end method

.method public i()J
    .locals 2

    iget-wide v0, p0, Lamq;->e:J

    return-wide v0
.end method

.method public j()J
    .locals 2

    iget-wide v0, p0, Lamq;->f:J

    return-wide v0
.end method

.method public k()J
    .locals 2

    iget-wide v0, p0, Lamq;->k:J

    return-wide v0
.end method

.method public l()J
    .locals 2

    iget-wide v0, p0, Lamq;->l:J

    return-wide v0
.end method
