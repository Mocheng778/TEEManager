.class public Lafw;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lals;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lals;
    .locals 1

    iget-object v0, p0, Lafw;->a:Lals;

    return-object v0
.end method

.method public a(Lals;)V
    .locals 0

    iput-object p1, p0, Lafw;->a:Lals;

    return-void
.end method
