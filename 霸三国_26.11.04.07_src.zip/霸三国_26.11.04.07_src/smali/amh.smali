.class public Lamh;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamh;->c:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamh;->b:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamh;->c:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamh;->d:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamh;->d:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamh;->a:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamh;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamh;->f:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamh;->a:I

    return-void
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamh;->f:I

    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    return v0

    :cond_1
    if-nez p1, :cond_2

    move v0, v1

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    if-eq v2, v3, :cond_3

    move v0, v1

    goto :goto_0

    :cond_3
    check-cast p1, Lamh;

    iget v2, p0, Lamh;->b:I

    iget v3, p1, Lamh;->b:I

    if-eq v2, v3, :cond_0

    move v0, v1

    goto :goto_0
.end method

.method public hashCode()I
    .locals 1

    iget v0, p0, Lamh;->b:I

    add-int/lit8 v0, v0, 0x1f

    return v0
.end method
