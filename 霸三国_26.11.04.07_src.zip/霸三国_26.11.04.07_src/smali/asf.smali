.class public Lasf;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/battle/view/ArmyDefendedView;


# direct methods
.method public constructor <init>(Lcom/lszb/battle/view/ArmyDefendedView;)V
    .locals 0

    iput-object p1, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public O(Laej;)V
    .locals 3

    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-virtual {v1}, Lcom/lszb/battle/view/ArmyDefendedView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {v2}, Lcom/lszb/battle/view/ArmyDefendedView;->c(Lcom/lszb/battle/view/ArmyDefendedView;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-virtual {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public a(Laid;)V
    .locals 2

    if-eqz p1, :cond_0

    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {}, Laql;->a()Laql;

    move-result-object v1

    invoke-virtual {v1}, Laql;->e()[Laln;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/battle/view/ArmyDefendedView;->a(Lcom/lszb/battle/view/ArmyDefendedView;[Laln;)[Laln;

    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->a(Lcom/lszb/battle/view/ArmyDefendedView;)V

    iget-object v0, p0, Lasf;->a:Lcom/lszb/battle/view/ArmyDefendedView;

    invoke-static {v0}, Lcom/lszb/battle/view/ArmyDefendedView;->b(Lcom/lszb/battle/view/ArmyDefendedView;)Lcom/lzlm/component/ListComponent;

    move-result-object v0

    invoke-virtual {v0}, Lcom/lzlm/component/ListComponent;->d()V

    :cond_0
    return-void
.end method
