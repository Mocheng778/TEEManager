.class Laqd;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Laqc;


# direct methods
.method constructor <init>(Laqc;)V
    .locals 0

    iput-object p1, p0, Laqd;->a:Laqc;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqd;->a:Laqc;

    invoke-static {v1}, Laqc;->a(Laqc;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqd;->a:Laqc;

    invoke-static {v0}, Laqc;->b(Laqc;)Lapr;

    move-result-object v0

    invoke-virtual {v0}, Lapr;->c()Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method
