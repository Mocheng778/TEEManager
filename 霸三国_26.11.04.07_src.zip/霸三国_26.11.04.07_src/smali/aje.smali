.class public Laje;
.super Ljava/lang/Object;


# direct methods
.method public static a(I)I
    .locals 2

    const/16 v0, 0xa

    div-int/lit8 v1, p0, 0xa

    add-int/lit8 v1, v1, 0x1

    if-le v1, v0, :cond_0

    :goto_0
    return v0

    :cond_0
    move v0, v1

    goto :goto_0
.end method

.method public static b(I)I
    .locals 3

    const/4 v1, 0x1

    const/4 v0, 0x0

    :goto_0
    add-int/lit8 v2, p0, -0x2

    if-ge v0, v2, :cond_0

    mul-int/lit8 v1, v1, 0x2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    mul-int/lit16 v0, v1, 0x7d0

    return v0
.end method
