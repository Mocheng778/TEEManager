.class public final Lak;
.super Laj;


# instance fields
.field private j:Ljava/lang/String;

.field private k:Ljava/lang/String;

.field private l:Ljava/lang/String;

.field private m:I

.field private n:Laa;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Laj;-><init>()V

    const-string v0, "000000000000000"

    iput-object v0, p0, Lak;->j:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lak;->k:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lak;->l:Ljava/lang/String;

    const/4 v0, 0x2

    iput v0, p0, Lak;->m:I

    const/4 v0, 0x1

    iput v0, p0, Lak;->a:I

    return-void
.end method


# virtual methods
.method public final a()Lorg/json/JSONObject;
    .locals 3

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    iget-object v0, p0, Lak;->j:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "ClientName"

    iget-object v2, p0, Lak;->j:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    iget-object v0, p0, Lak;->k:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "ClientDC"

    iget-object v2, p0, Lak;->k:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    iget-object v0, p0, Lak;->l:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "TempKey"

    iget-object v2, p0, Lak;->l:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    iget-object v0, p0, Lak;->n:Laa;

    if-eqz v0, :cond_3

    const-string v0, "ParamList"

    iget-object v2, p0, Lak;->n:Laa;

    invoke-virtual {v2}, Laa;->b()Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    iget-object v0, p0, Lak;->n:Laa;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lak;->n:Laa;

    invoke-virtual {v0}, Laa;->a()I

    move-result v0

    :goto_0
    iput v0, p0, Lak;->m:I

    const-string v0, "ParamNum"

    iget v2, p0, Lak;->m:I

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    return-object v1

    :cond_4
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public final a(Laa;)V
    .locals 0

    iput-object p1, p0, Lak;->n:Laa;

    return-void
.end method

.method public final b(I)V
    .locals 0

    iput p1, p0, Lak;->m:I

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lak;->l:Ljava/lang/String;

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lak;->j:Ljava/lang/String;

    return-void
.end method
