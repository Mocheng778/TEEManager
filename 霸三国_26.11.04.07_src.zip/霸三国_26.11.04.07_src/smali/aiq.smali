.class public Laiq;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:J

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laiq;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laiq;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laiq;->b:J

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Laiq;->c:Z

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Laiq;->b:J

    return-wide v0
.end method

.method public c()Z
    .locals 1

    iget-boolean v0, p0, Laiq;->c:Z

    return v0
.end method
