.class public Lapp;
.super Ljava/lang/Object;


# static fields
.field private static a:Lapp;


# instance fields
.field private b:Ljava/util/Hashtable;

.field private c:Ljava/util/Hashtable;

.field private d:Lbol;


# direct methods
.method private constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Lapp;->b:Ljava/util/Hashtable;

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Lapp;->c:Ljava/util/Hashtable;

    new-instance v0, Lapq;

    invoke-direct {v0, p0}, Lapq;-><init>(Lapp;)V

    iput-object v0, p0, Lapp;->d:Lbol;

    invoke-static {}, Lyu;->a()Lframework/server/game/IEventHandlerManager;

    move-result-object v0

    iget-object v1, p0, Lapp;->d:Lbol;

    invoke-interface {v0, v1}, Lframework/server/game/IEventHandlerManager;->addHandler(Lyv;)V

    return-void
.end method

.method public static a()Lapp;
    .locals 1

    sget-object v0, Lapp;->a:Lapp;

    if-nez v0, :cond_0

    new-instance v0, Lapp;

    invoke-direct {v0}, Lapp;-><init>()V

    sput-object v0, Lapp;->a:Lapp;

    :cond_0
    sget-object v0, Lapp;->a:Lapp;

    return-object v0
.end method

.method static synthetic a(Lapp;)Ljava/util/Hashtable;
    .locals 1

    iget-object v0, p0, Lapp;->b:Ljava/util/Hashtable;

    return-object v0
.end method

.method static synthetic b(Lapp;)Ljava/util/Hashtable;
    .locals 1

    iget-object v0, p0, Lapp;->c:Ljava/util/Hashtable;

    return-object v0
.end method


# virtual methods
.method public a(I)Lanq;
    .locals 2

    iget-object v0, p0, Lapp;->b:Ljava/util/Hashtable;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lanq;

    return-object v0
.end method

.method public b(I)[I
    .locals 4

    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    iget-object v0, p0, Lapp;->b:Ljava/util/Hashtable;

    invoke-virtual {v0}, Ljava/util/Hashtable;->elements()Ljava/util/Enumeration;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lanq;

    invoke-virtual {v0}, Lanq;->d()I

    move-result v2

    if-ne v2, p1, :cond_0

    invoke-virtual {v0}, Lanq;->c()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v0

    if-lez v0, :cond_3

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v0

    new-array v2, v0, [I

    const/4 v0, 0x0

    move v1, v0

    :goto_1
    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_2

    invoke-virtual {v3, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    aput v0, v2, v1

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1

    :cond_2
    move-object v0, v2

    :goto_2
    return-object v0

    :cond_3
    const/4 v0, 0x0

    goto :goto_2
.end method

.method public c(I)Lapr;
    .locals 2

    iget-object v0, p0, Lapp;->c:Ljava/util/Hashtable;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lapr;

    return-object v0
.end method
