.class public Lamg;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:[Lalo;

.field private c:[Lalo;

.field private d:J

.field private e:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lamg;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lamg;->d:J

    return-void
.end method

.method public a([Lalo;)V
    .locals 0

    iput-object p1, p0, Lamg;->b:[Lalo;

    return-void
.end method

.method public a()[Lalo;
    .locals 1

    iget-object v0, p0, Lamg;->b:[Lalo;

    return-object v0
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lamg;->e:J

    return-void
.end method

.method public b([Lalo;)V
    .locals 0

    iput-object p1, p0, Lamg;->c:[Lalo;

    return-void
.end method

.method public b()[Lalo;
    .locals 1

    iget-object v0, p0, Lamg;->c:[Lalo;

    return-object v0
.end method
