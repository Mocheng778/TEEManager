.class public Lapg;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/arena/view/ArenaMainView;


# direct methods
.method public constructor <init>(Lcom/lszb/arena/view/ArenaMainView;)V
    .locals 0

    iput-object p1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ladx;)V
    .locals 3

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Ladx;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/arena/view/ArenaRankListView;

    invoke-virtual {p1}, Ladx;->a()[Lajn;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/arena/view/ArenaRankListView;-><init>([Lajn;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Ladx;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public a(Lady;)V
    .locals 3

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Lady;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-virtual {p1}, Lady;->a()[Lajo;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/arena/view/ArenaRecordListView;-><init>([Lajo;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Lady;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public a(Ladz;)V
    .locals 2

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0, p1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;Ladz;)Ladz;

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;)Ladz;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;Ladz;)V

    :cond_0
    return-void
.end method

.method public a(Lafs;)V
    .locals 4

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Lafs;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/arena/view/ArenaDefenceListView;

    iget-object v2, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v2}, Lcom/lszb/arena/view/ArenaMainView;->c(Lcom/lszb/arena/view/ArenaMainView;)Lajn;

    move-result-object v2

    invoke-virtual {p1}, Lafs;->a()[Lamz;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lcom/lszb/arena/view/ArenaDefenceListView;-><init>(Lajn;[Lamz;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Lafs;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public b(Ladz;)V
    .locals 2

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0, p1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;Ladz;)Ladz;

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;)Ladz;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;Ladz;)V

    :cond_0
    return-void
.end method

.method public c(Ladz;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v1, 0x0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    iget-object v2, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v2}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v2

    invoke-virtual {v2}, Laok;->c()Laoj;

    move-result-object v2

    invoke-virtual {v0, v2}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    if-ne v0, v6, :cond_3

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;)Ladz;

    move-result-object v0

    invoke-virtual {v0}, Ladz;->a()Ljava/lang/String;

    move-result-object v0

    const-string v3, "\u3001"

    invoke-static {v0, v3}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    move v0, v1

    :goto_0
    array-length v4, v3

    if-ge v0, v4, :cond_1

    aget-object v4, v3, v0

    const-string v5, "_"

    invoke-static {v4, v5}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v5, v4, v1

    invoke-virtual {v2, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v5, "+"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    aget-object v4, v4, v6

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    array-length v4, v3

    add-int/lit8 v4, v4, -0x1

    if-ge v0, v4, :cond_0

    const-string v4, "$"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->length()I

    move-result v0

    if-lez v0, :cond_2

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;)Lbrp;

    move-result-object v0

    invoke-virtual {v0}, Lbrp;->a()V

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;)Lbrp;

    move-result-object v0

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lbrp;->a(Ljava/lang/String;)V

    :cond_2
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0, p1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;Ladz;)Ladz;

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;)Ladz;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;Ladz;)V

    :goto_1
    return-void

    :cond_3
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Ladz;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_1
.end method

.method public f(Ladz;)V
    .locals 3

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v0, p1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;Ladz;)Ladz;

    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    iget-object v1, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaMainView;->a(Lcom/lszb/arena/view/ArenaMainView;)Ladz;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/arena/view/ArenaMainView;->b(Lcom/lszb/arena/view/ArenaMainView;Ladz;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Lapg;->a:Lcom/lszb/arena/view/ArenaMainView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaMainView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Ladz;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method
