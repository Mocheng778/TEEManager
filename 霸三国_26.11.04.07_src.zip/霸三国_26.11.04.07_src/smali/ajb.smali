.class public Lajb;
.super Ljava/lang/Object;


# instance fields
.field private a:Lane;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lane;
    .locals 1

    iget-object v0, p0, Lajb;->a:Lane;

    return-object v0
.end method

.method public a(Lane;)V
    .locals 0

    iput-object p1, p0, Lajb;->a:Lane;

    return-void
.end method
