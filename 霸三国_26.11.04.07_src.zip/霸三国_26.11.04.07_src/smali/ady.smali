.class public Lady;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lajo;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lajo;)V
    .locals 0

    iput-object p1, p0, Lady;->a:[Lajo;

    return-void
.end method

.method public a()[Lajo;
    .locals 1

    iget-object v0, p0, Lady;->a:[Lajo;

    return-object v0
.end method
