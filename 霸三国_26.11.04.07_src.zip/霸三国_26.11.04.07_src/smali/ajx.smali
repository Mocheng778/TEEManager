.class public Lajx;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lajx;->b:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lajx;->b:I

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lajx;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lajx;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lajx;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lajx;->d:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lajx;->e:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lajx;->e:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lajx;->f:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lajx;->f:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lajx;->h:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lajx;->a:I

    return-void
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lajx;->g:I

    return-void
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lajx;->h:I

    return-void
.end method
