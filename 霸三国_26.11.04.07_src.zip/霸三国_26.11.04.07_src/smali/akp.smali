.class public Lakp;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lako;

.field private b:Ljava/lang/String;

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lakp;->c:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakp;->b:Ljava/lang/String;

    return-void
.end method

.method public a([Lako;)V
    .locals 0

    iput-object p1, p0, Lakp;->a:[Lako;

    return-void
.end method

.method public a()[Lako;
    .locals 1

    iget-object v0, p0, Lakp;->a:[Lako;

    return-object v0
.end method
