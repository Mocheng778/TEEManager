.class public Lacd;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lamt;Ljava/io/DataInputStream;)V
    .locals 1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lalx;

    invoke-direct {v0}, Lalx;-><init>()V

    invoke-static {v0, p1}, Labh;->a(Lalx;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lamt;->a(Lalx;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lamt;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lamt;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lamt;->c(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    invoke-virtual {p0, v0}, Lamt;->a(Z)V

    return-void
.end method
