.class public Lamt;
.super Ljava/lang/Object;


# instance fields
.field private a:Lalx;

.field private b:I

.field private c:Z

.field private d:I

.field private e:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalx;
    .locals 1

    iget-object v0, p0, Lamt;->a:Lalx;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamt;->b:I

    return-void
.end method

.method public a(Lalx;)V
    .locals 0

    iput-object p1, p0, Lamt;->a:Lalx;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lamt;->c:Z

    return-void
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamt;->e:I

    return-void
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamt;->d:I

    return-void
.end method
