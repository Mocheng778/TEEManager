.class public Larj;
.super Lars;


# instance fields
.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/16 v0, 0x9

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lars;-><init>(I[Lamz;)V

    iput-object p1, p0, Larj;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larj;->b:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 2

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-virtual {p0, p1}, Larj;->c([Lakw;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lmm;->a(Ljava/lang/String;)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public b()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
