.class public Laii;
.super Ljava/lang/Object;


# instance fields
.field private a:Lalw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalw;
    .locals 1

    iget-object v0, p0, Laii;->a:Lalw;

    return-object v0
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Laii;->a:Lalw;

    return-void
.end method
