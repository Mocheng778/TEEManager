.class public Laqk;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private final f:I

.field private final g:I

.field private final h:I

.field private final i:I

.field private j:Ljava/util/Vector;

.field private k:Ljava/util/Vector;

.field private final l:I

.field private final m:I

.field private final n:I

.field private o:Ljava/util/Vector;

.field private p:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput v1, p0, Laqk;->f:I

    iput v2, p0, Laqk;->g:I

    iput v3, p0, Laqk;->h:I

    const/4 v0, 0x3

    iput v0, p0, Laqk;->i:I

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laqk;->j:Ljava/util/Vector;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laqk;->k:Ljava/util/Vector;

    iput v1, p0, Laqk;->l:I

    iput v2, p0, Laqk;->m:I

    iput v3, p0, Laqk;->n:I

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laqk;->o:Ljava/util/Vector;

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Laqk;->a:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Laqk;->p:Z

    return-void
.end method

.method public a()Z
    .locals 1

    iget-boolean v0, p0, Laqk;->p:Z

    return v0
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqk;->a:Ljava/lang/String;

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    const-string v0, "|"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_1

    aget-object v3, v2, v0

    const-string v4, "_"

    invoke-static {v3, v4}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v4, v3, v1

    const-string v5, "1"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    new-instance v4, Lala;

    invoke-direct {v4}, Lala;-><init>()V

    aget-object v5, v3, v6

    invoke-virtual {v4, v5}, Lala;->a(Ljava/lang/String;)V

    aget-object v3, v3, v7

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v3}, Lala;->a(I)V

    iget-object v3, p0, Laqk;->k:Ljava/util/Vector;

    invoke-virtual {v3, v4}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    new-instance v4, Lalx;

    invoke-direct {v4}, Lalx;-><init>()V

    aget-object v5, v3, v6

    invoke-virtual {v4, v5}, Lalx;->a(Ljava/lang/String;)V

    aget-object v3, v3, v7

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v3}, Lalx;->a(I)V

    iget-object v3, p0, Laqk;->j:Ljava/util/Vector;

    invoke-virtual {v3, v4}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto :goto_1

    :cond_1
    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Laqk;->b:I

    return v0
.end method

.method public c(Ljava/lang/String;)V
    .locals 2

    const-string v0, "|"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqk;->b:I

    const/4 v1, 0x1

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqk;->c:I

    const/4 v1, 0x2

    aget-object v1, v0, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqk;->d:I

    const/4 v1, 0x3

    aget-object v0, v0, v1

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laqk;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Laqk;->c:I

    return v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Laqk;->d:I

    return v0
.end method

.method public f()I
    .locals 1

    iget v0, p0, Laqk;->e:I

    return v0
.end method

.method public g()Ljava/util/Vector;
    .locals 1

    iget-object v0, p0, Laqk;->j:Ljava/util/Vector;

    return-object v0
.end method

.method public h()Ljava/util/Vector;
    .locals 1

    iget-object v0, p0, Laqk;->k:Ljava/util/Vector;

    return-object v0
.end method

.method public i()Ljava/util/Vector;
    .locals 1

    iget-object v0, p0, Laqk;->o:Ljava/util/Vector;

    return-object v0
.end method
