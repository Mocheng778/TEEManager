.class Laoz;
.super Lbol;


# instance fields
.field final synthetic a:Laoy;


# direct methods
.method constructor <init>(Laoy;)V
    .locals 0

    iput-object p1, p0, Laoz;->a:Laoy;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public c(Laha;)V
    .locals 0

    invoke-virtual {p0, p1}, Laoz;->d(Laha;)V

    return-void
.end method

.method public d(Laha;)V
    .locals 2

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Laha;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Laoz;->a:Laoy;

    invoke-virtual {p1}, Laha;->b()I

    move-result v1

    invoke-static {v0, v1}, Laoy;->a(Laoy;I)I

    :cond_0
    return-void
.end method

.method public e(Ladz;)V
    .locals 3

    iget-object v0, p0, Laoz;->a:Laoy;

    invoke-static {v0}, Laoy;->b(Laoy;)Laok;

    move-result-object v0

    iget-object v1, p0, Laoz;->a:Laoy;

    invoke-static {v1}, Laoy;->a(Laoy;)Lcom/lszb/view/LoadingView;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Ladz;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    new-instance v0, Lcom/lszb/arena/view/ArenaMainView;

    invoke-direct {v0, p1}, Lcom/lszb/arena/view/ArenaMainView;-><init>(Ladz;)V

    iget-object v1, p0, Laoz;->a:Laoy;

    invoke-static {v1}, Laoy;->b(Laoy;)Laok;

    move-result-object v1

    invoke-virtual {v1, v0}, Laok;->a(Laoj;)V

    iget-object v1, p0, Laoz;->a:Laoy;

    invoke-static {v1}, Laoy;->c(Laoy;)Lapa;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Laoz;->a:Laoy;

    invoke-static {v1}, Laoy;->c(Laoy;)Lapa;

    move-result-object v1

    invoke-interface {v1, v0}, Lapa;->a(Laoj;)V

    iget-object v0, p0, Laoz;->a:Laoy;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Laoy;->a(Laoy;Lapa;)Lapa;

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laoz;->a:Laoy;

    invoke-static {v0}, Laoy;->b(Laoy;)Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Ladz;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method
