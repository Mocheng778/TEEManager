.class public Laow;
.super Ljava/lang/Object;

# interfaces
.implements Laoh;


# instance fields
.field final synthetic a:Lcom/lszb/GameMIDlet;


# direct methods
.method public constructor <init>(Lcom/lszb/GameMIDlet;)V
    .locals 0

    iput-object p1, p0, Laow;->a:Lcom/lszb/GameMIDlet;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-static {}, Lcom/lszb/GameMIDlet;->o()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->i()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->p()Lboo;

    move-result-object v0

    invoke-virtual {v0}, Lboo;->i()V

    invoke-static {}, Lbtl;->a()Lbtl;

    move-result-object v0

    invoke-virtual {v0}, Lbtl;->b()V

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    invoke-virtual {v0}, Latt;->j()V

    invoke-static {}, Lbmh;->a()Lbmh;

    move-result-object v0

    invoke-virtual {v0}, Lbmh;->b()V

    invoke-static {}, Lbru;->a()Lbru;

    move-result-object v0

    invoke-virtual {v0}, Lbru;->b()V

    invoke-static {}, Laox;->a()Laox;

    move-result-object v0

    invoke-virtual {v0}, Laox;->b()V

    return-void
.end method
