.class public Laet;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lalr;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lalr;)V
    .locals 0

    iput-object p1, p0, Laet;->a:[Lalr;

    return-void
.end method

.method public a()[Lalr;
    .locals 1

    iget-object v0, p0, Laet;->a:[Lalr;

    return-object v0
.end method
