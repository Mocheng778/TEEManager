.class public Lajh;
.super Ljava/lang/Object;


# direct methods
.method public static a(J)I
    .locals 3

    long-to-float v0, p0

    const/high16 v1, 0x44610000    # 900.0f

    div-float v1, v0, v1

    float-to-int v0, v1

    int-to-float v2, v0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    if-gtz v0, :cond_1

    const/4 v0, 0x1

    :cond_1
    mul-int/lit8 v0, v0, 0x2

    return v0
.end method

.method public static b(J)I
    .locals 3

    long-to-float v0, p0

    const/high16 v1, 0x44610000    # 900.0f

    div-float v1, v0, v1

    float-to-int v0, v1

    int-to-float v2, v0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    if-gtz v0, :cond_1

    const/4 v0, 0x1

    :cond_1
    mul-int/lit8 v0, v0, 0x2

    return v0
.end method

.method public static c(J)I
    .locals 3

    long-to-float v0, p0

    const/high16 v1, 0x44610000    # 900.0f

    div-float v1, v0, v1

    float-to-int v0, v1

    int-to-float v2, v0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    if-gtz v0, :cond_1

    const/4 v0, 0x1

    :cond_1
    mul-int/lit8 v0, v0, 0x2

    return v0
.end method

.method public static d(J)I
    .locals 3

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-gtz v0, :cond_1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    return v0

    :cond_1
    long-to-float v0, p0

    const/high16 v1, 0x43960000    # 300.0f

    div-float v1, v0, v1

    float-to-int v0, v1

    int-to-float v2, v0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_2

    add-int/lit8 v0, v0, 0x1

    :cond_2
    if-gtz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0
.end method
