.class public Ladx;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lajn;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lajn;)V
    .locals 0

    iput-object p1, p0, Ladx;->a:[Lajn;

    return-void
.end method

.method public a()[Lajn;
    .locals 1

    iget-object v0, p0, Ladx;->a:[Lajn;

    return-object v0
.end method
