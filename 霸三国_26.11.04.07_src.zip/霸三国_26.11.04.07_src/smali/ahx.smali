.class public Lahx;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Lajr;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lahx;->a:I

    return-void
.end method

.method public a(Lajr;)V
    .locals 0

    iput-object p1, p0, Lahx;->b:Lajr;

    return-void
.end method
