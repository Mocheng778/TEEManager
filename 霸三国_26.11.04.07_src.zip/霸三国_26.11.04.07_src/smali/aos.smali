.class public interface abstract Laos;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()Z
.end method
