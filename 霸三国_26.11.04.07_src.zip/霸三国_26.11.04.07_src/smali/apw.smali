.class Lapw;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Lapv;


# direct methods
.method constructor <init>(Lapv;)V
    .locals 0

    iput-object p1, p0, Lapw;->a:Lapv;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->a(Lapv;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->b(Lapv;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->c(Lapv;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->d(Lapv;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->e(Lapv;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lapw;->a:Lapv;

    invoke-static {v0}, Lapv;->f(Lapv;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const-string v0, ""

    goto :goto_0
.end method
