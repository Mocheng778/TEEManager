.class public Lapi;
.super Lbwb;


# instance fields
.field private a:Lbxr;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Lbxf;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lbwb;-><init>()V

    const-string v0, "\u884c"

    iput-object v0, p0, Lapi;->b:Ljava/lang/String;

    const-string v0, "\u6392\u540d"

    iput-object v0, p0, Lapi;->c:Ljava/lang/String;

    const-string v0, "\u541b\u4e3b"

    iput-object v0, p0, Lapi;->d:Ljava/lang/String;

    const-string v0, "\u6b21\u6570"

    iput-object v0, p0, Lapi;->e:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->c:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic b(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->g:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic c(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->d:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic d(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->h:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic e(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->e:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic f(Lapi;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapi;->i:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 1

    iget-object v0, p0, Lapi;->f:Lbxf;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapi;->f:Lbxf;

    invoke-virtual {v0}, Lbxf;->b()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public a(Lcar;Lajn;IIIIZ)V
    .locals 4

    if-eqz p2, :cond_0

    invoke-virtual {p2}, Lajn;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapi;->g:Ljava/lang/String;

    invoke-virtual {p2}, Lajn;->h()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapi;->h:Ljava/lang/String;

    invoke-virtual {p2}, Lajn;->a()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapi;->i:Ljava/lang/String;

    invoke-virtual {p2}, Lajn;->f()I

    move-result v0

    invoke-super {p0, v0}, Lbwb;->a(I)V

    :goto_0
    if-eqz p7, :cond_1

    iget-object v0, p0, Lapi;->f:Lbxf;

    invoke-virtual {v0}, Lbxf;->m()V

    :goto_1
    iget-object v0, p0, Lapi;->f:Lbxf;

    iget-object v1, p0, Lapi;->f:Lbxf;

    invoke-virtual {v1}, Lbxf;->a()I

    move-result v1

    sub-int v1, p5, v1

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v1, p3

    iget-object v2, p0, Lapi;->f:Lbxf;

    invoke-virtual {v2}, Lbxf;->j()I

    move-result v2

    sub-int/2addr v1, v2

    iget-object v2, p0, Lapi;->f:Lbxf;

    invoke-virtual {v2}, Lbxf;->b()I

    move-result v2

    sub-int v2, p6, v2

    div-int/lit8 v2, v2, 0x2

    add-int/2addr v2, p4

    iget-object v3, p0, Lapi;->f:Lbxf;

    invoke-virtual {v3}, Lbxf;->k()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void

    :cond_0
    invoke-super {p0}, Lbwb;->b()V

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lapi;->f:Lbxf;

    invoke-virtual {v0}, Lbxf;->n()V

    goto :goto_1
.end method

.method public a(Ljava/util/Hashtable;I)V
    .locals 3

    :try_start_0
    new-instance v0, Lbxr;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "arena_rank_row.bin"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v2

    invoke-direct {v0, v1, p1, v2}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    iput-object v0, p0, Lapi;->a:Lbxr;

    iget-object v0, p0, Lapi;->a:Lbxr;

    invoke-static {v0, p1}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    iget-object v0, p0, Lapi;->a:Lbxr;

    invoke-super {p0, v0}, Lbwb;->a(Lbxr;)V

    iget-object v0, p0, Lapi;->a:Lbxr;

    iget-object v1, p0, Lapi;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lapi;->f:Lbxf;

    iget-object v0, p0, Lapi;->f:Lbxf;

    invoke-virtual {v0, p2}, Lbxf;->e(I)V

    new-instance v1, Lapj;

    invoke-direct {v1, p0}, Lapj;-><init>(Lapi;)V

    iget-object v0, p0, Lapi;->a:Lbxr;

    iget-object v2, p0, Lapi;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lapi;->a:Lbxr;

    iget-object v2, p0, Lapi;->d:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Lapi;->a:Lbxr;

    iget-object v2, p0, Lapi;->e:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method
