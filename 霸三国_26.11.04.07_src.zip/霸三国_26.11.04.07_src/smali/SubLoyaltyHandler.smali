.class public LSubLoyaltyHandler;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/hero/view/SubLoyatlyView;


# direct methods
.method public constructor <init>(Lcom/lszb/hero/view/SubLoyatlyView;)V
    .locals 0

    iput-object p1, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public I(Laej;)V
    .locals 3

    iget-object v0, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-virtual {v0}, Lcom/lszb/hero/view/SubLoyatlyView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-virtual {v1}, Lcom/lszb/hero/view/SubLoyatlyView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-virtual {v0}, Lcom/lszb/hero/view/SubLoyatlyView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-virtual {v1}, Lcom/lszb/hero/view/SubLoyatlyView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    return-void

    :cond_0
    iget-object v0, p0, LSubLoyaltyHandler;->a:Lcom/lszb/hero/view/SubLoyatlyView;

    invoke-virtual {v0}, Lcom/lszb/hero/view/SubLoyatlyView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    return-void
.end method
