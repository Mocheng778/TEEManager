.class public Labf;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lalv;Ljava/io/DataInputStream;)V
    .locals 2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lalv;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lalv;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lalv;->a(I)V

    return-void
.end method
