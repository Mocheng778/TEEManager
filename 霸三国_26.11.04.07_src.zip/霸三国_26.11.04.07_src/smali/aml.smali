.class public Laml;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:J

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laml;->b:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laml;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laml;->d:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Laml;->c:Ljava/lang/String;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laml;->c:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Laml;->b:I

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Laml;->d:J

    return-wide v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Laml;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Laml;->e:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Laml;->f:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Laml;->f:I

    return v0
.end method
