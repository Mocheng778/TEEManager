.class public Larh;
.super Ljava/lang/Object;


# direct methods
.method public static a(ILbyr;Ljava/util/Hashtable;)Lbze;
    .locals 7

    const/4 v1, 0x0

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p0}, Laqj;->m(I)[Ljava/lang/String;

    move-result-object v3

    move v0, v1

    :goto_0
    array-length v2, v3

    if-ge v0, v2, :cond_0

    aget-object v2, v3, v0

    invoke-static {v2, p1, p2}, Lbvy;->a(Ljava/lang/String;Lbyr;Ljava/util/Hashtable;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p0}, Laqj;->n(I)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    invoke-static {v4, p1, p2}, Lbvy;->a(Ljava/lang/String;Lbyr;Ljava/util/Hashtable;)V

    :cond_1
    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v0

    invoke-virtual {v0, p0}, Laqj;->p(I)I

    move-result v0

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, p0}, Laqj;->q(I)I

    move-result v5

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v2

    invoke-virtual {v2, p0}, Laqj;->r(I)I

    move-result v6

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    :goto_1
    return-object v0

    :pswitch_0
    new-instance v0, Lard;

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v6}, Lard;-><init>(Lbyr;Ljava/util/Hashtable;[Ljava/lang/String;Ljava/lang/String;II)V

    goto :goto_1

    :pswitch_1
    new-instance v0, Larg;

    aget-object v3, v3, v1

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v6}, Larg;-><init>(Lbyr;Ljava/util/Hashtable;Ljava/lang/String;Ljava/lang/String;II)V

    goto :goto_1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
