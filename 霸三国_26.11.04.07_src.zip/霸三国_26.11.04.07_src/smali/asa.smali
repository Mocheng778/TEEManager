.class public Lasa;
.super Lasc;


# instance fields
.field private b:D

.field private c:D

.field private d:D

.field private e:D

.field private f:I

.field private g:I


# direct methods
.method public constructor <init>(Laqs;DDI)V
    .locals 4

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Laqs;->b(I)[Lbyq;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lasc;-><init>(Laqs;[Lbyq;)V

    iput-wide p2, p0, Lasa;->b:D

    iput-wide p4, p0, Lasa;->c:D

    iput p6, p0, Lasa;->f:I

    invoke-virtual {p1}, Laqs;->a()D

    move-result-wide v0

    sub-double v0, p2, v0

    int-to-double v2, p6

    div-double/2addr v0, v2

    iput-wide v0, p0, Lasa;->d:D

    invoke-virtual {p1}, Laqs;->b()D

    move-result-wide v0

    sub-double v0, p4, v0

    int-to-double v2, p6

    div-double/2addr v0, v2

    iput-wide v0, p0, Lasa;->e:D

    invoke-virtual {p0, p2, p3, p4, p5}, Lasa;->a(DD)I

    move-result v0

    invoke-virtual {p1, v0}, Laqs;->a(I)V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    invoke-virtual {p0}, Lasa;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lbyq;->b()V

    :cond_0
    iget v0, p0, Lasa;->g:I

    iget v1, p0, Lasa;->f:I

    if-ge v0, v1, :cond_1

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v0

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v1

    invoke-virtual {v1}, Laqs;->a()D

    move-result-wide v1

    iget-wide v3, p0, Lasa;->d:D

    add-double/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Laqs;->a(D)V

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v0

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v1

    invoke-virtual {v1}, Laqs;->b()D

    move-result-wide v1

    iget-wide v3, p0, Lasa;->e:D

    add-double/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Laqs;->b(D)V

    iget v0, p0, Lasa;->g:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lasa;->g:I

    :goto_0
    return-void

    :cond_1
    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v0

    iget-wide v1, p0, Lasa;->b:D

    invoke-virtual {v0, v1, v2}, Laqs;->a(D)V

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v0

    iget-wide v1, p0, Lasa;->c:D

    invoke-virtual {v0, v1, v2}, Laqs;->b(D)V

    invoke-virtual {p0}, Lasa;->b()Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->s()V

    goto :goto_0
.end method
