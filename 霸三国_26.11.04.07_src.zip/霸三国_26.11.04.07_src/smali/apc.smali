.class public Lapc;
.super Lbwj;


# instance fields
.field final synthetic a:Lcom/lszb/arena/view/ArenaAddTimesView;


# direct methods
.method public constructor <init>(Lcom/lszb/arena/view/ArenaAddTimesView;)V
    .locals 0

    iput-object p1, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-direct {p0}, Lbwj;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    invoke-static {}, Laoy;->a()Laoy;

    move-result-object v0

    invoke-virtual {v0}, Laoy;->b()I

    move-result v0

    iget-object v1, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->a(Lcom/lszb/arena/view/ArenaAddTimesView;)I

    move-result v1

    mul-int/2addr v0, v1

    iget-object v1, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->c(Lcom/lszb/arena/view/ArenaAddTimesView;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "${gold}"

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${num}"

    iget-object v2, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v2}, Lcom/lszb/arena/view/ArenaAddTimesView;->a(Lcom/lszb/arena/view/ArenaAddTimesView;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a(Lcom/lszb/view/ConfirmDialogView;)V
    .locals 2

    iget-object v0, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaAddTimesView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/LoadingView;

    invoke-direct {v1}, Lcom/lszb/view/LoadingView;-><init>()V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Lapc;->a:Lcom/lszb/arena/view/ArenaAddTimesView;

    invoke-static {v1}, Lcom/lszb/arena/view/ArenaAddTimesView;->a(Lcom/lszb/arena/view/ArenaAddTimesView;)I

    move-result v1

    invoke-virtual {v0, v1}, Lmm;->a(I)V

    return-void
.end method
