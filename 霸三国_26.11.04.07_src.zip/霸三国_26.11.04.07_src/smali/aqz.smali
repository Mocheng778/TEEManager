.class public Laqz;
.super Laqu;


# instance fields
.field private a:I

.field private b:I

.field private c:Laqr;

.field private d:[I

.field private e:[[I


# direct methods
.method public constructor <init>(Laqg;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Laqu;-><init>()V

    const-string v0, "_"

    invoke-static {p2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v0, v2, v1

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laqz;->a:I

    aget-object v0, v2, v8

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laqz;->b:I

    const/4 v0, 0x3

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/4 v0, 0x5

    aget-object v0, v2, v0

    const-string v4, "-"

    invoke-static {v0, v4}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    array-length v0, v4

    new-array v0, v0, [I

    iput-object v0, p0, Laqz;->d:[I

    array-length v0, v4

    filled-new-array {v0, v9}, [I

    move-result-object v0

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v5, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[I

    iput-object v0, p0, Laqz;->e:[[I

    move v0, v1

    :goto_0
    array-length v5, v4

    if-ge v0, v5, :cond_0

    aget-object v5, v4, v0

    const-string v6, ","

    invoke-static {v5, v6}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Laqz;->d:[I

    aget-object v7, v5, v1

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    aput v7, v6, v0

    iget-object v6, p0, Laqz;->e:[[I

    aget-object v6, v6, v0

    aget-object v7, v5, v8

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    aput v7, v6, v1

    iget-object v6, p0, Laqz;->e:[[I

    aget-object v6, v6, v0

    aget-object v5, v5, v9

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    aput v5, v6, v8

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    if-eqz v3, :cond_1

    iget v0, p0, Laqz;->a:I

    invoke-virtual {p1, v0, v3}, Laqg;->a(II)Laqr;

    move-result-object v0

    iput-object v0, p0, Laqz;->c:Laqr;

    :goto_1
    return-void

    :cond_1
    const-string v0, "1"

    aget-object v1, v2, v9

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget v0, p0, Laqz;->a:I

    invoke-virtual {p1, v0}, Laqg;->b(I)Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->h()Laqr;

    move-result-object v0

    iput-object v0, p0, Laqz;->c:Laqr;

    goto :goto_1

    :cond_2
    iget v0, p0, Laqz;->a:I

    invoke-virtual {p1, v0}, Laqg;->b(I)Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->i()Laqr;

    move-result-object v0

    iput-object v0, p0, Laqz;->c:Laqr;

    goto :goto_1
.end method


# virtual methods
.method public a(Laqg;)V
    .locals 5

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Laqz;->d:[I

    array-length v1, v1

    if-ge v0, v1, :cond_0

    iget v1, p0, Laqz;->a:I

    iget-object v2, p0, Laqz;->c:Laqr;

    iget-object v3, p0, Laqz;->d:[I

    aget v3, v3, v0

    iget v4, p0, Laqz;->b:I

    invoke-virtual {p1, v1, v2, v3, v4}, Laqg;->a(ILaqr;II)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method
