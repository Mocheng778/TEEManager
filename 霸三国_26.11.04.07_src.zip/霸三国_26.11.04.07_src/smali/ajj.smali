.class public Lajj;
.super Ljava/lang/Object;


# direct methods
.method public static a(II)I
    .locals 2

    invoke-static {p1}, Laji;->a(I)I

    move-result v1

    div-int v0, p0, v1

    rem-int v1, p0, v1

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    return v0
.end method
