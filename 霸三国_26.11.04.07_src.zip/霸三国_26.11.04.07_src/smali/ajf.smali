.class public Lajf;
.super Ljava/lang/Object;


# static fields
.field public static a:F

.field private static b:F

.field private static c:F


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/high16 v0, 0x3f800000    # 1.0f

    sput v0, Lajf;->b:F

    sput v0, Lajf;->c:F

    const/high16 v0, 0x41f00000    # 30.0f

    sput v0, Lajf;->a:F

    return-void
.end method

.method public static a(I)I
    .locals 2

    const/16 v0, 0x14

    rem-int/lit8 v1, p0, 0x5

    if-eqz v1, :cond_0

    div-int/lit8 v1, p0, 0x5

    add-int/lit8 v1, v1, 0x1

    :goto_0
    if-le v1, v0, :cond_1

    :goto_1
    return v0

    :cond_0
    div-int/lit8 v1, p0, 0x5

    goto :goto_0

    :cond_1
    move v0, v1

    goto :goto_1
.end method

.method public static a(II)I
    .locals 1

    mul-int v0, p0, p1

    div-int/lit8 v0, v0, 0x5

    return v0
.end method

.method public static a(III)I
    .locals 3

    invoke-static {p0, p1}, Lajf;->a(II)I

    move-result v1

    invoke-static {p2}, Laji;->a(I)I

    move-result v2

    div-int v0, v1, v2

    rem-int/2addr v1, v2

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    int-to-float v0, v0

    sget v1, Lajf;->c:F

    mul-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method public static a(Lakw;)I
    .locals 3

    const/high16 v2, 0x43960000    # 300.0f

    invoke-virtual {p0}, Lakw;->t()I

    move-result v0

    invoke-virtual {p0}, Lakw;->u()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Lakw;->v()I

    move-result v1

    add-int/2addr v0, v1

    rem-int/lit16 v0, v0, 0x12c

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lakw;->t()I

    move-result v0

    invoke-virtual {p0}, Lakw;->u()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Lakw;->v()I

    move-result v1

    add-int/2addr v0, v1

    int-to-float v0, v0

    div-float/2addr v0, v2

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    float-to-int v0, v0

    mul-int/lit16 v0, v0, 0x2710

    :goto_0
    return v0

    :cond_0
    invoke-virtual {p0}, Lakw;->t()I

    move-result v0

    invoke-virtual {p0}, Lakw;->u()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0}, Lakw;->v()I

    move-result v1

    add-int/2addr v0, v1

    int-to-float v0, v0

    div-float/2addr v0, v2

    float-to-int v0, v0

    mul-int/lit16 v0, v0, 0x2710

    goto :goto_0
.end method

.method public static a(Lakw;I)I
    .locals 2

    invoke-static {p0}, Lajf;->b(Lakw;)I

    move-result v0

    invoke-static {p1}, Laji;->a(I)I

    move-result v1

    div-int/2addr v0, v1

    rem-int v1, v0, v1

    if-lez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    int-to-float v0, v0

    sget v1, Lajf;->b:F

    mul-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method public static a(Lakw;II)I
    .locals 3

    invoke-static {p0, p2}, Lajf;->b(Lakw;I)I

    move-result v1

    invoke-static {p1}, Laji;->a(I)I

    move-result v2

    div-int v0, v1, v2

    rem-int/2addr v1, v2

    if-eqz v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    return v0
.end method

.method public static b(Lakw;)I
    .locals 1

    invoke-static {p0}, Lajf;->a(Lakw;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x2

    return v0
.end method

.method public static b(Lakw;I)I
    .locals 1

    invoke-virtual {p0}, Lakw;->w()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1

    mul-int/2addr v0, p1

    return v0
.end method

.method public static c(Lakw;)I
    .locals 2

    invoke-virtual {p0}, Lakw;->n()I

    move-result v0

    mul-int/lit16 v0, v0, 0x3e8

    invoke-virtual {p0}, Lakw;->w()I

    move-result v1

    mul-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x32

    return v0
.end method

.method public static c(Lakw;I)I
    .locals 3

    invoke-static {p0}, Lajf;->c(Lakw;)I

    move-result v0

    invoke-static {p1}, Laji;->a(I)I

    move-result v1

    rem-int v2, v0, v1

    div-int/2addr v0, v1

    if-eqz v2, :cond_0

    add-int/lit8 v0, v0, 0x1

    :cond_0
    return v0
.end method
