.class public Lafi;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lale;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lale;
    .locals 1

    iget-object v0, p0, Lafi;->a:Lale;

    return-object v0
.end method

.method public a(Lale;)V
    .locals 0

    iput-object p1, p0, Lafi;->a:Lale;

    return-void
.end method
