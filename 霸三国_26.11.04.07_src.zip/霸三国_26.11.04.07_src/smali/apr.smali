.class public Lapr;
.super Ljava/lang/Object;


# instance fields
.field private a:Lbyq;

.field private b:Lbyq;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lbyq;Lbyq;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lapr;->a:Lbyq;

    iput-object p2, p0, Lapr;->b:Lbyq;

    iput-object p3, p0, Lapr;->c:Ljava/lang/String;

    iput-object p4, p0, Lapr;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Lbyq;
    .locals 1

    iget-object v0, p0, Lapr;->a:Lbyq;

    return-object v0
.end method

.method public b()Lbyq;
    .locals 1

    iget-object v0, p0, Lapr;->b:Lbyq;

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapr;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapr;->d:Ljava/lang/String;

    return-object v0
.end method
