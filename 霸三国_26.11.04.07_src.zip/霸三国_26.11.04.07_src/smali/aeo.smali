.class public Laeo;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Laks;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Laks;)V
    .locals 0

    iput-object p1, p0, Laeo;->a:[Laks;

    return-void
.end method

.method public a()[Laks;
    .locals 1

    iget-object v0, p0, Laeo;->a:[Laks;

    return-object v0
.end method
