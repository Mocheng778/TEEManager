.class public Lajd;
.super Ljava/lang/Object;


# instance fields
.field private a:Lframework/server/game/IGameRuleHelper;


# direct methods
.method public constructor <init>(Lframework/server/game/IGameRuleHelper;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const-string v1, "1,4,7,5,"

    invoke-interface {v0, v4, v4, v4, v1}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const-string v1, "5,8,"

    invoke-interface {v0, v3, v3, v3, v1}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/4 v1, 0x4

    const-string v2, "2,6,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/4 v1, 0x5

    const-string v2, "3,7,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/4 v1, 0x7

    const-string v2, "2,5,10,"

    invoke-interface {v0, v1, v5, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8

    const-string v2, "3,11,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9

    const-string v2, "6,13,18,14,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa

    const-string v2, "7,14,19,15,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb

    const-string v2, "8,15,20,16,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc

    const-string v2, "16,21,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd

    const-string v2, "9,17,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe

    const-string v2, "10,18,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf

    const-string v2, "11,19,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10

    const-string v2, "12,20,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12

    const-string v2, "9,14,23,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13

    const-string v2, "10,15,24,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14

    const-string v2, "11,16,25,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15

    const-string v2, "12,26,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16

    const-string v2, "17,28,35,29,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17

    const-string v2, "18,29,36,30,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18

    const-string v2, "19,30,37,31,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19

    const-string v2, "20,31,38,32,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a

    const-string v2, "21,32,39,33,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b

    const-string v2, "33,40,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c

    const-string v2, "22,34,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d

    const-string v2, "23,35,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e

    const-string v2, "24,36,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f

    const-string v2, "25,37,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20

    const-string v2, "26,38,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21

    const-string v2, "27,39,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23

    const-string v2, "22,29,42,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24

    const-string v2, "23,30,43,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25

    const-string v2, "24,31,44,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26

    const-string v2, "25,32,45,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27

    const-string v2, "26,33,46,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28

    const-string v2, "27,47,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29

    const-string v2, "34,49,58,50,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a

    const-string v2, "35,50,59,51,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b

    const-string v2, "36,51,60,52,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c

    const-string v2, "37,52,61,53,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d

    const-string v2, "38,53,62,54,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e

    const-string v2, "39,54,63,55,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f

    const-string v2, "40,55,64,56,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30

    const-string v2, "56,65,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31

    const-string v2, "41,57,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32

    const-string v2, "42,58,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33

    const-string v2, "43,59,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34

    const-string v2, "44,60,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35

    const-string v2, "45,61,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36

    const-string v2, "46,62,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37

    const-string v2, "47,63,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38

    const-string v2, "48,64,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a

    const-string v2, "41,50,67,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b

    const-string v2, "42,51,68,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c

    const-string v2, "43,52,69,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d

    const-string v2, "44,53,70,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e

    const-string v2, "45,54,71,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f

    const-string v2, "46,55,72,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40

    const-string v2, "47,56,73,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41

    const-string v2, "48,74,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42

    const-string v2, "57,76,87,77,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43

    const-string v2, "58,77,88,78,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44

    const-string v2, "59,78,89,79,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45

    const-string v2, "60,79,90,80,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46

    const-string v2, "61,80,91,81,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47

    const-string v2, "62,81,92,82,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48

    const-string v2, "63,82,93,83,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x49

    const-string v2, "64,83,94,84,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4a

    const-string v2, "65,84,95,85,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4b

    const-string v2, "85,96,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4c

    const-string v2, "66,86,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4d

    const-string v2, "67,87,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4e

    const-string v2, "68,88,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x4f

    const-string v2, "69,89,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x50

    const-string v2, "70,90,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x51

    const-string v2, "71,91,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x52

    const-string v2, "72,92,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x53

    const-string v2, "73,93,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x54

    const-string v2, "74,94,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x55

    const-string v2, "75,95,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x57

    const-string v2, "66,77,98,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x58

    const-string v2, "67,78,99,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x59

    const-string v2, "68,79,100,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5a

    const-string v2, "69,80,101,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5b

    const-string v2, "70,81,102,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5c

    const-string v2, "71,82,103,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5d

    const-string v2, "72,83,104,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5e

    const-string v2, "73,84,105,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x5f

    const-string v2, "74,85,106,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x60

    const-string v2, "75,107,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x61

    const-string v2, "86,109,122,110,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x62

    const-string v2, "87,110,123,111,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x63

    const-string v2, "88,111,124,112,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x64

    const-string v2, "89,112,125,113,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x65

    const-string v2, "90,113,126,114,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x66

    const-string v2, "91,114,127,115,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x67

    const-string v2, "92,115,128,116,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x68

    const-string v2, "93,116,129,117,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x69

    const-string v2, "94,117,130,118,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6a

    const-string v2, "95,118,131,119,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6b

    const-string v2, "96,119,132,120,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6c

    const-string v2, "120,133,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6d

    const-string v2, "97,121,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6e

    const-string v2, "98,122,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x6f

    const-string v2, "99,123,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x70

    const-string v2, "100,124,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x71

    const-string v2, "101,125,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x72

    const-string v2, "102,126,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x73

    const-string v2, "103,127,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x74

    const-string v2, "104,128,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x75

    const-string v2, "105,129,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x76

    const-string v2, "106,130,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x77

    const-string v2, "107,131,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x78

    const-string v2, "108,132,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7a

    const-string v2, "97,110,135,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7b

    const-string v2, "98,111,136,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7c

    const-string v2, "99,112,137,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7d

    const-string v2, "100,113,138,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7e

    const-string v2, "101,114,139,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x7f

    const-string v2, "102,115,140,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x80

    const-string v2, "103,116,141,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x81

    const-string v2, "104,117,142,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x82

    const-string v2, "105,118,143,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x83

    const-string v2, "106,119,144,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x84

    const-string v2, "107,120,145,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x85

    const-string v2, "108,146,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x86

    const-string v2, "121,148,163,149,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x87

    const-string v2, "122,149,164,150,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x88

    const-string v2, "123,150,165,151,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x89

    const-string v2, "124,151,166,152,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8a

    const-string v2, "125,152,167,153,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8b

    const-string v2, "126,153,168,154,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8c

    const-string v2, "127,154,169,155,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8d

    const-string v2, "128,155,170,156,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8e

    const-string v2, "129,156,171,157,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x8f

    const-string v2, "130,157,172,158,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x90

    const-string v2, "131,158,173,159,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x91

    const-string v2, "132,159,174,160,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x92

    const-string v2, "133,160,175,161,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x93

    const-string v2, "161,176,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x94

    const-string v2, "134,162,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x95

    const-string v2, "135,163,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x96

    const-string v2, "136,164,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x97

    const-string v2, "137,165,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x98

    const-string v2, "138,166,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x99

    const-string v2, "139,167,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9a

    const-string v2, "140,168,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9b

    const-string v2, "141,169,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9c

    const-string v2, "142,170,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9d

    const-string v2, "143,171,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9e

    const-string v2, "144,172,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x9f

    const-string v2, "145,173,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa0

    const-string v2, "146,174,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa1

    const-string v2, "147,175,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa3

    const-string v2, "134,149,178,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa4

    const-string v2, "135,150,179,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa5

    const-string v2, "136,151,180,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa6

    const-string v2, "137,152,181,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa7

    const-string v2, "138,153,182,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa8

    const-string v2, "139,154,183,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xa9

    const-string v2, "140,155,184,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xaa

    const-string v2, "141,156,185,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xab

    const-string v2, "142,157,186,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xac

    const-string v2, "143,158,187,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xad

    const-string v2, "144,159,188,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xae

    const-string v2, "145,160,189,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xaf

    const-string v2, "146,161,190,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb0

    const-string v2, "147,191,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb1

    const-string v2, "162,193,210,194,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb2

    const-string v2, "163,194,211,195,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb3

    const-string v2, "164,195,212,196,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb4

    const-string v2, "165,196,213,197,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb5

    const-string v2, "166,197,214,198,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb6

    const-string v2, "167,198,215,199,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb7

    const-string v2, "168,199,216,200,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb8

    const-string v2, "169,200,217,201,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xb9

    const-string v2, "170,201,218,202,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xba

    const-string v2, "171,202,219,203,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xbb

    const-string v2, "172,203,220,204,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xbc

    const-string v2, "173,204,221,205,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xbd

    const-string v2, "174,205,222,206,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xbe

    const-string v2, "175,206,223,207,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xbf

    const-string v2, "176,207,224,208,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc0

    const-string v2, "208,225,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc1

    const-string v2, "177,209,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc2

    const-string v2, "178,210,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc3

    const-string v2, "179,211,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc4

    const-string v2, "180,212,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc5

    const-string v2, "181,213,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc6

    const-string v2, "182,214,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc7

    const-string v2, "183,215,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc8

    const-string v2, "184,216,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xc9

    const-string v2, "185,217,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xca

    const-string v2, "186,218,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xcb

    const-string v2, "187,219,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xcc

    const-string v2, "188,220,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xcd

    const-string v2, "189,221,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xce

    const-string v2, "190,222,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xcf

    const-string v2, "191,223,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd0

    const-string v2, "192,224,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd2

    const-string v2, "177,194,227,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd3

    const-string v2, "178,195,228,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd4

    const-string v2, "179,196,229,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd5

    const-string v2, "180,197,230,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd6

    const-string v2, "181,198,231,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd7

    const-string v2, "182,199,232,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd8

    const-string v2, "183,200,233,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xd9

    const-string v2, "184,201,234,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xda

    const-string v2, "185,202,235,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xdb

    const-string v2, "186,203,236,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xdc

    const-string v2, "187,204,237,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xdd

    const-string v2, "188,205,238,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xde

    const-string v2, "189,206,239,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xdf

    const-string v2, "190,207,240,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe0

    const-string v2, "191,208,241,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe1

    const-string v2, "192,242,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe2

    const-string v2, "209,244,263,245,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe3

    const-string v2, "210,245,264,246,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe4

    const-string v2, "211,246,265,247,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe5

    const-string v2, "212,247,266,248,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe6

    const-string v2, "213,248,267,249,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe7

    const-string v2, "214,249,268,250,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe8

    const-string v2, "215,250,269,251,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xe9

    const-string v2, "216,251,270,252,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xea

    const-string v2, "217,252,271,253,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xeb

    const-string v2, "218,253,272,254,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xec

    const-string v2, "219,254,273,255,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xed

    const-string v2, "220,255,274,256,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xee

    const-string v2, "221,256,275,257,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xef

    const-string v2, "222,257,276,258,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf0

    const-string v2, "223,258,277,259,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf1

    const-string v2, "224,259,278,260,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf2

    const-string v2, "225,260,279,261,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf3

    const-string v2, "261,280,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf4

    const-string v2, "226,262,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf5

    const-string v2, "227,263,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf6

    const-string v2, "228,264,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf7

    const-string v2, "229,265,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf8

    const-string v2, "230,266,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xf9

    const-string v2, "231,267,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xfa

    const-string v2, "232,268,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xfb

    const-string v2, "233,269,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xfc

    const-string v2, "234,270,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xfd

    const-string v2, "235,271,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xfe

    const-string v2, "236,272,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0xff

    const-string v2, "237,273,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x100

    const-string v2, "238,274,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x101

    const-string v2, "239,275,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x102

    const-string v2, "240,276,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x103

    const-string v2, "241,277,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x104

    const-string v2, "242,278,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x105

    const-string v2, "243,279,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x107

    const-string v2, "226,245,282,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x108

    const-string v2, "227,246,283,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x109

    const-string v2, "228,247,284,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10a

    const-string v2, "229,248,285,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10b

    const-string v2, "230,249,286,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10c

    const-string v2, "231,250,287,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10d

    const-string v2, "232,251,288,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10e

    const-string v2, "233,252,289,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x10f

    const-string v2, "234,253,290,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x110

    const-string v2, "235,254,291,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x111

    const-string v2, "236,255,292,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x112

    const-string v2, "237,256,293,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x113

    const-string v2, "238,257,294,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x114

    const-string v2, "239,258,295,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x115

    const-string v2, "240,259,296,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x116

    const-string v2, "241,260,297,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x117

    const-string v2, "242,261,298,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x118

    const-string v2, "243,299,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x119

    const-string v2, "262,301,322,302,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11a

    const-string v2, "263,302,323,303,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11b

    const-string v2, "264,303,324,304,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11c

    const-string v2, "265,304,325,305,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11d

    const-string v2, "266,305,326,306,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11e

    const-string v2, "267,306,327,307,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x11f

    const-string v2, "268,307,328,308,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x120

    const-string v2, "269,308,329,309,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x121

    const-string v2, "270,309,330,310,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x122

    const-string v2, "271,310,331,311,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x123

    const-string v2, "272,311,332,312,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x124

    const-string v2, "273,312,333,313,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x125

    const-string v2, "274,313,334,314,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x126

    const-string v2, "275,314,335,315,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x127

    const-string v2, "276,315,336,316,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x128

    const-string v2, "277,316,337,317,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x129

    const-string v2, "278,317,338,318,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12a

    const-string v2, "279,318,339,319,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12b

    const-string v2, "280,319,340,320,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12c

    const-string v2, "320,341,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12d

    const-string v2, "281,321,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12e

    const-string v2, "282,322,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x12f

    const-string v2, "283,323,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x130

    const-string v2, "284,324,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x131

    const-string v2, "285,325,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x132

    const-string v2, "286,326,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x133

    const-string v2, "287,327,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x134

    const-string v2, "288,328,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x135

    const-string v2, "289,329,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x136

    const-string v2, "290,330,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x137

    const-string v2, "291,331,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x138

    const-string v2, "292,332,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x139

    const-string v2, "293,333,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13a

    const-string v2, "294,334,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13b

    const-string v2, "295,335,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13c

    const-string v2, "296,336,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13d

    const-string v2, "297,337,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13e

    const-string v2, "298,338,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x13f

    const-string v2, "299,339,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x140

    const-string v2, "300,340,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x142

    const-string v2, "281,302,343,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x143

    const-string v2, "282,303,344,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x144

    const-string v2, "283,304,345,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x145

    const-string v2, "284,305,346,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x146

    const-string v2, "285,306,347,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x147

    const-string v2, "286,307,348,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x148

    const-string v2, "287,308,349,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x149

    const-string v2, "288,309,350,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14a

    const-string v2, "289,310,351,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14b

    const-string v2, "290,311,352,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14c

    const-string v2, "291,312,353,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14d

    const-string v2, "292,313,354,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14e

    const-string v2, "293,314,355,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x14f

    const-string v2, "294,315,356,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x150

    const-string v2, "295,316,357,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x151

    const-string v2, "296,317,358,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x152

    const-string v2, "297,318,359,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x153

    const-string v2, "298,319,360,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x154

    const-string v2, "299,320,361,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x155

    const-string v2, "300,362,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x156

    const-string v2, "321,364,387,365,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x157

    const-string v2, "322,365,388,366,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x158

    const-string v2, "323,366,389,367,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x159

    const-string v2, "324,367,390,368,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15a

    const-string v2, "325,368,391,369,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15b

    const-string v2, "326,369,392,370,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15c

    const-string v2, "327,370,393,371,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15d

    const-string v2, "328,371,394,372,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15e

    const-string v2, "329,372,395,373,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x15f

    const-string v2, "330,373,396,374,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x160

    const-string v2, "331,374,397,375,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x161

    const-string v2, "332,375,398,376,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x162

    const-string v2, "333,376,399,377,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x163

    const-string v2, "334,377,400,378,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x164

    const-string v2, "335,378,401,379,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x165

    const-string v2, "336,379,402,380,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x166

    const-string v2, "337,380,403,381,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x167

    const-string v2, "338,381,404,382,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x168

    const-string v2, "339,382,405,383,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x169

    const-string v2, "340,383,406,384,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16a

    const-string v2, "341,384,407,385,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16b

    const-string v2, "385,408,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16c

    const-string v2, "342,386,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16d

    const-string v2, "343,387,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16e

    const-string v2, "344,388,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x16f

    const-string v2, "345,389,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x170

    const-string v2, "346,390,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x171

    const-string v2, "347,391,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x172

    const-string v2, "348,392,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x173

    const-string v2, "349,393,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x174

    const-string v2, "350,394,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x175

    const-string v2, "351,395,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x176

    const-string v2, "352,396,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x177

    const-string v2, "353,397,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x178

    const-string v2, "354,398,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x179

    const-string v2, "355,399,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17a

    const-string v2, "356,400,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17b

    const-string v2, "357,401,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17c

    const-string v2, "358,402,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17d

    const-string v2, "359,403,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17e

    const-string v2, "360,404,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x17f

    const-string v2, "361,405,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x180

    const-string v2, "362,406,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x181

    const-string v2, "363,407,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x183

    const-string v2, "342,365,410,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x184

    const-string v2, "343,366,411,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x185

    const-string v2, "344,367,412,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x186

    const-string v2, "345,368,413,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x187

    const-string v2, "346,369,414,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x188

    const-string v2, "347,370,415,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x189

    const-string v2, "348,371,416,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18a

    const-string v2, "349,372,417,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18b

    const-string v2, "350,373,418,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18c

    const-string v2, "351,374,419,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18d

    const-string v2, "352,375,420,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18e

    const-string v2, "353,376,421,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x18f

    const-string v2, "354,377,422,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x190

    const-string v2, "355,378,423,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x191

    const-string v2, "356,379,424,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x192

    const-string v2, "357,380,425,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x193

    const-string v2, "358,381,426,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x194

    const-string v2, "359,382,427,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x195

    const-string v2, "360,383,428,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x196

    const-string v2, "361,384,429,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x197

    const-string v2, "362,385,430,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x198

    const-string v2, "363,431,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x199

    const-string v2, "386,433,458,434,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19a

    const-string v2, "387,434,459,435,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19b

    const-string v2, "388,435,460,436,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19c

    const-string v2, "389,436,461,437,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19d

    const-string v2, "390,437,462,438,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19e

    const-string v2, "391,438,463,439,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x19f

    const-string v2, "392,439,464,440,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a0

    const-string v2, "393,440,465,441,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a1

    const-string v2, "394,441,466,442,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a2

    const-string v2, "395,442,467,443,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a3

    const-string v2, "396,443,468,444,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a4

    const-string v2, "397,444,469,445,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a5

    const-string v2, "398,445,470,446,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a6

    const-string v2, "399,446,471,447,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a7

    const-string v2, "400,447,472,448,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a8

    const-string v2, "401,448,473,449,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1a9

    const-string v2, "402,449,474,450,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1aa

    const-string v2, "403,450,475,451,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ab

    const-string v2, "404,451,476,452,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ac

    const-string v2, "405,452,477,453,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ad

    const-string v2, "406,453,478,454,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ae

    const-string v2, "407,454,479,455,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1af

    const-string v2, "408,455,480,456,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b0

    const-string v2, "456,481,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b1

    const-string v2, "409,457,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b2

    const-string v2, "410,458,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b3

    const-string v2, "411,459,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b4

    const-string v2, "412,460,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b5

    const-string v2, "413,461,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b6

    const-string v2, "414,462,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b7

    const-string v2, "415,463,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b8

    const-string v2, "416,464,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1b9

    const-string v2, "417,465,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ba

    const-string v2, "418,466,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1bb

    const-string v2, "419,467,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1bc

    const-string v2, "420,468,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1bd

    const-string v2, "421,469,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1be

    const-string v2, "422,470,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1bf

    const-string v2, "423,471,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c0

    const-string v2, "424,472,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c1

    const-string v2, "425,473,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c2

    const-string v2, "426,474,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c3

    const-string v2, "427,475,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c4

    const-string v2, "428,476,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c5

    const-string v2, "429,477,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c6

    const-string v2, "430,478,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c7

    const-string v2, "431,479,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1c8

    const-string v2, "432,480,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ca

    const-string v2, "409,434,483,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1cb

    const-string v2, "410,435,484,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1cc

    const-string v2, "411,436,485,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1cd

    const-string v2, "412,437,486,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ce

    const-string v2, "413,438,487,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1cf

    const-string v2, "414,439,488,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d0

    const-string v2, "415,440,489,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d1

    const-string v2, "416,441,490,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d2

    const-string v2, "417,442,491,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d3

    const-string v2, "418,443,492,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d4

    const-string v2, "419,444,493,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d5

    const-string v2, "420,445,494,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d6

    const-string v2, "421,446,495,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d7

    const-string v2, "422,447,496,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d8

    const-string v2, "423,448,497,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1d9

    const-string v2, "424,449,498,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1da

    const-string v2, "425,450,499,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1db

    const-string v2, "426,451,500,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1dc

    const-string v2, "427,452,501,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1dd

    const-string v2, "428,453,502,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1de

    const-string v2, "429,454,503,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1df

    const-string v2, "430,455,504,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e0

    const-string v2, "431,456,505,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e1

    const-string v2, "432,506,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e2

    const-string v2, "457,508,535,509,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e3

    const-string v2, "458,509,536,510,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e4

    const-string v2, "459,510,537,511,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e5

    const-string v2, "460,511,538,512,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e6

    const-string v2, "461,512,539,513,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e7

    const-string v2, "462,513,540,514,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e8

    const-string v2, "463,514,541,515,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1e9

    const-string v2, "464,515,542,516,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ea

    const-string v2, "465,516,543,517,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1eb

    const-string v2, "466,517,544,518,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ec

    const-string v2, "467,518,545,519,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ed

    const-string v2, "468,519,546,520,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ee

    const-string v2, "469,520,547,521,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ef

    const-string v2, "470,521,548,522,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f0

    const-string v2, "471,522,549,523,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f1

    const-string v2, "472,523,550,524,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f2

    const-string v2, "473,524,551,525,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f3

    const-string v2, "474,525,552,526,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f4

    const-string v2, "475,526,553,527,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f5

    const-string v2, "476,527,554,528,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f6

    const-string v2, "477,528,555,529,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f7

    const-string v2, "478,529,556,530,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f8

    const-string v2, "479,530,557,531,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1f9

    const-string v2, "480,531,558,532,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1fa

    const-string v2, "481,532,559,533,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1fb

    const-string v2, "533,560,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1fc

    const-string v2, "482,534,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1fd

    const-string v2, "483,535,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1fe

    const-string v2, "484,536,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x1ff

    const-string v2, "485,537,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x200

    const-string v2, "486,538,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x201

    const-string v2, "487,539,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x202

    const-string v2, "488,540,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x203

    const-string v2, "489,541,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x204

    const-string v2, "490,542,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x205

    const-string v2, "491,543,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x206

    const-string v2, "492,544,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x207

    const-string v2, "493,545,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x208

    const-string v2, "494,546,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x209

    const-string v2, "495,547,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20a

    const-string v2, "496,548,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20b

    const-string v2, "497,549,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20c

    const-string v2, "498,550,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20d

    const-string v2, "499,551,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20e

    const-string v2, "500,552,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x20f

    const-string v2, "501,553,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x210

    const-string v2, "502,554,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x211

    const-string v2, "503,555,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x212

    const-string v2, "504,556,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x213

    const-string v2, "505,557,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x214

    const-string v2, "506,558,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x215

    const-string v2, "507,559,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x217

    const-string v2, "482,509,562,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x218

    const-string v2, "483,510,563,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x219

    const-string v2, "484,511,564,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21a

    const-string v2, "485,512,565,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21b

    const-string v2, "486,513,566,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21c

    const-string v2, "487,514,567,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21d

    const-string v2, "488,515,568,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21e

    const-string v2, "489,516,569,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x21f

    const-string v2, "490,517,570,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x220

    const-string v2, "491,518,571,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x221

    const-string v2, "492,519,572,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x222

    const-string v2, "493,520,573,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x223

    const-string v2, "494,521,574,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x224

    const-string v2, "495,522,575,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x225

    const-string v2, "496,523,576,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x226

    const-string v2, "497,524,577,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x227

    const-string v2, "498,525,578,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x228

    const-string v2, "499,526,579,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x229

    const-string v2, "500,527,580,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22a

    const-string v2, "501,528,581,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22b

    const-string v2, "502,529,582,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22c

    const-string v2, "503,530,583,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22d

    const-string v2, "504,531,584,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22e

    const-string v2, "505,532,585,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x22f

    const-string v2, "506,533,586,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x230

    const-string v2, "507,587,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x231

    const-string v2, "534,589,617,590,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x232

    const-string v2, "535,590,618,591,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x233

    const-string v2, "536,591,619,592,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x234

    const-string v2, "537,592,620,593,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x235

    const-string v2, "538,593,621,594,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x236

    const-string v2, "539,594,622,595,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x237

    const-string v2, "540,595,623,596,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x238

    const-string v2, "541,596,624,597,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x239

    const-string v2, "542,597,625,598,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23a

    const-string v2, "543,598,626,599,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23b

    const-string v2, "544,599,627,600,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23c

    const-string v2, "545,600,628,601,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23d

    const-string v2, "546,601,629,602,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23e

    const-string v2, "547,602,630,603,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x23f

    const-string v2, "548,603,631,604,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x240

    const-string v2, "549,604,632,605,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x241

    const-string v2, "550,605,633,606,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x242

    const-string v2, "551,606,634,607,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x243

    const-string v2, "552,607,635,608,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x244

    const-string v2, "553,608,636,609,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x245

    const-string v2, "554,609,637,610,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x246

    const-string v2, "555,610,638,611,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x247

    const-string v2, "556,611,639,612,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x248

    const-string v2, "557,612,640,613,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x249

    const-string v2, "558,613,641,614,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24a

    const-string v2, "559,614,642,615,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24b

    const-string v2, "560,615,643,616,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24c

    const-string v2, "616,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24d

    const-string v2, "561,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24e

    const-string v2, "562,617,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x24f

    const-string v2, "563,618,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x250

    const-string v2, "564,619,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x251

    const-string v2, "565,620,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x252

    const-string v2, "566,621,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x253

    const-string v2, "567,622,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x254

    const-string v2, "568,623,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x255

    const-string v2, "569,624,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x256

    const-string v2, "570,625,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x257

    const-string v2, "571,626,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x258

    const-string v2, "572,627,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x259

    const-string v2, "573,628,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25a

    const-string v2, "574,629,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25b

    const-string v2, "575,630,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25c

    const-string v2, "576,631,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25d

    const-string v2, "577,632,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25e

    const-string v2, "578,633,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x25f

    const-string v2, "579,634,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x260

    const-string v2, "580,635,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x261

    const-string v2, "581,636,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x262

    const-string v2, "582,637,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x263

    const-string v2, "583,638,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x264

    const-string v2, "584,639,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x265

    const-string v2, "585,640,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x266

    const-string v2, "586,641,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x267

    const-string v2, "587,642,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x268

    const-string v2, "588,643,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x269

    const-string v2, "561,590,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26a

    const-string v2, "562,591,644,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26b

    const-string v2, "563,592,645,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26c

    const-string v2, "564,593,646,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26d

    const-string v2, "565,594,647,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26e

    const-string v2, "566,595,648,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x26f

    const-string v2, "567,596,649,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x270

    const-string v2, "568,597,650,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x271

    const-string v2, "569,598,651,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x272

    const-string v2, "570,599,652,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x273

    const-string v2, "571,600,653,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x274

    const-string v2, "572,601,654,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x275

    const-string v2, "573,602,655,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x276

    const-string v2, "574,603,656,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x277

    const-string v2, "575,604,657,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x278

    const-string v2, "576,605,658,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x279

    const-string v2, "577,606,659,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27a

    const-string v2, "578,607,660,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27b

    const-string v2, "579,608,661,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27c

    const-string v2, "580,609,662,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27d

    const-string v2, "581,610,663,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27e

    const-string v2, "582,611,664,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x27f

    const-string v2, "583,612,665,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x280

    const-string v2, "584,613,666,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x281

    const-string v2, "585,614,667,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x282

    const-string v2, "586,615,668,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x283

    const-string v2, "587,616,669,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x284

    const-string v2, "618,670,696,671,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x285

    const-string v2, "619,671,697,672,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x286

    const-string v2, "620,672,698,673,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x287

    const-string v2, "621,673,699,674,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x288

    const-string v2, "622,674,700,675,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x289

    const-string v2, "623,675,701,676,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28a

    const-string v2, "624,676,702,677,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28b

    const-string v2, "625,677,703,678,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28c

    const-string v2, "626,678,704,679,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28d

    const-string v2, "627,679,705,680,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28e

    const-string v2, "628,680,706,681,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x28f

    const-string v2, "629,681,707,682,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x290

    const-string v2, "630,682,708,683,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x291

    const-string v2, "631,683,709,684,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x292

    const-string v2, "632,684,710,685,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x293

    const-string v2, "633,685,711,686,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x294

    const-string v2, "634,686,712,687,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x295

    const-string v2, "635,687,713,688,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x296

    const-string v2, "636,688,714,689,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x297

    const-string v2, "637,689,715,690,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x298

    const-string v2, "638,690,716,691,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x299

    const-string v2, "639,691,717,692,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29a

    const-string v2, "640,692,718,693,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29b

    const-string v2, "641,693,719,694,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29c

    const-string v2, "642,694,720,695,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29d

    const-string v2, "643,695,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29e

    const-string v2, "644,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x29f

    const-string v2, "645,696,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a0

    const-string v2, "646,697,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a1

    const-string v2, "647,698,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a2

    const-string v2, "648,699,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a3

    const-string v2, "649,700,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a4

    const-string v2, "650,701,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a5

    const-string v2, "651,702,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a6

    const-string v2, "652,703,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a7

    const-string v2, "653,704,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a8

    const-string v2, "654,705,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2a9

    const-string v2, "655,706,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2aa

    const-string v2, "656,707,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ab

    const-string v2, "657,708,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ac

    const-string v2, "658,709,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ad

    const-string v2, "659,710,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ae

    const-string v2, "660,711,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2af

    const-string v2, "661,712,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b0

    const-string v2, "662,713,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b1

    const-string v2, "663,714,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b2

    const-string v2, "664,715,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b3

    const-string v2, "665,716,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b4

    const-string v2, "666,717,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b5

    const-string v2, "667,718,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b6

    const-string v2, "668,719,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b7

    const-string v2, "669,720,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b8

    const-string v2, "644,671,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2b9

    const-string v2, "645,672,721,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ba

    const-string v2, "646,673,722,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2bb

    const-string v2, "647,674,723,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2bc

    const-string v2, "648,675,724,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2bd

    const-string v2, "649,676,725,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2be

    const-string v2, "650,677,726,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2bf

    const-string v2, "651,678,727,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c0

    const-string v2, "652,679,728,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c1

    const-string v2, "653,680,729,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c2

    const-string v2, "654,681,730,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c3

    const-string v2, "655,682,731,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c4

    const-string v2, "656,683,732,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c5

    const-string v2, "657,684,733,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c6

    const-string v2, "658,685,734,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c7

    const-string v2, "659,686,735,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c8

    const-string v2, "660,687,736,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2c9

    const-string v2, "661,688,737,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ca

    const-string v2, "662,689,738,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2cb

    const-string v2, "663,690,739,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2cc

    const-string v2, "664,691,740,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2cd

    const-string v2, "665,692,741,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ce

    const-string v2, "666,693,742,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2cf

    const-string v2, "667,694,743,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d0

    const-string v2, "668,695,744,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d1

    const-string v2, "697,745,769,746,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d2

    const-string v2, "698,746,770,747,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d3

    const-string v2, "699,747,771,748,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d4

    const-string v2, "700,748,772,749,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d5

    const-string v2, "701,749,773,750,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d6

    const-string v2, "702,750,774,751,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d7

    const-string v2, "703,751,775,752,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d8

    const-string v2, "704,752,776,753,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2d9

    const-string v2, "705,753,777,754,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2da

    const-string v2, "706,754,778,755,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2db

    const-string v2, "707,755,779,756,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2dc

    const-string v2, "708,756,780,757,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2dd

    const-string v2, "709,757,781,758,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2de

    const-string v2, "710,758,782,759,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2df

    const-string v2, "711,759,783,760,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e0

    const-string v2, "712,760,784,761,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e1

    const-string v2, "713,761,785,762,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e2

    const-string v2, "714,762,786,763,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e3

    const-string v2, "715,763,787,764,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e4

    const-string v2, "716,764,788,765,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e5

    const-string v2, "717,765,789,766,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e6

    const-string v2, "718,766,790,767,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e7

    const-string v2, "719,767,791,768,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e8

    const-string v2, "720,768,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2e9

    const-string v2, "721,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ea

    const-string v2, "722,769,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2eb

    const-string v2, "723,770,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ec

    const-string v2, "724,771,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ed

    const-string v2, "725,772,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ee

    const-string v2, "726,773,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ef

    const-string v2, "727,774,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f0

    const-string v2, "728,775,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f1

    const-string v2, "729,776,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f2

    const-string v2, "730,777,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f3

    const-string v2, "731,778,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f4

    const-string v2, "732,779,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f5

    const-string v2, "733,780,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f6

    const-string v2, "734,781,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f7

    const-string v2, "735,782,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f8

    const-string v2, "736,783,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2f9

    const-string v2, "737,784,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2fa

    const-string v2, "738,785,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2fb

    const-string v2, "739,786,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2fc

    const-string v2, "740,787,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2fd

    const-string v2, "741,788,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2fe

    const-string v2, "742,789,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x2ff

    const-string v2, "743,790,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x300

    const-string v2, "744,791,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x301

    const-string v2, "721,746,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x302

    const-string v2, "722,747,792,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x303

    const-string v2, "723,748,793,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x304

    const-string v2, "724,749,794,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x305

    const-string v2, "725,750,795,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x306

    const-string v2, "726,751,796,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x307

    const-string v2, "727,752,797,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x308

    const-string v2, "728,753,798,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x309

    const-string v2, "729,754,799,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30a

    const-string v2, "730,755,800,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30b

    const-string v2, "731,756,801,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30c

    const-string v2, "732,757,802,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30d

    const-string v2, "733,758,803,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30e

    const-string v2, "734,759,804,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x30f

    const-string v2, "735,760,805,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x310

    const-string v2, "736,761,806,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x311

    const-string v2, "737,762,807,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x312

    const-string v2, "738,763,808,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x313

    const-string v2, "739,764,809,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x314

    const-string v2, "740,765,810,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x315

    const-string v2, "741,766,811,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x316

    const-string v2, "742,767,812,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x317

    const-string v2, "743,768,813,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x318

    const-string v2, "770,814,836,815,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x319

    const-string v2, "771,815,837,816,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31a

    const-string v2, "772,816,838,817,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31b

    const-string v2, "773,817,839,818,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31c

    const-string v2, "774,818,840,819,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31d

    const-string v2, "775,819,841,820,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31e

    const-string v2, "776,820,842,821,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x31f

    const-string v2, "777,821,843,822,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x320

    const-string v2, "778,822,844,823,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x321

    const-string v2, "779,823,845,824,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x322

    const-string v2, "780,824,846,825,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x323

    const-string v2, "781,825,847,826,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x324

    const-string v2, "782,826,848,827,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x325

    const-string v2, "783,827,849,828,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x326

    const-string v2, "784,828,850,829,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x327

    const-string v2, "785,829,851,830,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x328

    const-string v2, "786,830,852,831,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x329

    const-string v2, "787,831,853,832,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32a

    const-string v2, "788,832,854,833,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32b

    const-string v2, "789,833,855,834,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32c

    const-string v2, "790,834,856,835,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32d

    const-string v2, "791,835,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32e

    const-string v2, "792,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x32f

    const-string v2, "793,836,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x330

    const-string v2, "794,837,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x331

    const-string v2, "795,838,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x332

    const-string v2, "796,839,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x333

    const-string v2, "797,840,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x334

    const-string v2, "798,841,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x335

    const-string v2, "799,842,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x336

    const-string v2, "800,843,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x337

    const-string v2, "801,844,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x338

    const-string v2, "802,845,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x339

    const-string v2, "803,846,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33a

    const-string v2, "804,847,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33b

    const-string v2, "805,848,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33c

    const-string v2, "806,849,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33d

    const-string v2, "807,850,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33e

    const-string v2, "808,851,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x33f

    const-string v2, "809,852,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x340

    const-string v2, "810,853,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x341

    const-string v2, "811,854,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x342

    const-string v2, "812,855,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x343

    const-string v2, "813,856,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x344

    const-string v2, "792,815,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x345

    const-string v2, "793,816,857,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x346

    const-string v2, "794,817,858,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x347

    const-string v2, "795,818,859,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x348

    const-string v2, "796,819,860,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x349

    const-string v2, "797,820,861,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34a

    const-string v2, "798,821,862,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34b

    const-string v2, "799,822,863,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34c

    const-string v2, "800,823,864,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34d

    const-string v2, "801,824,865,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34e

    const-string v2, "802,825,866,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x34f

    const-string v2, "803,826,867,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x350

    const-string v2, "804,827,868,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x351

    const-string v2, "805,828,869,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x352

    const-string v2, "806,829,870,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x353

    const-string v2, "807,830,871,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x354

    const-string v2, "808,831,872,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x355

    const-string v2, "809,832,873,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x356

    const-string v2, "810,833,874,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x357

    const-string v2, "811,834,875,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x358

    const-string v2, "812,835,876,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x359

    const-string v2, "837,877,897,878,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35a

    const-string v2, "838,878,898,879,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35b

    const-string v2, "839,879,899,880,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35c

    const-string v2, "840,880,900,881,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35d

    const-string v2, "841,881,901,882,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35e

    const-string v2, "842,882,902,883,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x35f

    const-string v2, "843,883,903,884,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x360

    const-string v2, "844,884,904,885,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x361

    const-string v2, "845,885,905,886,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x362

    const-string v2, "846,886,906,887,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x363

    const-string v2, "847,887,907,888,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x364

    const-string v2, "848,888,908,889,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x365

    const-string v2, "849,889,909,890,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x366

    const-string v2, "850,890,910,891,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x367

    const-string v2, "851,891,911,892,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x368

    const-string v2, "852,892,912,893,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x369

    const-string v2, "853,893,913,894,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36a

    const-string v2, "854,894,914,895,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36b

    const-string v2, "855,895,915,896,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36c

    const-string v2, "856,896,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36d

    const-string v2, "857,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36e

    const-string v2, "858,897,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x36f

    const-string v2, "859,898,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x370

    const-string v2, "860,899,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x371

    const-string v2, "861,900,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x372

    const-string v2, "862,901,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x373

    const-string v2, "863,902,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x374

    const-string v2, "864,903,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x375

    const-string v2, "865,904,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x376

    const-string v2, "866,905,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x377

    const-string v2, "867,906,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x378

    const-string v2, "868,907,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x379

    const-string v2, "869,908,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37a

    const-string v2, "870,909,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37b

    const-string v2, "871,910,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37c

    const-string v2, "872,911,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37d

    const-string v2, "873,912,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37e

    const-string v2, "874,913,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x37f

    const-string v2, "875,914,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x380

    const-string v2, "876,915,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x381

    const-string v2, "857,878,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x382

    const-string v2, "858,879,916,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x383

    const-string v2, "859,880,917,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x384

    const-string v2, "860,881,918,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x385

    const-string v2, "861,882,919,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x386

    const-string v2, "862,883,920,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x387

    const-string v2, "863,884,921,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x388

    const-string v2, "864,885,922,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x389

    const-string v2, "865,886,923,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38a

    const-string v2, "866,887,924,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38b

    const-string v2, "867,888,925,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38c

    const-string v2, "868,889,926,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38d

    const-string v2, "869,890,927,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38e

    const-string v2, "870,891,928,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x38f

    const-string v2, "871,892,929,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x390

    const-string v2, "872,893,930,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x391

    const-string v2, "873,894,931,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x392

    const-string v2, "874,895,932,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x393

    const-string v2, "875,896,933,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x394

    const-string v2, "898,934,952,935,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x395

    const-string v2, "899,935,953,936,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x396

    const-string v2, "900,936,954,937,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x397

    const-string v2, "901,937,955,938,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x398

    const-string v2, "902,938,956,939,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x399

    const-string v2, "903,939,957,940,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39a

    const-string v2, "904,940,958,941,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39b

    const-string v2, "905,941,959,942,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39c

    const-string v2, "906,942,960,943,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39d

    const-string v2, "907,943,961,944,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39e

    const-string v2, "908,944,962,945,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x39f

    const-string v2, "909,945,963,946,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a0

    const-string v2, "910,946,964,947,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a1

    const-string v2, "911,947,965,948,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a2

    const-string v2, "912,948,966,949,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a3

    const-string v2, "913,949,967,950,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a4

    const-string v2, "914,950,968,951,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a5

    const-string v2, "915,951,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a6

    const-string v2, "916,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a7

    const-string v2, "917,952,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a8

    const-string v2, "918,953,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3a9

    const-string v2, "919,954,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3aa

    const-string v2, "920,955,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ab

    const-string v2, "921,956,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ac

    const-string v2, "922,957,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ad

    const-string v2, "923,958,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ae

    const-string v2, "924,959,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3af

    const-string v2, "925,960,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b0

    const-string v2, "926,961,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b1

    const-string v2, "927,962,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b2

    const-string v2, "928,963,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b3

    const-string v2, "929,964,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b4

    const-string v2, "930,965,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b5

    const-string v2, "931,966,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b6

    const-string v2, "932,967,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b7

    const-string v2, "933,968,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b8

    const-string v2, "916,935,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3b9

    const-string v2, "917,936,969,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ba

    const-string v2, "918,937,970,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3bb

    const-string v2, "919,938,971,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3bc

    const-string v2, "920,939,972,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3bd

    const-string v2, "921,940,973,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3be

    const-string v2, "922,941,974,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3bf

    const-string v2, "923,942,975,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c0

    const-string v2, "924,943,976,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c1

    const-string v2, "925,944,977,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c2

    const-string v2, "926,945,978,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c3

    const-string v2, "927,946,979,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c4

    const-string v2, "928,947,980,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c5

    const-string v2, "929,948,981,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c6

    const-string v2, "930,949,982,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c7

    const-string v2, "931,950,983,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c8

    const-string v2, "932,951,984,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3c9

    const-string v2, "953,985,1001,986,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ca

    const-string v2, "954,986,1002,987,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3cb

    const-string v2, "955,987,1003,988,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3cc

    const-string v2, "956,988,1004,989,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3cd

    const-string v2, "957,989,1005,990,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ce

    const-string v2, "958,990,1006,991,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3cf

    const-string v2, "959,991,1007,992,"

    invoke-interface {v0, v1, v4, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d0

    const-string v2, "960,992,1008,993,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d1

    const-string v2, "961,993,1009,994,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d2

    const-string v2, "962,994,1010,995,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d3

    const-string v2, "963,995,1011,996,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d4

    const-string v2, "964,996,1012,997,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d5

    const-string v2, "965,997,1013,998,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d6

    const-string v2, "966,998,1014,999,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d7

    const-string v2, "967,999,1015,1000,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d8

    const-string v2, "968,1000,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3d9

    const-string v2, "969,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3da

    const-string v2, "970,1001,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3db

    const-string v2, "971,1002,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3dc

    const-string v2, "972,1003,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3dd

    const-string v2, "973,1004,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3de

    const-string v2, "974,1005,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3df

    const-string v2, "975,1006,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e0

    const-string v2, "976,1007,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e1

    const-string v2, "977,1008,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e2

    const-string v2, "978,1009,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e3

    const-string v2, "979,1010,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e4

    const-string v2, "980,1011,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e5

    const-string v2, "981,1012,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e6

    const-string v2, "982,1013,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e7

    const-string v2, "983,1014,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e8

    const-string v2, "984,1015,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3e9

    const-string v2, "969,986,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ea

    const-string v2, "970,987,1016,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3eb

    const-string v2, "971,988,1017,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ec

    const-string v2, "972,989,1018,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ed

    const-string v2, "973,990,1019,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ee

    const-string v2, "974,991,1020,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ef

    const-string v2, "975,992,1021,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f0

    const-string v2, "976,993,1022,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f1

    const-string v2, "977,994,1023,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f2

    const-string v2, "978,995,1024,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f3

    const-string v2, "979,996,1025,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f4

    const-string v2, "980,997,1026,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f5

    const-string v2, "981,998,1027,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f6

    const-string v2, "982,999,1028,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f7

    const-string v2, "983,1000,1029,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f8

    const-string v2, "1002,1030,1044,1031,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3f9

    const-string v2, "1003,1031,1045,1032,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3fa

    const-string v2, "1004,1032,1046,1033,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3fb

    const-string v2, "1005,1033,1047,1034,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3fc

    const-string v2, "1006,1034,1048,1035,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3fd

    const-string v2, "1007,1035,1049,1036,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3fe

    const-string v2, "1008,1036,1050,1037,"

    invoke-interface {v0, v1, v5, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x3ff

    const-string v2, "1009,1037,1051,1038,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x400

    const-string v2, "1010,1038,1052,1039,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x401

    const-string v2, "1011,1039,1053,1040,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x402

    const-string v2, "1012,1040,1054,1041,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x403

    const-string v2, "1013,1041,1055,1042,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x404

    const-string v2, "1014,1042,1056,1043,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x405

    const-string v2, "1015,1043,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x406

    const-string v2, "1016,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x407

    const-string v2, "1017,1044,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x408

    const-string v2, "1018,1045,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x409

    const-string v2, "1019,1046,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40a

    const-string v2, "1020,1047,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40b

    const-string v2, "1021,1048,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40c

    const-string v2, "1022,1049,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40d

    const-string v2, "1023,1050,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40e

    const-string v2, "1024,1051,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x40f

    const-string v2, "1025,1052,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x410

    const-string v2, "1026,1053,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x411

    const-string v2, "1027,1054,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x412

    const-string v2, "1028,1055,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x413

    const-string v2, "1029,1056,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x414

    const-string v2, "1016,1031,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x415

    const-string v2, "1017,1032,1057,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x416

    const-string v2, "1018,1033,1058,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x417

    const-string v2, "1019,1034,1059,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x418

    const-string v2, "1020,1035,1060,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x419

    const-string v2, "1021,1036,1061,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41a

    const-string v2, "1022,1037,1062,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41b

    const-string v2, "1023,1038,1063,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41c

    const-string v2, "1024,1039,1064,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41d

    const-string v2, "1025,1040,1065,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41e

    const-string v2, "1026,1041,1066,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x41f

    const-string v2, "1027,1042,1067,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x420

    const-string v2, "1028,1043,1068,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x421

    const-string v2, "1045,1069,1081,1070,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x422

    const-string v2, "1046,1070,1082,1071,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x423

    const-string v2, "1047,1071,1083,1072,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x424

    const-string v2, "1048,1072,1084,1073,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x425

    const-string v2, "1049,1073,1085,1074,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x426

    const-string v2, "1050,1074,1086,1075,"

    invoke-interface {v0, v1, v4, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x427

    const-string v2, "1051,1075,1087,1076,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x428

    const-string v2, "1052,1076,1088,1077,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x429

    const-string v2, "1053,1077,1089,1078,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42a

    const-string v2, "1054,1078,1090,1079,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42b

    const-string v2, "1055,1079,1091,1080,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42c

    const-string v2, "1056,1080,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42d

    const-string v2, "1057,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42e

    const-string v2, "1058,1081,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x42f

    const-string v2, "1059,1082,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x430

    const-string v2, "1060,1083,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x431

    const-string v2, "1061,1084,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x432

    const-string v2, "1062,1085,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x433

    const-string v2, "1063,1086,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x434

    const-string v2, "1064,1087,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x435

    const-string v2, "1065,1088,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x436

    const-string v2, "1066,1089,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x437

    const-string v2, "1067,1090,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x438

    const-string v2, "1068,1091,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x439

    const-string v2, "1057,1070,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43a

    const-string v2, "1058,1071,1092,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43b

    const-string v2, "1059,1072,1093,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43c

    const-string v2, "1060,1073,1094,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43d

    const-string v2, "1061,1074,1095,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43e

    const-string v2, "1062,1075,1096,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x43f

    const-string v2, "1063,1076,1097,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x440

    const-string v2, "1064,1077,1098,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x441

    const-string v2, "1065,1078,1099,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x442

    const-string v2, "1066,1079,1100,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x443

    const-string v2, "1067,1080,1101,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x444

    const-string v2, "1082,1102,1112,1103,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x445

    const-string v2, "1083,1103,1113,1104,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x446

    const-string v2, "1084,1104,1114,1105,"

    invoke-interface {v0, v1, v4, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x447

    const-string v2, "1085,1105,1115,1106,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x448

    const-string v2, "1086,1106,1116,1107,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x449

    const-string v2, "1087,1107,1117,1108,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44a

    const-string v2, "1088,1108,1118,1109,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44b

    const-string v2, "1089,1109,1119,1110,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44c

    const-string v2, "1090,1110,1120,1111,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44d

    const-string v2, "1091,1111,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44e

    const-string v2, "1092,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x44f

    const-string v2, "1093,1112,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x450

    const-string v2, "1094,1113,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x451

    const-string v2, "1095,1114,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x452

    const-string v2, "1096,1115,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x453

    const-string v2, "1097,1116,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x454

    const-string v2, "1098,1117,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x455

    const-string v2, "1099,1118,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x456

    const-string v2, "1100,1119,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x457

    const-string v2, "1101,1120,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x458

    const-string v2, "1092,1103,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x459

    const-string v2, "1093,1104,1121,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45a

    const-string v2, "1094,1105,1122,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45b

    const-string v2, "1095,1106,1123,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45c

    const-string v2, "1096,1107,1124,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45d

    const-string v2, "1097,1108,1125,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45e

    const-string v2, "1098,1109,1126,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x45f

    const-string v2, "1099,1110,1127,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x460

    const-string v2, "1100,1111,1128,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x461

    const-string v2, "1113,1129,1137,1130,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x462

    const-string v2, "1114,1130,1138,1131,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x463

    const-string v2, "1115,1131,1139,1132,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x464

    const-string v2, "1116,1132,1140,1133,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x465

    const-string v2, "1117,1133,1141,1134,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x466

    const-string v2, "1118,1134,1142,1135,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x467

    const-string v2, "1119,1135,1143,1136,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x468

    const-string v2, "1120,1136,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x469

    const-string v2, "1121,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46a

    const-string v2, "1122,1137,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46b

    const-string v2, "1123,1138,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46c

    const-string v2, "1124,1139,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46d

    const-string v2, "1125,1140,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46e

    const-string v2, "1126,1141,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x46f

    const-string v2, "1127,1142,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x470

    const-string v2, "1128,1143,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x471

    const-string v2, "1121,1130,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x472

    const-string v2, "1122,1131,1144,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x473

    const-string v2, "1123,1132,1145,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x474

    const-string v2, "1124,1133,1146,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x475

    const-string v2, "1125,1134,1147,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x476

    const-string v2, "1126,1135,1148,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x477

    const-string v2, "1127,1136,1149,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x478

    const-string v2, "1138,1150,1156,1151,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x479

    const-string v2, "1139,1151,1157,1152,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47a

    const-string v2, "1140,1152,1158,1153,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47b

    const-string v2, "1141,1153,1159,1154,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47c

    const-string v2, "1142,1154,1160,1155,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47d

    const-string v2, "1143,1155,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47e

    const-string v2, "1144,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x47f

    const-string v2, "1145,1156,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x480

    const-string v2, "1146,1157,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x481

    const-string v2, "1147,1158,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x482

    const-string v2, "1148,1159,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x483

    const-string v2, "1149,1160,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x484

    const-string v2, "1144,1151,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x485

    const-string v2, "1145,1152,1161,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x486

    const-string v2, "1146,1153,1162,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x487

    const-string v2, "1147,1154,1163,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x488

    const-string v2, "1148,1155,1164,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x489

    const-string v2, "1157,1165,1169,1166,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48a

    const-string v2, "1158,1166,1170,1167,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48b

    const-string v2, "1159,1167,1171,1168,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48c

    const-string v2, "1160,1168,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48d

    const-string v2, "1161,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48e

    const-string v2, "1162,1169,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x48f

    const-string v2, "1163,1170,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x490

    const-string v2, "1164,1171,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x491

    const-string v2, "1161,1166,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x492

    const-string v2, "1162,1167,1172,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x493

    const-string v2, "1163,1168,1173,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x494

    const-string v2, "1170,1174,1176,1175,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x495

    const-string v2, "1171,1175,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x496

    const-string v2, "1172,"

    invoke-interface {v0, v1, v3, v5, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x497

    const-string v2, "1173,1176,"

    invoke-interface {v0, v1, v3, v4, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    iget-object v0, p0, Lajd;->a:Lframework/server/game/IGameRuleHelper;

    const/16 v1, 0x498

    const-string v2, "1172,1175,"

    invoke-interface {v0, v1, v3, v3, v2}, Lframework/server/game/IGameRuleHelper;->_ci(IIILjava/lang/String;)V

    return-void
.end method
