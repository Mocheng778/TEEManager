.class public Lary;
.super Lasc;


# direct methods
.method public constructor <init>(Laqs;)V
    .locals 1

    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Laqs;->b(I)[Lbyq;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lasc;-><init>(Laqs;[Lbyq;)V

    invoke-virtual {p0}, Lary;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->b()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-virtual {p0}, Lary;->e()Lbyq;

    move-result-object v0

    invoke-virtual {v0}, Lbyq;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lary;->b()Laqs;

    move-result-object v0

    invoke-virtual {v0}, Laqs;->p()V

    :cond_0
    return-void
.end method
