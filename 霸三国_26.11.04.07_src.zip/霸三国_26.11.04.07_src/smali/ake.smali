.class public Lake;
.super Ljava/lang/Object;


# instance fields
.field private a:Lals;

.field private b:J

.field private c:J

.field private d:J

.field private e:J

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lals;
    .locals 1

    iget-object v0, p0, Lake;->a:Lals;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lake;->f:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lake;->b:J

    return-void
.end method

.method public a(Lals;)V
    .locals 0

    iput-object p1, p0, Lake;->a:Lals;

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Lake;->c:J

    return-wide v0
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lake;->c:J

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Lake;->d:J

    return-wide v0
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lake;->d:J

    return-void
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Lake;->e:J

    return-wide v0
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lake;->e:J

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lake;->f:I

    return v0
.end method
