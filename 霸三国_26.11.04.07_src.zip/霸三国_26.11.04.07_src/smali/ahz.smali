.class public Lahz;
.super Ljava/lang/Object;


# instance fields
.field private a:Lajv;

.field private b:I

.field private c:I

.field private d:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lahz;->b:I

    return-void
.end method

.method public a(Lajv;)V
    .locals 0

    iput-object p1, p0, Lahz;->a:Lajv;

    return-void
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lahz;->c:I

    return-void
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lahz;->d:I

    return-void
.end method
