.class public Lakw;
.super Ljava/lang/Object;


# instance fields
.field private A:I

.field private B:J

.field private C:J

.field private D:J

.field private E:I

.field private F:J

.field private G:Ljava/lang/String;

.field private H:I

.field private I:I

.field private J:I

.field private K:I

.field private L:I

.field private M:I

.field private N:Z

.field private O:I

.field private P:I

.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:I

.field private m:I

.field private n:I

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:I

.field private v:I

.field private w:I

.field private x:I

.field private y:I

.field private z:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lakw;->d:I

    return-void
.end method


# virtual methods
.method public A()I
    .locals 1

    iget v0, p0, Lakw;->A:I

    return v0
.end method

.method public A(I)V
    .locals 0

    iput p1, p0, Lakw;->A:I

    return-void
.end method

.method public B()J
    .locals 2

    iget-wide v0, p0, Lakw;->C:J

    return-wide v0
.end method

.method public B(I)V
    .locals 0

    iput p1, p0, Lakw;->I:I

    return-void
.end method

.method public C()J
    .locals 2

    iget-wide v0, p0, Lakw;->F:J

    return-wide v0
.end method

.method public C(I)V
    .locals 0

    iput p1, p0, Lakw;->H:I

    return-void
.end method

.method public D()I
    .locals 1

    iget v0, p0, Lakw;->I:I

    return v0
.end method

.method public D(I)V
    .locals 0

    iput p1, p0, Lakw;->J:I

    return-void
.end method

.method public E()I
    .locals 1

    iget v0, p0, Lakw;->H:I

    return v0
.end method

.method public E(I)V
    .locals 0

    iput p1, p0, Lakw;->O:I

    return-void
.end method

.method public F()I
    .locals 1

    iget v0, p0, Lakw;->J:I

    return v0
.end method

.method public F(I)V
    .locals 0

    iput p1, p0, Lakw;->K:I

    return-void
.end method

.method public G(I)V
    .locals 0

    iput p1, p0, Lakw;->M:I

    return-void
.end method

.method public G()Z
    .locals 1

    iget-boolean v0, p0, Lakw;->N:Z

    return v0
.end method

.method public H()I
    .locals 1

    iget v0, p0, Lakw;->K:I

    return v0
.end method

.method public H(I)V
    .locals 0

    iput p1, p0, Lakw;->P:I

    return-void
.end method

.method public I()I
    .locals 1

    iget v0, p0, Lakw;->L:I

    return v0
.end method

.method public I(I)V
    .locals 0

    iput p1, p0, Lakw;->L:I

    return-void
.end method

.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakw;->G:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakw;->d:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lakw;->B:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakw;->G:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lakw;->N:Z

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lakw;->d:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakw;->E:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lakw;->C:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakw;->b:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakw;->l:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakw;->l:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lakw;->D:J

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lakw;->i:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lakw;->i:I

    return-void
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lakw;->F:J

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lakw;->x:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lakw;->x:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lakw;->r:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lakw;->r:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lakw;->s:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lakw;->s:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lakw;->t:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lakw;->t:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lakw;->u:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lakw;->n:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lakw;->n:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lakw;->u:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lakw;->a:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lakw;->a:I

    return-void
.end method

.method public l()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakw;->b:Ljava/lang/String;

    return-object v0
.end method

.method public l(I)V
    .locals 0

    iput p1, p0, Lakw;->c:I

    return-void
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lakw;->c:I

    return v0
.end method

.method public m(I)V
    .locals 0

    iput p1, p0, Lakw;->e:I

    return-void
.end method

.method public n()I
    .locals 1

    iget v0, p0, Lakw;->e:I

    return v0
.end method

.method public n(I)V
    .locals 0

    iput p1, p0, Lakw;->f:I

    return-void
.end method

.method public namedHeroId()I
    .locals 1

    iget v0, p0, Lakw;->E:I

    return v0
.end method

.method public o()I
    .locals 1

    iget v0, p0, Lakw;->g:I

    return v0
.end method

.method public o(I)V
    .locals 0

    iput p1, p0, Lakw;->g:I

    return-void
.end method

.method public p()I
    .locals 1

    iget v0, p0, Lakw;->h:I

    return v0
.end method

.method public p(I)V
    .locals 0

    iput p1, p0, Lakw;->h:I

    return-void
.end method

.method public q()I
    .locals 1

    iget v0, p0, Lakw;->j:I

    return v0
.end method

.method public q(I)V
    .locals 0

    iput p1, p0, Lakw;->j:I

    return-void
.end method

.method public r()I
    .locals 1

    iget v0, p0, Lakw;->k:I

    return v0
.end method

.method public r(I)V
    .locals 0

    iput p1, p0, Lakw;->k:I

    return-void
.end method

.method public s()I
    .locals 1

    iget v0, p0, Lakw;->m:I

    return v0
.end method

.method public s(I)V
    .locals 0

    iput p1, p0, Lakw;->m:I

    return-void
.end method

.method public t()I
    .locals 1

    iget v0, p0, Lakw;->o:I

    return v0
.end method

.method public t(I)V
    .locals 0

    iput p1, p0, Lakw;->o:I

    return-void
.end method

.method public u()I
    .locals 1

    iget v0, p0, Lakw;->p:I

    return v0
.end method

.method public u(I)V
    .locals 0

    iput p1, p0, Lakw;->p:I

    return-void
.end method

.method public v()I
    .locals 1

    iget v0, p0, Lakw;->q:I

    return v0
.end method

.method public v(I)V
    .locals 0

    iput p1, p0, Lakw;->q:I

    return-void
.end method

.method public w()I
    .locals 1

    iget v0, p0, Lakw;->w:I

    return v0
.end method

.method public w(I)V
    .locals 0

    iput p1, p0, Lakw;->v:I

    return-void
.end method

.method public x()I
    .locals 1

    iget v0, p0, Lakw;->y:I

    return v0
.end method

.method public x(I)V
    .locals 0

    iput p1, p0, Lakw;->w:I

    return-void
.end method

.method public y()I
    .locals 1

    iget v0, p0, Lakw;->z:I

    return v0
.end method

.method public y(I)V
    .locals 0

    iput p1, p0, Lakw;->y:I

    return-void
.end method

.method public z()J
    .locals 2

    iget-wide v0, p0, Lakw;->B:J

    return-wide v0
.end method

.method public z(I)V
    .locals 0

    iput p1, p0, Lakw;->z:I

    return-void
.end method
