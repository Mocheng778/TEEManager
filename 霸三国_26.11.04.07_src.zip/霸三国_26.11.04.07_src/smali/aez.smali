.class public Laez;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lamw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lamw;)V
    .locals 0

    iput-object p1, p0, Laez;->a:[Lamw;

    return-void
.end method

.method public a()[Lamw;
    .locals 1

    iget-object v0, p0, Laez;->a:[Lamw;

    return-object v0
.end method
