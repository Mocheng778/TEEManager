.class public Lakr;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lajw;

.field private b:[Lakw;

.field private c:[Lamb;

.field private d:[Lamb;

.field private e:Laks;

.field private f:[Lajv;

.field private g:[Lamf;

.field private h:Ljava/lang/String;

.field private i:I

.field private j:Z

.field private k:Lajr;

.field private l:Lajq;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lakr;->i:I

    return-void
.end method

.method public a(Lajq;)V
    .locals 0

    iput-object p1, p0, Lakr;->l:Lajq;

    return-void
.end method

.method public a(Lajr;)V
    .locals 0

    iput-object p1, p0, Lakr;->k:Lajr;

    return-void
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Lakr;->e:Laks;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakr;->h:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lakr;->j:Z

    return-void
.end method

.method public a([Lajv;)V
    .locals 0

    iput-object p1, p0, Lakr;->f:[Lajv;

    return-void
.end method

.method public a([Lajw;)V
    .locals 0

    iput-object p1, p0, Lakr;->a:[Lajw;

    return-void
.end method

.method public a([Lakw;)V
    .locals 0

    iput-object p1, p0, Lakr;->b:[Lakw;

    return-void
.end method

.method public a([Lamb;)V
    .locals 0

    iput-object p1, p0, Lakr;->c:[Lamb;

    return-void
.end method

.method public a([Lamf;)V
    .locals 0

    iput-object p1, p0, Lakr;->g:[Lamf;

    return-void
.end method

.method public a()[Lamf;
    .locals 1

    iget-object v0, p0, Lakr;->g:[Lamf;

    return-object v0
.end method

.method public b([Lamb;)V
    .locals 0

    iput-object p1, p0, Lakr;->d:[Lamb;

    return-void
.end method

.method public b()[Lamb;
    .locals 1

    iget-object v0, p0, Lakr;->c:[Lamb;

    return-object v0
.end method

.method public c()[Lamb;
    .locals 1

    iget-object v0, p0, Lakr;->d:[Lamb;

    return-object v0
.end method

.method public d()[Lajw;
    .locals 1

    iget-object v0, p0, Lakr;->a:[Lajw;

    return-object v0
.end method

.method public e()[Lakw;
    .locals 1

    iget-object v0, p0, Lakr;->b:[Lakw;

    return-object v0
.end method

.method public f()Laks;
    .locals 1

    iget-object v0, p0, Lakr;->e:Laks;

    return-object v0
.end method

.method public g()[Lajv;
    .locals 1

    iget-object v0, p0, Lakr;->f:[Lajv;

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakr;->h:Ljava/lang/String;

    return-object v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lakr;->i:I

    return v0
.end method

.method public j()Z
    .locals 1

    iget-boolean v0, p0, Lakr;->j:Z

    return v0
.end method
