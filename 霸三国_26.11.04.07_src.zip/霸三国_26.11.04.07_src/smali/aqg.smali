.class public Laqg;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:Lbyw;

.field private f:Ljava/util/Hashtable;

.field private g:Lbyr;

.field private h:Ljava/util/Hashtable;

.field private i:J

.field private j:J

.field private k:J

.field private l:J

.field private m:Laqk;

.field private n:Lbyq;

.field private o:Ljava/util/Hashtable;

.field private p:Ljava/util/Hashtable;

.field private q:Laqs;

.field private r:D

.field private s:D

.field private t:D

.field private u:D

.field private v:D

.field private w:D

.field private x:D

.field private y:I

.field private z:Z


# direct methods
.method public constructor <init>(Lbyr;Ljava/util/Hashtable;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lbyw;

    invoke-direct {v0}, Lbyw;-><init>()V

    iput-object v0, p0, Laqg;->e:Lbyw;

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Laqg;->f:Ljava/util/Hashtable;

    new-instance v0, Laqk;

    invoke-direct {v0}, Laqk;-><init>()V

    iput-object v0, p0, Laqg;->m:Laqk;

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Laqg;->o:Ljava/util/Hashtable;

    new-instance v0, Ljava/util/Hashtable;

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    iput-object v0, p0, Laqg;->p:Ljava/util/Hashtable;

    iput-object p1, p0, Laqg;->g:Lbyr;

    iput-object p2, p0, Laqg;->h:Ljava/util/Hashtable;

    return-void
.end method

.method private c(I)I
    .locals 2

    iget v0, p0, Laqg;->a:I

    mul-int/2addr v0, p1

    iget v1, p0, Laqg;->a:I

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    return v0
.end method

.method private d(I)I
    .locals 2

    iget v0, p0, Laqg;->b:I

    mul-int/2addr v0, p1

    iget v1, p0, Laqg;->b:I

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    return v0
.end method


# virtual methods
.method public a()I
    .locals 2

    iget-wide v0, p0, Laqg;->w:D

    double-to-int v0, v0

    return v0
.end method

.method public a(I)Laqp;
    .locals 5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->o:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Laqp;

    iget-object v2, p0, Laqg;->e:Lbyw;

    iget-object v3, p0, Laqg;->g:Lbyr;

    iget-object v4, p0, Laqg;->h:Ljava/util/Hashtable;

    invoke-static {p1, v3, v4}, Larh;->a(ILbyr;Ljava/util/Hashtable;)Lbze;

    move-result-object v3

    invoke-static {}, Laqj;->a()Laqj;

    move-result-object v4

    invoke-virtual {v4, p1}, Laqj;->o(I)I

    move-result v4

    invoke-direct {v1, v2, v3, v4}, Laqp;-><init>(Lbyw;Lbze;I)V

    iget-object v2, p0, Laqg;->o:Ljava/util/Hashtable;

    invoke-virtual {v2, v0, v1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget-object v1, p0, Laqg;->o:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqp;

    return-object v0
.end method

.method public a(II)Laqr;
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "_"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->p:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Laqr;

    iget-object v2, p0, Laqg;->g:Lbyr;

    iget-object v3, p0, Laqg;->h:Ljava/util/Hashtable;

    invoke-direct {v1, p2, p0, v2, v3}, Laqr;-><init>(ILaqg;Lbyr;Ljava/util/Hashtable;)V

    iget-object v2, p0, Laqg;->p:Ljava/util/Hashtable;

    invoke-virtual {v2, v0, v1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget-object v1, p0, Laqg;->p:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqr;

    return-object v0
.end method

.method public a(IIII)V
    .locals 3

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    invoke-direct {p0, p2}, Laqg;->c(I)I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {v0, v1, v2}, Laqs;->a(D)V

    invoke-direct {p0, p3}, Laqg;->d(I)I

    move-result v1

    int-to-double v1, v1

    invoke-virtual {v0, v1, v2}, Laqs;->b(D)V

    invoke-virtual {v0, p4}, Laqs;->a(I)V

    iget-object v1, p0, Laqg;->e:Lbyw;

    invoke-virtual {v1, v0}, Lbyw;->a(Lbyx;)V

    return-void
.end method

.method public a(ILaqr;II)V
    .locals 7

    iget-object v0, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Laqs;

    const/4 v2, 0x0

    invoke-virtual {p2}, Laqr;->c()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {p2}, Laqr;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_0

    new-instance v2, Lbyq;

    iget-object v3, p0, Laqg;->g:Lbyr;

    invoke-virtual {p2}, Laqr;->c()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lbyr;->b(Ljava/lang/String;)I

    move-result v3

    iget-object v4, p0, Laqg;->g:Lbyr;

    iget-object v5, p0, Laqg;->h:Ljava/util/Hashtable;

    invoke-direct {v2, v3, v4, v5}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    :cond_0
    invoke-virtual {p2}, Laqr;->e()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Laqs;->a(Lbyq;I)V

    iget-wide v1, p0, Laqg;->s:D

    int-to-double v3, p4

    mul-double/2addr v1, v3

    iget-wide v3, p0, Laqg;->r:D

    div-double/2addr v1, v3

    iget-wide v3, p0, Laqg;->t:D

    int-to-double v5, p4

    mul-double/2addr v3, v5

    iget-wide v5, p0, Laqg;->r:D

    div-double/2addr v3, v5

    iget v5, p0, Laqg;->y:I

    invoke-virtual {v0}, Laqs;->j()Laqo;

    move-result-object v0

    invoke-virtual {v0}, Laqo;->b()I

    move-result v0

    if-ne v5, v0, :cond_1

    iget-boolean v0, p0, Laqg;->z:Z

    if-eqz v0, :cond_2

    iget-wide v5, p0, Laqg;->w:D

    cmpl-double v0, v1, v5

    if-lez v0, :cond_6

    iget-wide v0, p0, Laqg;->w:D

    :goto_0
    iget-wide v5, p0, Laqg;->x:D

    cmpl-double v2, v3, v5

    if-lez v2, :cond_5

    iget-wide v2, p0, Laqg;->x:D

    :goto_1
    iget-wide v4, p0, Laqg;->u:D

    add-double/2addr v4, v0

    iput-wide v4, p0, Laqg;->u:D

    iget-wide v4, p0, Laqg;->v:D

    add-double/2addr v4, v2

    iput-wide v4, p0, Laqg;->v:D

    iget-wide v4, p0, Laqg;->w:D

    sub-double v0, v4, v0

    iput-wide v0, p0, Laqg;->w:D

    iget-wide v0, p0, Laqg;->x:D

    sub-double/2addr v0, v2

    iput-wide v0, p0, Laqg;->x:D

    :cond_1
    :goto_2
    return-void

    :cond_2
    iget-wide v5, p0, Laqg;->u:D

    cmpl-double v0, v1, v5

    if-lez v0, :cond_3

    iget-wide v1, p0, Laqg;->u:D

    :cond_3
    iget-wide v5, p0, Laqg;->v:D

    cmpl-double v0, v3, v5

    if-lez v0, :cond_4

    iget-wide v3, p0, Laqg;->v:D

    :cond_4
    iget-wide v5, p0, Laqg;->w:D

    add-double/2addr v5, v1

    iput-wide v5, p0, Laqg;->w:D

    iget-wide v5, p0, Laqg;->x:D

    add-double/2addr v5, v3

    iput-wide v5, p0, Laqg;->x:D

    iget-wide v5, p0, Laqg;->u:D

    sub-double v0, v5, v1

    iput-wide v0, p0, Laqg;->u:D

    iget-wide v0, p0, Laqg;->v:D

    sub-double/2addr v0, v3

    iput-wide v0, p0, Laqg;->v:D

    goto :goto_2

    :cond_5
    move-wide v2, v3

    goto :goto_1

    :cond_6
    move-wide v0, v1

    goto :goto_0
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laqg;->i:J

    return-void
.end method

.method public a(Laqr;II)V
    .locals 6

    iget-object v0, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Laqs;

    iget-boolean v2, v0, Laqs;->guanghanForm:Z

    if-eqz v2, :cond_0

    iput-object v1, v0, Laqs;->guanghanTarget:Laqs;

    :cond_0
    const-wide/16 v2, 0x0

    iget-boolean v4, v1, Laqs;->guanghanForm:Z

    if-eqz v4, :cond_1

    invoke-virtual {v1}, Laqs;->c()D

    move-result-wide v2

    const-wide/high16 v4, 0x4054000000000000L    # 80.0

    add-double/2addr v2, v4

    :cond_1
    iput-wide v2, v0, Laqs;->projectileTargetHeight:D

    invoke-virtual {v1}, Laqs;->a()D

    move-result-wide v2

    invoke-virtual {v1}, Laqs;->b()D

    move-result-wide v4

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Laqs;->a(Laqr;DD)V

    return-void
.end method

.method public a(Laqs;)V
    .locals 2

    invoke-virtual {p1}, Laqs;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-virtual {v1, v0, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public a(Lcar;IIII)V
    .locals 8

    iget-object v0, p0, Laqg;->n:Lbyq;

    neg-int v1, p2

    neg-int v2, p3

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1, v2, v3}, Lbyq;->a(Lcar;III)V

    iget-object v0, p0, Laqg;->e:Lbyw;

    invoke-virtual {p0}, Laqg;->m()I

    move-result v1

    sub-int v2, v1, p2

    invoke-virtual {p0}, Laqg;->n()I

    move-result v1

    sub-int v3, v1, p3

    invoke-virtual {p0}, Laqg;->m()I

    move-result v1

    sub-int v4, p2, v1

    invoke-virtual {p0}, Laqg;->n()I

    move-result v1

    sub-int v5, p3, v1

    move-object v1, p1

    move v6, p4

    move v7, p5

    invoke-virtual/range {v0 .. v7}, Lbyw;->a(Lcar;IIIIII)V

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const-string v0, "|"

    invoke-static {p1, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lbyq;

    iget-object v2, p0, Laqg;->g:Lbyr;

    aget-object v3, v0, v5

    invoke-virtual {v2, v3}, Lbyr;->b(Ljava/lang/String;)I

    move-result v2

    iget-object v3, p0, Laqg;->g:Lbyr;

    iget-object v4, p0, Laqg;->h:Ljava/util/Hashtable;

    invoke-direct {v1, v2, v3, v4}, Lbyq;-><init>(ILbyr;Ljava/util/Hashtable;)V

    iput-object v1, p0, Laqg;->n:Lbyq;

    iget-object v1, p0, Laqg;->n:Lbyq;

    iget-object v2, p0, Laqg;->h:Ljava/util/Hashtable;

    invoke-static {v1, v2}, Lbvy;->a(Lbyq;Ljava/util/Hashtable;)V

    aget-object v0, v0, v6

    const-string v1, ","

    invoke-static {v0, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    aget-object v1, v0, v5

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqg;->c:I

    aget-object v0, v0, v6

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Laqg;->d:I

    iget-object v0, p0, Laqg;->n:Lbyq;

    invoke-virtual {v0, v5}, Lbyq;->e(I)I

    move-result v0

    iget v1, p0, Laqg;->c:I

    div-int/2addr v0, v1

    iput v0, p0, Laqg;->a:I

    iget-object v0, p0, Laqg;->n:Lbyq;

    invoke-virtual {v0, v5}, Lbyq;->f(I)I

    move-result v0

    iget v1, p0, Laqg;->d:I

    div-int/2addr v0, v1

    iput v0, p0, Laqg;->b:I

    return-void
.end method

.method public b()I
    .locals 2

    iget-wide v0, p0, Laqg;->x:D

    double-to-int v0, v0

    return v0
.end method

.method public b(I)Laqs;
    .locals 2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    :cond_0
    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    return-object v0
.end method

.method public b(II)V
    .locals 2

    iget-object v0, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    invoke-virtual {v0, p2}, Laqs;->c(I)V

    return-void
.end method

.method public b(IIII)V
    .locals 6

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqg;->f:Ljava/util/Hashtable;

    invoke-virtual {v1, v0}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqs;

    invoke-direct {p0, p2}, Laqg;->c(I)I

    move-result v1

    int-to-double v1, v1

    invoke-direct {p0, p3}, Laqg;->d(I)I

    move-result v3

    int-to-double v3, v3

    move v5, p4

    invoke-virtual/range {v0 .. v5}, Laqs;->a(DDI)V

    iget-object v1, p0, Laqg;->q:Laqs;

    if-nez v1, :cond_0

    iput-object v0, p0, Laqg;->q:Laqs;

    :cond_0
    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Laqg;->j:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const-wide/16 v6, 0x0

    const-string v2, "_"

    invoke-static {p1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v3, v2, v0

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Laqg;->y:I

    const-string v3, "1"

    aget-object v4, v2, v1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    iput-boolean v3, p0, Laqg;->z:Z

    iget-object v3, p0, Laqg;->m:Laqk;

    iget-boolean v4, p0, Laqg;->z:Z

    if-eqz v4, :cond_0

    const-string v4, "1"

    aget-object v5, v2, v8

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    :cond_0
    iget-boolean v4, p0, Laqg;->z:Z

    if-nez v4, :cond_2

    const-string v4, "1"

    aget-object v5, v2, v8

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2

    :cond_1
    move v0, v1

    :cond_2
    invoke-virtual {v3, v0}, Laqk;->a(Z)V

    const/4 v0, 0x3

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->r:D

    const/4 v0, 0x6

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->s:D

    const/4 v0, 0x7

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->t:D

    iget-boolean v0, p0, Laqg;->z:Z

    if-eqz v0, :cond_3

    aget-object v0, v2, v9

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->w:D

    const/4 v0, 0x5

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->x:D

    iput-wide v6, p0, Laqg;->u:D

    iput-wide v6, p0, Laqg;->v:D

    :goto_0
    return-void

    :cond_3
    aget-object v0, v2, v9

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->u:D

    const/4 v0, 0x5

    aget-object v0, v2, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    int-to-double v0, v0

    iput-wide v0, p0, Laqg;->v:D

    iput-wide v6, p0, Laqg;->w:D

    iput-wide v6, p0, Laqg;->x:D

    goto :goto_0
.end method

.method public c()I
    .locals 2

    iget-wide v0, p0, Laqg;->u:D

    double-to-int v0, v0

    return v0
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Laqg;->k:J

    return-void
.end method

.method public d()I
    .locals 2

    iget-wide v0, p0, Laqg;->v:D

    double-to-int v0, v0

    return v0
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Laqg;->l:J

    return-void
.end method

.method public e()Laqs;
    .locals 1

    iget-object v0, p0, Laqg;->q:Laqs;

    return-object v0
.end method

.method public f()Laqk;
    .locals 1

    iget-object v0, p0, Laqg;->m:Laqk;

    return-object v0
.end method

.method public g()J
    .locals 2

    iget-wide v0, p0, Laqg;->i:J

    return-wide v0
.end method

.method public h()J
    .locals 2

    iget-wide v0, p0, Laqg;->j:J

    return-wide v0
.end method

.method public i()J
    .locals 2

    iget-wide v0, p0, Laqg;->k:J

    return-wide v0
.end method

.method public j()J
    .locals 2

    iget-wide v0, p0, Laqg;->l:J

    return-wide v0
.end method

.method public k()Ljava/util/Enumeration;
    .locals 1

    iget-object v0, p0, Laqg;->e:Lbyw;

    invoke-virtual {v0}, Lbyw;->b()Ljava/util/Enumeration;

    move-result-object v0

    return-object v0
.end method

.method public l()Lbyw;
    .locals 1

    iget-object v0, p0, Laqg;->e:Lbyw;

    return-object v0
.end method

.method public m()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public n()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public o()I
    .locals 2

    iget-object v0, p0, Laqg;->n:Lbyq;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lbyq;->a(I)I

    move-result v0

    return v0
.end method

.method public p()I
    .locals 2

    iget-object v0, p0, Laqg;->n:Lbyq;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lbyq;->b(I)I

    move-result v0

    return v0
.end method

.method public q()V
    .locals 1

    iget-object v0, p0, Laqg;->e:Lbyw;

    invoke-virtual {v0}, Lbyw;->a()V

    return-void
.end method
