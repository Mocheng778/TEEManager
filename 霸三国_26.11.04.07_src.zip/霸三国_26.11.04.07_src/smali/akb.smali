.class public Lakb;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Lakj;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lakb;->a:I

    return-void
.end method

.method public a(Lakj;)V
    .locals 0

    iput-object p1, p0, Lakb;->b:Lakj;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakb;->c:Ljava/lang/String;

    return-void
.end method
