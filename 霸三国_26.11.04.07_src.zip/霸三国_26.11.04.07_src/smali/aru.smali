.class public Laru;
.super Lars;


# instance fields
.field private b:Lall;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lall;[Lamz;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, v0, p2}, Lars;-><init>(I[Lamz;)V

    iput-object p1, p0, Laru;->b:Lall;

    invoke-virtual {p1}, Lall;->d()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laru;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laru;->c:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 5

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget-object v1, p0, Laru;->b:Lall;

    invoke-virtual {v1}, Lall;->b()I

    move-result v1

    iget-object v2, p0, Laru;->b:Lall;

    invoke-virtual {v2}, Lall;->c()I

    move-result v2

    invoke-static {}, Latt;->a()Latt;

    move-result-object v3

    invoke-virtual {v3}, Latt;->k()Laks;

    move-result-object v3

    invoke-virtual {v3}, Laks;->d()I

    move-result v3

    invoke-virtual {p0, p1}, Laru;->c([Lakw;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lmm;->b(IIILjava/lang/String;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-static {}, Latt;->a()Latt;

    move-result-object v1

    invoke-virtual {v1}, Latt;->k()Laks;

    move-result-object v1

    invoke-virtual {v1}, Laks;->d()I

    move-result v1

    iget-object v2, p0, Laru;->b:Lall;

    invoke-virtual {v2}, Lall;->b()I

    move-result v2

    iget-object v3, p0, Laru;->b:Lall;

    invoke-virtual {v3}, Lall;->c()I

    move-result v3

    invoke-virtual {v0, v1, v2, v3}, Lmm;->h(III)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 7

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v1}, Lakw;->x()I

    move-result v1

    invoke-virtual {v0, v1}, Latt;->a(I)Lakr;

    const/4 v1, 0x1

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    invoke-virtual {v0}, Latt;->k()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->i()I

    move-result v2

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    invoke-virtual {v0}, Latt;->k()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->j()I

    move-result v3

    iget-object v0, p0, Laru;->b:Lall;

    invoke-virtual {v0}, Lall;->b()I

    move-result v4

    iget-object v0, p0, Laru;->b:Lall;

    invoke-virtual {v0}, Lall;->c()I

    move-result v5

    move-object v0, p0

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Laru;->a(ZIIII[Lakw;)I

    move-result v0

    return v0
.end method

.method public d()I
    .locals 1

    iget-object v0, p0, Laru;->b:Lall;

    invoke-virtual {v0}, Lall;->b()I

    move-result v0

    return v0
.end method

.method public e()I
    .locals 1

    iget-object v0, p0, Laru;->b:Lall;

    invoke-virtual {v0}, Lall;->c()I

    move-result v0

    return v0
.end method
