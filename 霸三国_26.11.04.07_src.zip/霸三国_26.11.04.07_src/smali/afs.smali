.class public Lafs;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lamz;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lamz;)V
    .locals 0

    iput-object p1, p0, Lafs;->a:[Lamz;

    return-void
.end method

.method public a()[Lamz;
    .locals 1

    iget-object v0, p0, Lafs;->a:[Lamz;

    return-object v0
.end method
