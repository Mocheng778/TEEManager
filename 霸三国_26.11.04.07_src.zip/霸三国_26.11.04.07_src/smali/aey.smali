.class public Laey;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Lakw;

.field private e:I

.field private f:I

.field private g:I

.field private h:[Lala;

.field private i:[Lalx;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laey;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laey;->a:I

    return-void
.end method

.method public a(Lakw;)V
    .locals 0

    iput-object p1, p0, Laey;->d:Lakw;

    return-void
.end method

.method public a([Lala;)V
    .locals 0

    iput-object p1, p0, Laey;->h:[Lala;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Laey;->i:[Lalx;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laey;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Laey;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Laey;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Laey;->c:I

    return-void
.end method

.method public d()Lakw;
    .locals 1

    iget-object v0, p0, Laey;->d:Lakw;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Laey;->e:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Laey;->g:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Laey;->f:I

    return-void
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Laey;->g:I

    return-void
.end method

.method public f()[Lala;
    .locals 1

    iget-object v0, p0, Laey;->h:[Lala;

    return-object v0
.end method

.method public g()[Lalx;
    .locals 1

    iget-object v0, p0, Laey;->i:[Lalx;

    return-object v0
.end method
