.class public interface abstract Laoi;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a_(II)Z
.end method
