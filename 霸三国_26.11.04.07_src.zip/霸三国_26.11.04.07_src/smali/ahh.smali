.class public Lahh;
.super Ljava/lang/Object;


# instance fields
.field private a:Lajt;

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lajt;
    .locals 1

    iget-object v0, p0, Lahh;->a:Lajt;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lahh;->b:I

    return-void
.end method

.method public a(Lajt;)V
    .locals 0

    iput-object p1, p0, Lahh;->a:Lajt;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lahh;->b:I

    return v0
.end method
