.class public Lajt;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Laks;

.field private c:Lalw;

.field private d:Laju;

.field private e:[Lalo;

.field private f:[Lalo;

.field private g:J

.field private h:J

.field private i:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()J
    .locals 2

    iget-wide v0, p0, Lajt;->h:J

    return-wide v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lajt;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lajt;->h:J

    return-void
.end method

.method public a(Laju;)V
    .locals 0

    iput-object p1, p0, Lajt;->d:Laju;

    return-void
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Lajt;->b:Laks;

    return-void
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Lajt;->c:Lalw;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lajt;->i:Ljava/lang/String;

    return-void
.end method

.method public a([Lalo;)V
    .locals 0

    iput-object p1, p0, Lajt;->e:[Lalo;

    return-void
.end method

.method public b()Laks;
    .locals 1

    iget-object v0, p0, Lajt;->b:Laks;

    return-object v0
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lajt;->g:J

    return-void
.end method

.method public b([Lalo;)V
    .locals 0

    iput-object p1, p0, Lajt;->f:[Lalo;

    return-void
.end method

.method public c()Lalw;
    .locals 1

    iget-object v0, p0, Lajt;->c:Lalw;

    return-object v0
.end method

.method public d()Laju;
    .locals 1

    iget-object v0, p0, Lajt;->d:Laju;

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lajt;->i:Ljava/lang/String;

    return-object v0
.end method

.method public f()[Lalo;
    .locals 1

    iget-object v0, p0, Lajt;->e:[Lalo;

    return-object v0
.end method

.method public g()[Lalo;
    .locals 1

    iget-object v0, p0, Lajt;->f:[Lalo;

    return-object v0
.end method

.method public h()J
    .locals 2

    iget-wide v0, p0, Lajt;->g:J

    return-wide v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lajt;->a:I

    return v0
.end method
