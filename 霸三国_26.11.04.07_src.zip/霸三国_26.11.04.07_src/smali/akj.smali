.class public Lakj;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:[Lalx;

.field private f:[Lala;

.field private g:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lakj;->a:I

    return-void
.end method

.method public a([Lala;)V
    .locals 0

    iput-object p1, p0, Lakj;->f:[Lala;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lakj;->e:[Lalx;

    return-void
.end method

.method public a()[Lala;
    .locals 1

    iget-object v0, p0, Lakj;->f:[Lala;

    return-object v0
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lakj;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakj;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakj;->b:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakj;->g:I

    return-void
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lakj;->c:I

    return-void
.end method

.method public d()[Lalx;
    .locals 1

    iget-object v0, p0, Lakj;->e:[Lalx;

    return-object v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lakj;->c:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lakj;->d:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lakj;->d:I

    return v0
.end method
