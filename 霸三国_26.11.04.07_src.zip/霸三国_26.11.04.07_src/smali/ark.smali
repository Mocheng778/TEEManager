.class public Lark;
.super Lars;


# instance fields
.field private b:Lcom/lszb/practise/view/TowerView;


# direct methods
.method public constructor <init>([Lamz;Lcom/lszb/practise/view/TowerView;)V
    .locals 1

    const/16 v0, 0xb

    invoke-direct {p0, v0, p1}, Lars;-><init>(I[Lamz;)V

    iput-object p2, p0, Lark;->b:Lcom/lszb/practise/view/TowerView;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    invoke-super {p0}, Lars;->f()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 2

    iput-object p1, p0, Lars;->a:[Lakw;

    iget-object v0, p0, Lark;->b:Lcom/lszb/practise/view/TowerView;

    invoke-virtual {p0, p1}, Lark;->c([Lakw;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/lszb/practise/view/TowerView;->a(Ljava/lang/String;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-virtual {v0}, Lmm;->R()V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    invoke-super {p0}, Lars;->c()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
