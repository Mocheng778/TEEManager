.class public Larn;
.super Lars;


# instance fields
.field private b:Lako;

.field private c:I


# direct methods
.method public constructor <init>(ILako;[Lamz;)V
    .locals 1

    const/4 v0, 0x6

    invoke-direct {p0, v0, p3}, Lars;-><init>(I[Lamz;)V

    iput p1, p0, Larn;->c:I

    iput-object p2, p0, Larn;->b:Lako;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larn;->b:Lako;

    invoke-virtual {v0}, Lako;->d()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 4

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget v1, p0, Larn;->c:I

    invoke-virtual {p0, p1}, Larn;->c([Lakw;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Larn;->b:Lako;

    invoke-virtual {v3}, Lako;->a()I

    move-result v3

    invoke-virtual {v0, v1, v2, v3}, Lmm;->a(ILjava/lang/String;I)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larn;->b:Lako;

    invoke-virtual {v0}, Lako;->c()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
