.class public Laps;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/barracks/view/BarrackRecruitView;


# direct methods
.method public constructor <init>(Lcom/lszb/barracks/view/BarrackRecruitView;)V
    .locals 0

    iput-object p1, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public be(Laej;)V
    .locals 5

    iget-object v0, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    iget-object v0, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v0

    const-class v1, Lcom/lszb/barracks/view/BarracksListView;

    invoke-virtual {v0, v1}, Laok;->c(Ljava/lang/Class;)V

    iget-object v0, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    iget-object v1, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v1}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v1

    invoke-virtual {v1}, Latv;->j()I

    move-result v1

    iget-object v2, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v2

    invoke-virtual {v2}, Latv;->h()Lajw;

    move-result-object v2

    invoke-virtual {v2}, Lajw;->g()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Latt;->a(II)Lamf;

    move-result-object v1

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    iget-object v2, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v2

    invoke-virtual {v2}, Latv;->j()I

    move-result v2

    invoke-virtual {v0, v2}, Latt;->a(I)Lakr;

    move-result-object v2

    const/4 v0, 0x0

    :goto_1
    invoke-virtual {v2}, Lakr;->d()[Lajw;

    move-result-object v3

    array-length v3, v3

    if-ge v0, v3, :cond_1

    invoke-virtual {v2}, Lakr;->d()[Lajw;

    move-result-object v3

    aget-object v3, v3, v0

    invoke-virtual {v3}, Lajw;->g()I

    move-result v3

    iget-object v4, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v4}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v4

    invoke-virtual {v4}, Latv;->h()Lajw;

    move-result-object v4

    invoke-virtual {v4}, Lajw;->g()I

    move-result v4

    if-ne v3, v4, :cond_2

    iget-object v3, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v3}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v3

    invoke-virtual {v2}, Lakr;->d()[Lajw;

    move-result-object v2

    aget-object v0, v2, v0

    invoke-virtual {v3, v0}, Latv;->a(Lajw;)V

    :cond_1
    iget-object v0, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarrackRecruitView;->e()Laok;

    move-result-object v0

    new-instance v2, Lcom/lszb/barracks/view/BarracksProduceListView;

    iget-object v3, p0, Laps;->a:Lcom/lszb/barracks/view/BarrackRecruitView;

    invoke-static {v3}, Lcom/lszb/barracks/view/BarrackRecruitView;->a(Lcom/lszb/barracks/view/BarrackRecruitView;)Latv;

    move-result-object v3

    invoke-direct {v2, v3, v1}, Lcom/lszb/barracks/view/BarracksProduceListView;-><init>(Latv;Lamf;)V

    invoke-virtual {v0, v2}, Laok;->a(Laoj;)V

    goto/16 :goto_0

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1
.end method
