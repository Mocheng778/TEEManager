.class public Lafb;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lalc;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lalc;)V
    .locals 0

    iput-object p1, p0, Lafb;->a:[Lalc;

    return-void
.end method

.method public a()[Lalc;
    .locals 1

    iget-object v0, p0, Lafb;->a:[Lalc;

    return-object v0
.end method
