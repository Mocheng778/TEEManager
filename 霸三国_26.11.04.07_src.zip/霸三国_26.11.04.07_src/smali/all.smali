.class public Lall;
.super Ljava/lang/Object;


# instance fields
.field private A:Ljava/lang/String;

.field private B:I

.field private C:Z

.field private D:Ljava/lang/String;

.field private E:I

.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:I

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:I

.field private j:I

.field private k:I

.field private l:Ljava/lang/String;

.field private m:I

.field private n:I

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:J

.field private t:J

.field private u:J

.field private v:J

.field private w:I

.field private x:I

.field private y:Z

.field private z:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lall;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lall;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lall;->s:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->d:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lall;->y:Z

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lall;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lall;->b:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lall;->t:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->e:Ljava/lang/String;

    return-void
.end method

.method public b(Z)V
    .locals 0

    iput-boolean p1, p0, Lall;->C:Z

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lall;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lall;->c:I

    return-void
.end method

.method public c(J)V
    .locals 0

    iput-wide p1, p0, Lall;->u:J

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->g:Ljava/lang/String;

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lall;->f:I

    return-void
.end method

.method public d(J)V
    .locals 0

    iput-wide p1, p0, Lall;->v:J

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->h:Ljava/lang/String;

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->e:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lall;->i:I

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->l:Ljava/lang/String;

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lall;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lall;->j:I

    return-void
.end method

.method public f(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->A:Ljava/lang/String;

    return-void
.end method

.method public g()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->g:Ljava/lang/String;

    return-object v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lall;->k:I

    return-void
.end method

.method public g(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lall;->D:Ljava/lang/String;

    return-void
.end method

.method public h()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->h:Ljava/lang/String;

    return-object v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lall;->m:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lall;->i:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lall;->n:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lall;->j:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lall;->o:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lall;->k:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lall;->p:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lall;->m:I

    return v0
.end method

.method public l(I)V
    .locals 0

    iput p1, p0, Lall;->q:I

    return-void
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lall;->n:I

    return v0
.end method

.method public m(I)V
    .locals 0

    iput p1, p0, Lall;->r:I

    return-void
.end method

.method public n()I
    .locals 1

    iget v0, p0, Lall;->o:I

    return v0
.end method

.method public n(I)V
    .locals 0

    iput p1, p0, Lall;->w:I

    return-void
.end method

.method public o()I
    .locals 1

    iget v0, p0, Lall;->p:I

    return v0
.end method

.method public o(I)V
    .locals 0

    iput p1, p0, Lall;->x:I

    return-void
.end method

.method public p()I
    .locals 1

    iget v0, p0, Lall;->q:I

    return v0
.end method

.method public p(I)V
    .locals 0

    iput p1, p0, Lall;->z:I

    return-void
.end method

.method public q()I
    .locals 1

    iget v0, p0, Lall;->r:I

    return v0
.end method

.method public q(I)V
    .locals 0

    iput p1, p0, Lall;->B:I

    return-void
.end method

.method public r()J
    .locals 2

    iget-wide v0, p0, Lall;->u:J

    return-wide v0
.end method

.method public r(I)V
    .locals 0

    iput p1, p0, Lall;->E:I

    return-void
.end method

.method public s()J
    .locals 2

    iget-wide v0, p0, Lall;->v:J

    return-wide v0
.end method

.method public t()I
    .locals 1

    iget v0, p0, Lall;->w:I

    return v0
.end method

.method public u()I
    .locals 1

    iget v0, p0, Lall;->x:I

    return v0
.end method

.method public v()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->A:Ljava/lang/String;

    return-object v0
.end method

.method public w()I
    .locals 1

    iget v0, p0, Lall;->B:I

    return v0
.end method

.method public x()Z
    .locals 1

    iget-boolean v0, p0, Lall;->C:Z

    return v0
.end method

.method public y()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lall;->D:Ljava/lang/String;

    return-object v0
.end method
