.class public Laqf;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/util/Vector;


# direct methods
.method public constructor <init>(Laqg;Ljava/lang/String;)V
    .locals 7

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laqf;->b:Ljava/util/Vector;

    const-string v0, ":"

    invoke-static {p2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v0, v3, v2

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x64

    sget v1, Laoe;->a:I

    div-int/2addr v0, v1

    iput v0, p0, Laqf;->a:I

    const/4 v0, 0x1

    :goto_0
    array-length v1, v3

    if-ge v0, v1, :cond_2

    aget-object v1, v3, v0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_1

    aget-object v1, v3, v0

    const-string v4, "|"

    invoke-static {v1, v4}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    move v1, v2

    :goto_1
    array-length v5, v4

    if-ge v1, v5, :cond_1

    aget-object v5, v4, v1

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_0

    iget-object v5, p0, Laqf;->b:Ljava/util/Vector;

    aget-object v6, v4, v1

    invoke-static {p1, v0, v6}, Laqv;->a(Laqg;ILjava/lang/String;)Laqu;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laqf;->a:I

    return v0
.end method

.method public a(Laqg;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Laqf;->b:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Laqf;->b:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqu;

    invoke-virtual {v0, p1}, Laqu;->a(Laqg;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0

    :cond_0
    return-void
.end method
