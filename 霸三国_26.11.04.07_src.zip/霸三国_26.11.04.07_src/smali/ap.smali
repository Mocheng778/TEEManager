.class public final Lap;
.super Laj;


# instance fields
.field public j:I

.field public k:I


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Laj;-><init>()V

    const/16 v0, 0x106

    iput v0, p0, Laj;->a:I

    return-void
.end method


# virtual methods
.method public final a()Lorg/json/JSONObject;
    .locals 3

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "StartSequence"

    iget v2, p0, Lap;->j:I

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "RecordNum"

    iget v2, p0, Lap;->k:I

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    return-object v0
.end method

.method public final b(I)V
    .locals 0

    iput p1, p0, Lap;->j:I

    return-void
.end method

.method public final c(I)V
    .locals 0

    iput p1, p0, Lap;->k:I

    return-void
.end method
