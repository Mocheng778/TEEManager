.class Laog;
.super Ljava/lang/Object;


# instance fields
.field final synthetic a:Laoe;

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>(Laoe;II)V
    .locals 0

    iput-object p1, p0, Laog;->a:Laoe;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Laog;->b:I

    iput p3, p0, Laog;->c:I

    return-void
.end method

.method static synthetic a(Laog;)I
    .locals 1

    iget v0, p0, Laog;->b:I

    return v0
.end method

.method static synthetic b(Laog;)I
    .locals 1

    iget v0, p0, Laog;->c:I

    return v0
.end method
