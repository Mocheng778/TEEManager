.class public Lagt;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lamt;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lamt;)V
    .locals 0

    iput-object p1, p0, Lagt;->a:[Lamt;

    return-void
.end method

.method public a()[Lamt;
    .locals 1

    iget-object v0, p0, Lagt;->a:[Lamt;

    return-object v0
.end method
