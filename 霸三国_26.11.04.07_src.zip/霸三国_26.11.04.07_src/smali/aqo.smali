.class public Laqo;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Z

.field private f:Ljava/util/Vector;


# direct methods
.method public constructor <init>(ZLjava/lang/String;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laqo;->f:Ljava/util/Vector;

    iput-boolean p1, p0, Laqo;->e:Z

    const-string v0, "_"

    invoke-static {p2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, v0, v1

    const-string v2, "1"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    aget-object v1, v0, v3

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Laqo;->a:I

    const/4 v1, 0x2

    aget-object v1, v0, v1

    iput-object v1, p0, Laqo;->b:Ljava/lang/String;

    const/4 v1, 0x3

    aget-object v1, v0, v1

    iput-object v1, p0, Laqo;->c:Ljava/lang/String;

    array-length v1, v0

    if-le v1, v4, :cond_0

    aget-object v0, v0, v4

    :goto_0
    iput-object v0, p0, Laqo;->d:Ljava/lang/String;

    :goto_1
    return-void

    :cond_0
    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    aget-object v0, v0, v3

    iput-object v0, p0, Laqo;->b:Ljava/lang/String;

    goto :goto_1
.end method


# virtual methods
.method public a(Laqs;)V
    .locals 1

    iget-object v0, p0, Laqo;->f:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public a()Z
    .locals 1

    iget-boolean v0, p0, Laqo;->e:Z

    return v0
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laqo;->a:I

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqo;->b:Ljava/lang/String;

    return-object v0
.end method
