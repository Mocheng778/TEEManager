.class public Lagy;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lanj;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lanj;)V
    .locals 0

    iput-object p1, p0, Lagy;->a:[Lanj;

    return-void
.end method

.method public a()[Lanj;
    .locals 1

    iget-object v0, p0, Lagy;->a:[Lanj;

    return-object v0
.end method
