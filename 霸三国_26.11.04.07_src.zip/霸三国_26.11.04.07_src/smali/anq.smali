.class public Lanq;
.super Ljava/lang/Object;


# instance fields
.field private A:I

.field private B:I

.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:I

.field private m:I

.field private n:I

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:I

.field private v:I

.field private w:I

.field private x:Z

.field private y:I

.field private z:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lanq;->s:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lanq;->h:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lanq;->b:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lanq;->x:Z

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lanq;->t:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lanq;->s:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lanq;->c:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lanq;->a:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lanq;->z:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lanq;->d:Ljava/lang/String;

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lanq;->g:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lanq;->A:I

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lanq;->e:Ljava/lang/String;

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lanq;->i:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lanq;->t:I

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lanq;->f:Ljava/lang/String;

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lanq;->j:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lanq;->a:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lanq;->k:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lanq;->n:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lanq;->l:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lanq;->g:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lanq;->m:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lanq;->i:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lanq;->o:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lanq;->j:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lanq;->p:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lanq;->k:I

    return-void
.end method

.method public l()I
    .locals 1

    iget v0, p0, Lanq;->q:I

    return v0
.end method

.method public l(I)V
    .locals 0

    iput p1, p0, Lanq;->l:I

    return-void
.end method

.method public m()I
    .locals 1

    iget v0, p0, Lanq;->r:I

    return v0
.end method

.method public m(I)V
    .locals 0

    iput p1, p0, Lanq;->m:I

    return-void
.end method

.method public n()I
    .locals 1

    iget v0, p0, Lanq;->B:I

    return v0
.end method

.method public n(I)V
    .locals 0

    iput p1, p0, Lanq;->o:I

    return-void
.end method

.method public o(I)V
    .locals 0

    iput p1, p0, Lanq;->p:I

    return-void
.end method

.method public p(I)V
    .locals 0

    iput p1, p0, Lanq;->q:I

    return-void
.end method

.method public q(I)V
    .locals 0

    iput p1, p0, Lanq;->r:I

    return-void
.end method

.method public r(I)V
    .locals 0

    iput p1, p0, Lanq;->u:I

    return-void
.end method

.method public s(I)V
    .locals 0

    iput p1, p0, Lanq;->v:I

    return-void
.end method

.method public t(I)V
    .locals 0

    iput p1, p0, Lanq;->w:I

    return-void
.end method

.method public u(I)V
    .locals 0

    iput p1, p0, Lanq;->y:I

    return-void
.end method

.method public v(I)V
    .locals 0

    iput p1, p0, Lanq;->B:I

    return-void
.end method
