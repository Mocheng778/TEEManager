.class public Laer;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lakw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lakw;)V
    .locals 0

    iput-object p1, p0, Laer;->a:[Lakw;

    return-void
.end method
