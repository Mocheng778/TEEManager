.class public abstract Laqc;
.super Ljava/lang/Object;


# instance fields
.field protected a:Lbxf;

.field protected b:I

.field protected c:Laok;

.field private d:Lbxr;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Lapr;

.field private i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "\u5175\u8425\u884c"

    iput-object v0, p0, Laqc;->e:Ljava/lang/String;

    const-string v0, "\u5175\u79cd"

    iput-object v0, p0, Laqc;->f:Ljava/lang/String;

    const-string v0, "\u4fe1\u606f"

    iput-object v0, p0, Laqc;->g:Ljava/lang/String;

    iput p1, p0, Laqc;->b:I

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v0

    invoke-virtual {v0, p1}, Lapp;->c(I)Lapr;

    move-result-object v0

    iput-object v0, p0, Laqc;->h:Lapr;

    return-void
.end method

.method static synthetic a(Laqc;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqc;->f:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic b(Laqc;)Lapr;
    .locals 1

    iget-object v0, p0, Laqc;->h:Lapr;

    return-object v0
.end method


# virtual methods
.method protected a(II)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Laqc;->a:Lbxf;

    iget-object v1, p0, Laqc;->a:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Laqc;->a:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method protected abstract a()Ljava/lang/String;
.end method

.method public a(Laok;Lanx;Ljava/util/Hashtable;II)V
    .locals 3

    iput-object p1, p0, Laqc;->c:Laok;

    :try_start_0
    new-instance v0, Lbxr;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Laqc;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v2

    invoke-direct {v0, v1, p3, v2}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    iput-object v0, p0, Laqc;->d:Lbxr;

    iget-object v0, p0, Laqc;->d:Lbxr;

    invoke-static {v0, p3}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    sget-boolean v0, Lcom/lszb/GameMIDlet;->b:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Laqc;->d:Lbxr;

    iget-object v1, p0, Laqc;->h:Lapr;

    invoke-virtual {v1}, Lapr;->a()Lbyq;

    move-result-object v1

    invoke-static {p3, v0, v1, p2}, Lbvw;->a(Ljava/util/Hashtable;Lbxr;Lbyq;Lanx;)V

    :cond_0
    iget-object v0, p0, Laqc;->d:Lbxr;

    iget-object v1, p0, Laqc;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Laqc;->a:Lbxf;

    iget-object v0, p0, Laqc;->a:Lbxf;

    invoke-virtual {v0, p4}, Lbxf;->e(I)V

    iget-object v0, p0, Laqc;->a:Lbxf;

    invoke-virtual {v0, p5}, Lbxf;->f(I)V

    new-instance v1, Laqd;

    invoke-direct {v1, p0}, Laqd;-><init>(Laqc;)V

    iget-object v0, p0, Laqc;->d:Lbxr;

    iget-object v2, p0, Laqc;->f:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Laqc;->d:Lbxr;

    invoke-virtual {p0, v0, p4, p5}, Laqc;->a(Lbxr;II)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method protected abstract a(Lbxr;II)V
.end method

.method public a(Lcar;IIZ)V
    .locals 3

    if-eqz p4, :cond_0

    iget-object v0, p0, Laqc;->a:Lbxf;

    invoke-virtual {v0}, Lbxf;->m()V

    :goto_0
    iget-object v0, p0, Laqc;->a:Lbxf;

    iget-object v1, p0, Laqc;->a:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Laqc;->a:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void

    :cond_0
    iget-object v0, p0, Laqc;->a:Lbxf;

    invoke-virtual {v0}, Lbxf;->n()V

    goto :goto_0
.end method

.method protected a(Ljava/lang/Object;)V
    .locals 3

    instance-of v0, p1, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    check-cast p1, Lcom/lzlm/component/ButtonComponent;

    iget-object v0, p0, Laqc;->g:Ljava/lang/String;

    invoke-virtual {p1}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqc;->c:Laok;

    new-instance v1, Lcom/lszb/barracks/view/BarracksInfoView;

    iget v2, p0, Laqc;->b:I

    invoke-direct {v1, v2}, Lcom/lszb/barracks/view/BarracksInfoView;-><init>(I)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :cond_0
    return-void
.end method

.method public b(II)V
    .locals 1

    invoke-virtual {p0, p1, p2}, Laqc;->a(II)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Laqc;->i:Ljava/lang/Object;

    iget-object v0, p0, Laqc;->i:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqc;->i:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->m()V

    :cond_0
    return-void
.end method

.method public c(II)V
    .locals 2

    invoke-virtual {p0, p1, p2}, Laqc;->a(II)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Laqc;->i:Ljava/lang/Object;

    if-eqz v1, :cond_0

    iget-object v1, p0, Laqc;->i:Ljava/lang/Object;

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqc;->i:Ljava/lang/Object;

    invoke-virtual {p0, v0}, Laqc;->a(Ljava/lang/Object;)V

    :cond_0
    iget-object v0, p0, Laqc;->i:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqc;->i:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->n()V

    :cond_1
    return-void
.end method
