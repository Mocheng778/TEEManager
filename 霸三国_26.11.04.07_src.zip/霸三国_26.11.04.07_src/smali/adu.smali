.class public Ladu;
.super Ljava/lang/Object;

# interfaces
.implements Lframework/server/game/IReader;


# instance fields
.field final synthetic a:Ladt;


# direct methods
.method public constructor <init>(Ladt;)V
    .locals 0

    iput-object p1, p0, Ladu;->a:Ladt;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public read(Ljava/io/DataInputStream;)V
    .locals 4

    new-instance v1, Lagr;

    invoke-direct {v1}, Lagr;-><init>()V

    invoke-static {v1, p1}, Lframework/server/game/ControllerResponse;->read(Lframework/server/game/ControllerResponse;Ljava/io/DataInputStream;)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lagr;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [B

    const/4 v0, 0x0

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readByte()B

    move-result v3

    aput-byte v3, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v1, v2}, Lagr;->a([B)V

    :cond_2
    iget-object v0, p0, Ladu;->a:Ladt;

    invoke-static {v0}, Ladt;->a(Ladt;)Lads;

    move-result-object v0

    invoke-interface {v0, v1}, Lads;->a(Lagr;)V

    return-void
.end method
