.class Laof;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Laoh;

.field final synthetic b:Laoe;


# direct methods
.method constructor <init>(Laoe;Laoh;)V
    .locals 0

    iput-object p1, p0, Laof;->b:Laoe;

    iput-object p2, p0, Laof;->a:Laoh;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const/4 v2, 0x0

    :cond_0
    :goto_0
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->a(Laoe;)Z

    move-result v0

    if-eqz v0, :cond_7

    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->b(Laoe;)Laok;

    move-result-object v0

    invoke-virtual {v0}, Laok;->f()Z

    move-result v0

    if-eqz v0, :cond_6

    move v1, v2

    :goto_1
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->c(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_1

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->b(Laoe;)Laok;

    move-result-object v5

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->c(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v5, v0}, Laok;->a(I)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1

    :cond_1
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->c(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    move v1, v2

    :goto_2
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->d(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_2

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->b(Laoe;)Laok;

    move-result-object v5

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->d(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v5, v0}, Laok;->b(I)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_2

    :cond_2
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->d(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    move v1, v2

    :goto_3
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->e(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_3

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->e(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laog;

    iget-object v5, p0, Laof;->b:Laoe;

    invoke-static {v5}, Laoe;->b(Laoe;)Laok;

    move-result-object v5

    invoke-static {v0}, Laog;->a(Laog;)I

    move-result v6

    invoke-static {v0}, Laog;->b(Laog;)I

    move-result v0

    invoke-virtual {v5, v6, v0}, Laok;->a(II)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_3

    :cond_3
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->e(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    move v1, v2

    :goto_4
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->f(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_4

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->f(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laog;

    iget-object v5, p0, Laof;->b:Laoe;

    invoke-static {v5}, Laoe;->b(Laoe;)Laok;

    move-result-object v5

    invoke-static {v0}, Laog;->a(Laog;)I

    move-result v6

    invoke-static {v0}, Laog;->b(Laog;)I

    move-result v0

    invoke-virtual {v5, v6, v0}, Laok;->c(II)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_4

    :cond_4
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->f(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    move v1, v2

    :goto_5
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->g(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_5

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->g(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laog;

    iget-object v5, p0, Laof;->b:Laoe;

    invoke-static {v5}, Laoe;->b(Laoe;)Laok;

    move-result-object v5

    invoke-static {v0}, Laog;->a(Laog;)I

    move-result v6

    invoke-static {v0}, Laog;->b(Laog;)I

    move-result v0

    invoke-virtual {v5, v6, v0}, Laok;->b(II)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_5

    :cond_5
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->g(Laoe;)Ljava/util/Vector;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->b(Laoe;)Laok;

    move-result-object v0

    invoke-virtual {v0}, Laok;->g()V

    iget-object v0, p0, Laof;->a:Laoh;

    if-eqz v0, :cond_6

    iget-object v0, p0, Laof;->a:Laoh;

    invoke-interface {v0}, Laoh;->a()V

    :cond_6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-object v5, p0, Laof;->b:Laoe;

    invoke-virtual {v5}, Laoe;->f()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    sub-long v0, v5, v0

    sput-wide v0, Laoe;->c:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sub-long/2addr v0, v3

    sput-wide v0, Laoe;->b:J

    sget-wide v0, Laoe;->b:J

    sget v3, Laoe;->a:I

    int-to-long v3, v3

    cmp-long v0, v0, v3

    if-gez v0, :cond_0

    sget v0, Laoe;->a:I

    int-to-long v0, v0

    sget-wide v3, Laoe;->b:J

    sub-long/2addr v0, v3

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto/16 :goto_0

    :cond_7
    iget-object v0, p0, Laof;->b:Laoe;

    invoke-static {v0}, Laoe;->h(Laoe;)Lcaw;

    move-result-object v0

    invoke-virtual {v0}, Lcaw;->v()V

    return-void
.end method
