.class public final Lan;
.super Laj;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Laj;-><init>()V

    const/4 v0, 0x2

    iput v0, p0, Lan;->a:I

    return-void
.end method


# virtual methods
.method public final a()Lorg/json/JSONObject;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method
