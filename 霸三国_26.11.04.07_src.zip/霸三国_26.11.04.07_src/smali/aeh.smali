.class public Laeh;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:[Laks;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Laeh;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laeh;->a:I

    return-void
.end method

.method public a([Laks;)V
    .locals 0

    iput-object p1, p0, Laeh;->c:[Laks;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laeh;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Laeh;->b:I

    return-void
.end method

.method public c()[Laks;
    .locals 1

    iget-object v0, p0, Laeh;->c:[Laks;

    return-object v0
.end method
