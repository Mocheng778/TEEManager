.class public Lash;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private final g:Ljava/lang/String;

.field private final h:Ljava/lang/String;

.field private final i:Ljava/lang/String;

.field private final j:Ljava/lang/String;

.field private k:Lbxf;

.field private l:Laqi;


# direct methods
.method public constructor <init>(Laqi;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "\u653b\u65b9"

    iput-object v0, p0, Lash;->a:Ljava/lang/String;

    const-string v0, "\u73a9\u5bb6\u540d"

    iput-object v0, p0, Lash;->b:Ljava/lang/String;

    const-string v0, "\u5c06\u9886\u540d"

    iput-object v0, p0, Lash;->c:Ljava/lang/String;

    const-string v0, "\u7b49\u7ea7"

    iput-object v0, p0, Lash;->d:Ljava/lang/String;

    const-string v0, "\u5175\u79cd"

    iput-object v0, p0, Lash;->e:Ljava/lang/String;

    const-string v0, "\u6570\u91cf"

    iput-object v0, p0, Lash;->f:Ljava/lang/String;

    const-string v0, "\u4f24\u4ea1"

    iput-object v0, p0, Lash;->g:Ljava/lang/String;

    const-string v0, "\u6740\u654c"

    iput-object v0, p0, Lash;->h:Ljava/lang/String;

    const-string v0, "\u7ecf\u9a8c"

    iput-object v0, p0, Lash;->i:Ljava/lang/String;

    const-string v0, "\u884c"

    iput-object v0, p0, Lash;->j:Ljava/lang/String;

    iput-object p1, p0, Lash;->l:Laqi;

    return-void
.end method

.method static synthetic a(Lash;)Laqi;
    .locals 1

    iget-object v0, p0, Lash;->l:Laqi;

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 1

    iget-object v0, p0, Lash;->k:Lbxf;

    invoke-virtual {v0}, Lbxf;->b()I

    move-result v0

    return v0
.end method

.method public a(ILjava/util/Hashtable;)V
    .locals 10

    :try_start_0
    new-instance v9, Lbxr;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "battle_result_row.bin"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v1

    invoke-direct {v9, v0, p2, v1}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "ui-battle.properties"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf-8"

    invoke-static {v0, v1}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    invoke-static {v9, p2}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    iget-object v1, p0, Lash;->l:Laqi;

    invoke-virtual {v1}, Laqi;->a()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "battle_result_row.\u653b"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_0
    iget-object v0, p0, Lash;->l:Laqi;

    invoke-virtual {v0}, Laqi;->d()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v0

    iget-object v1, p0, Lash;->l:Laqi;

    invoke-virtual {v1}, Laqi;->e()I

    move-result v1

    invoke-virtual {v0, v1}, Lapp;->c(I)Lapr;

    move-result-object v4

    iget-object v0, p0, Lash;->l:Laqi;

    invoke-virtual {v0}, Laqi;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    iget-object v0, p0, Lash;->l:Laqi;

    invoke-virtual {v0}, Laqi;->g()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    iget-object v0, p0, Lash;->l:Laqi;

    invoke-virtual {v0}, Laqi;->h()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    iget-object v0, p0, Lash;->l:Laqi;

    invoke-virtual {v0}, Laqi;->i()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    new-instance v0, Lasi;

    move-object v1, p0

    invoke-direct/range {v0 .. v8}, Lasi;-><init>(Lash;Ljava/lang/String;Ljava/lang/String;Lapr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "\u653b\u65b9"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u73a9\u5bb6\u540d"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u5c06\u9886\u540d"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u7b49\u7ea7"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u5175\u79cd"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u6570\u91cf"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u4f24\u4ea1"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u6740\u654c"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v1, "\u7ecf\u9a8c"

    invoke-virtual {v9, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v1

    check-cast v1, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v1, v0}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    const-string v0, "\u884c"

    invoke-virtual {v9, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lash;->k:Lbxf;

    iget-object v0, p0, Lash;->k:Lbxf;

    invoke-virtual {v0, p1}, Lbxf;->e(I)V

    :goto_1
    return-void

    :cond_0
    const-string v1, "battle_result_row.\u9632"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v2

    goto/16 :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_1
.end method

.method public a(Lcar;II)V
    .locals 3

    iget-object v0, p0, Lash;->k:Lbxf;

    iget-object v1, p0, Lash;->k:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Lash;->k:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void
.end method
