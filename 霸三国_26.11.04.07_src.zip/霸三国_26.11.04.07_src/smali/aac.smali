.class public Laac;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lakr;Ljava/io/DataInputStream;)V
    .locals 4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lakr;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lakr;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lajq;

    invoke-direct {v0}, Lajq;-><init>()V

    invoke-static {v0, p1}, Lzb;->a(Lajq;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lakr;->a(Lajq;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Laks;

    invoke-direct {v0}, Laks;-><init>()V

    invoke-static {v0, p1}, Laad;->a(Laks;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lakr;->a(Laks;)V

    :cond_2
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Lajr;

    invoke-direct {v0}, Lajr;-><init>()V

    invoke-static {v0, p1}, Lzc;->a(Lajr;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lakr;->a(Lajr;)V

    :cond_3
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    invoke-virtual {p0, v0}, Lakr;->a(Z)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lajv;

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_5

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_4

    new-instance v3, Lajv;

    invoke-direct {v3}, Lajv;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Lzg;->a(Lajv;Ljava/io/DataInputStream;)V

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p0, v2}, Lakr;->a([Lajv;)V

    :cond_6
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lajw;

    move v0, v1

    :goto_1
    array-length v3, v2

    if-ge v0, v3, :cond_8

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_7

    new-instance v3, Lajw;

    invoke-direct {v3}, Lajw;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Lzh;->a(Lajw;Ljava/io/DataInputStream;)V

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_8
    invoke-virtual {p0, v2}, Lakr;->a([Lajw;)V

    :cond_9
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lakw;

    move v0, v1

    :goto_2
    array-length v3, v2

    if-ge v0, v3, :cond_b

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_a

    new-instance v3, Lakw;

    invoke-direct {v3}, Lakw;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Laah;->a(Lakw;Ljava/io/DataInputStream;)V

    :cond_a
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_b
    invoke-virtual {p0, v2}, Lakr;->a([Lakw;)V

    :cond_c
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lamb;

    move v0, v1

    :goto_3
    array-length v3, v2

    if-ge v0, v3, :cond_e

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_d

    new-instance v3, Lamb;

    invoke-direct {v3}, Lamb;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Labl;->a(Lamb;Ljava/io/DataInputStream;)V

    :cond_d
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_e
    invoke-virtual {p0, v2}, Lakr;->b([Lamb;)V

    :cond_f
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_12

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lamb;

    move v0, v1

    :goto_4
    array-length v3, v2

    if-ge v0, v3, :cond_11

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_10

    new-instance v3, Lamb;

    invoke-direct {v3}, Lamb;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Labl;->a(Lamb;Ljava/io/DataInputStream;)V

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_11
    invoke-virtual {p0, v2}, Lakr;->a([Lamb;)V

    :cond_12
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v0, v0, [Lamf;

    :goto_5
    array-length v2, v0

    if-ge v1, v2, :cond_14

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_13

    new-instance v2, Lamf;

    invoke-direct {v2}, Lamf;-><init>()V

    aput-object v2, v0, v1

    aget-object v2, v0, v1

    invoke-static {v2, p1}, Labp;->a(Lamf;Ljava/io/DataInputStream;)V

    :cond_13
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_14
    invoke-virtual {p0, v0}, Lakr;->a([Lamf;)V

    :cond_15
    return-void
.end method
