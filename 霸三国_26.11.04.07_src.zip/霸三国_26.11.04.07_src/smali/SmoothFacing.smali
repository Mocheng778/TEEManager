.class public final LSmoothFacing;
.super Ljava/lang/Object;
.source "SmoothFacing.java"


# static fields
.field private static final ADD:Landroid/graphics/PorterDuffXfermode;

.field private static final BEAST_TAIL_X:[F

.field private static final BEAST_TAIL_Y:[F

.field private static final BEAST_X:[F

.field private static final BEAST_Y:[F

.field private static final BIRD_TAIL_X:[F

.field private static final BIRD_TAIL_Y:[F

.field private static final BIRD_X:[F

.field private static final BIRD_Y:[F

.field private static final DIRECTIONS:[I

.field private static final DRAGON_MOUTH_X:[F

.field private static final DRAGON_MOUTH_Y:[F

.field private static final DRAGON_TAIL_X:[F

.field private static final DRAGON_TAIL_Y:[F

.field private static final DRAGON_X:[F

.field private static final DRAGON_Y:[F

.field private static final HEIGHT:I = 0x100

.field private static final MESH:I = 0x10

.field private static final PAINT:Landroid/graphics/Paint;

.field private static final TIGER_TAIL_X:[F

.field private static final TIGER_TAIL_Y:[F

.field private static final TIGER_X:[F

.field private static final TIGER_Y:[F

.field private static final VIEWS:[I

.field private static final WIDTH:I = 0xc0

.field private static final X:I = 0x60

.field private static final Y:I = 0xdc

.field private static graphicsA:Lcar;

.field private static graphicsB:Lcar;

.field private static final mesh:[F

.field private static mixed:Landroid/graphics/Bitmap;

.field private static mixture:Landroid/graphics/Canvas;

.field private static poseA:Landroid/graphics/Bitmap;

.field private static poseB:Landroid/graphics/Bitmap;


# instance fields
.field private angle:F

.field private dragonAimed:[Lbyq;

.field private dragonCoil:Lbyq;

.field private target:F

.field private velocity:F


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 9
    const/16 v0, 0x8

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    sput-object v1, LSmoothFacing;->DIRECTIONS:[I

    .line 10
    new-array v0, v0, [I

    fill-array-data v0, :array_1

    sput-object v0, LSmoothFacing;->VIEWS:[I

    .line 11
    const/4 v0, 0x5

    new-array v1, v0, [F

    fill-array-data v1, :array_2

    sput-object v1, LSmoothFacing;->BIRD_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_3

    sput-object v1, LSmoothFacing;->BIRD_Y:[F

    .line 12
    new-array v1, v0, [F

    fill-array-data v1, :array_4

    sput-object v1, LSmoothFacing;->BEAST_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_5

    sput-object v1, LSmoothFacing;->BEAST_Y:[F

    .line 13
    new-array v1, v0, [F

    fill-array-data v1, :array_6

    sput-object v1, LSmoothFacing;->BIRD_TAIL_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_7

    sput-object v1, LSmoothFacing;->BIRD_TAIL_Y:[F

    .line 14
    new-array v1, v0, [F

    fill-array-data v1, :array_8

    sput-object v1, LSmoothFacing;->BEAST_TAIL_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_9

    sput-object v1, LSmoothFacing;->BEAST_TAIL_Y:[F

    .line 15
    new-array v1, v0, [F

    fill-array-data v1, :array_a

    sput-object v1, LSmoothFacing;->DRAGON_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_b

    sput-object v1, LSmoothFacing;->DRAGON_Y:[F

    .line 16
    new-array v1, v0, [F

    fill-array-data v1, :array_c

    sput-object v1, LSmoothFacing;->DRAGON_TAIL_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_d

    sput-object v1, LSmoothFacing;->DRAGON_TAIL_Y:[F

    .line 17
    new-array v1, v0, [F

    fill-array-data v1, :array_e

    sput-object v1, LSmoothFacing;->TIGER_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_f

    sput-object v1, LSmoothFacing;->TIGER_Y:[F

    .line 18
    new-array v1, v0, [F

    fill-array-data v1, :array_10

    sput-object v1, LSmoothFacing;->TIGER_TAIL_X:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_11

    sput-object v1, LSmoothFacing;->TIGER_TAIL_Y:[F

    .line 20
    new-instance v1, Landroid/graphics/Paint;

    const/4 v2, 0x3

    invoke-direct {v1, v2}, Landroid/graphics/Paint;-><init>(I)V

    sput-object v1, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    .line 21
    new-instance v1, Landroid/graphics/PorterDuffXfermode;

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->ADD:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v1, v2}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    sput-object v1, LSmoothFacing;->ADD:Landroid/graphics/PorterDuffXfermode;

    .line 25
    const/16 v1, 0x242

    new-array v1, v1, [F

    sput-object v1, LSmoothFacing;->mesh:[F

    .line 29
    new-array v1, v0, [F

    fill-array-data v1, :array_12

    sput-object v1, LSmoothFacing;->DRAGON_MOUTH_X:[F

    .line 30
    new-array v0, v0, [F

    fill-array-data v0, :array_13

    sput-object v0, LSmoothFacing;->DRAGON_MOUTH_Y:[F

    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x9
        0x8
        0xa
        0x2
        0x6
        0x4
        0x5
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x4
        0x3
        0x2
        0x1
    .end array-data

    :array_2
    .array-data 4
        0x0
        -0x3e800000    # -16.0f
        -0x3e900000    # -15.0f
        -0x3eb00000    # -13.0f
        0x0
    .end array-data

    :array_3
    .array-data 4
        -0x3e700000    # -18.0f
        -0x3e900000    # -15.0f
        -0x3f000000    # -8.0f
        -0x40000000    # -2.0f
        -0x3e700000    # -18.0f
    .end array-data

    :array_4
    .array-data 4
        0x0
        -0x3df80000    # -34.0f
        -0x3dd40000    # -43.0f
        -0x3e280000    # -27.0f
        0x0
    .end array-data

    :array_5
    .array-data 4
        -0x3ea00000    # -14.0f
        -0x3f400000    # -6.0f
        -0x3f800000    # -4.0f
        0x40800000    # 4.0f
        0x40000000    # 2.0f
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x42600000    # 56.0f
        0x42840000    # 66.0f
        0x42600000    # 56.0f
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x42480000    # 50.0f
        0x41d80000    # 27.0f
        0x40e00000    # 7.0f
        -0x3f000000    # -8.0f
        0x42480000    # 50.0f
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x42200000    # 40.0f
        0x42380000    # 46.0f
        0x41d80000    # 27.0f
        0x0
    .end array-data

    :array_9
    .array-data 4
        -0x3e600000    # -20.0f
        0x0
        -0x3f400000    # -6.0f
        -0x3e900000    # -15.0f
        -0x3e600000    # -20.0f
    .end array-data

    :array_a
    .array-data 4
        0x0
        -0x3e800000    # -16.0f
        -0x3dfc0000    # -33.0f
        -0x3e180000    # -29.0f
        0x0
    .end array-data

    :array_b
    .array-data 4
        -0x3df80000    # -34.0f
        -0x3e000000    # -32.0f
        -0x3e700000    # -18.0f
        -0x3e800000    # -16.0f
        -0x3f200000    # -7.0f
    .end array-data

    :array_c
    .array-data 4
        0x0
        0x41500000    # 13.0f
        0x41e00000    # 28.0f
        0x41e00000    # 28.0f
        0x40e00000    # 7.0f
    .end array-data

    :array_d
    .array-data 4
        0x42200000    # 40.0f
        0x421c0000    # 39.0f
        0x41e80000    # 29.0f
        0x41e00000    # 28.0f
        0x42080000    # 34.0f
    .end array-data

    :array_e
    .array-data 4
        0x0
        -0x3e480000    # -23.0f
        -0x3de00000    # -40.0f
        -0x3e300000    # -26.0f
        0x0
    .end array-data

    :array_f
    .array-data 4
        -0x3e480000    # -23.0f
        -0x3e780000    # -17.0f
        -0x3f000000    # -8.0f
        0x40800000    # 4.0f
        0x41500000    # 13.0f
    .end array-data

    :array_10
    .array-data 4
        0x0
        0x42000000    # 32.0f
        0x422c0000    # 43.0f
        0x41f00000    # 30.0f
        0x0
    .end array-data

    :array_11
    .array-data 4
        0x41d00000    # 26.0f
        0x41800000    # 16.0f
        0x0
        -0x3ec00000    # -12.0f
        -0x3e380000    # -25.0f
    .end array-data

    :array_12
    .array-data 4
        0x0
        -0x3e780000    # -17.0f
        -0x3e380000    # -25.0f
        -0x3e680000    # -19.0f
        0x0
    .end array-data

    :array_13
    .array-data 4
        -0x3eb00000    # -13.0f
        -0x3eb00000    # -13.0f
        -0x3fc00000    # -3.0f
        -0x3f400000    # -6.0f
        -0x3ec00000    # -12.0f
    .end array-data
.end method

.method public constructor <init>(I)V
    .locals 1

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, LSmoothFacing;->ordinal(I)I

    move-result p1

    int-to-float p1, p1

    const/high16 v0, 0x42340000    # 45.0f

    mul-float/2addr p1, v0

    iput p1, p0, LSmoothFacing;->target:F

    iput p1, p0, LSmoothFacing;->angle:F

    return-void
.end method

.method private static coilPhase(Laqs;)F
    .locals 1

    .line 79
    iget p0, p0, Laqs;->qinglongTick:I

    int-to-float p0, p0

    const v0, 0x3da0d97c

    mul-float/2addr p0, v0

    return p0
.end method

.method private static coreY(I)F
    .locals 1

    .line 164
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_0

    const/high16 p0, 0x430c0000    # 140.0f

    goto :goto_0

    :cond_0
    const/16 v0, 0x2c

    if-ne p0, v0, :cond_1

    const/high16 p0, 0x43340000    # 180.0f

    goto :goto_0

    :cond_1
    const/16 v0, 0x29

    if-ne p0, v0, :cond_2

    const/high16 p0, 0x43020000    # 130.0f

    goto :goto_0

    :cond_2
    const/16 v0, 0x2a

    if-ne p0, v0, :cond_3

    const/high16 p0, 0x43470000    # 199.0f

    goto :goto_0

    :cond_3
    const/high16 p0, 0x43200000    # 160.0f

    :goto_0
    return p0
.end method

.method private static delta(F)F
    .locals 2

    .line 46
    const/high16 v0, 0x43b40000    # 360.0f

    rem-float/2addr p0, v0

    const/high16 v1, 0x44070000    # 540.0f

    add-float/2addr p0, v1

    rem-float/2addr p0, v0

    const/high16 v0, 0x43340000    # 180.0f

    sub-float/2addr p0, v0

    .line 47
    return p0
.end method

.method public static dragonMuzzleHeight(Laqs;)D
    .locals 4

    .line 99
    const/high16 v0, 0x40000000    # 2.0f

    invoke-static {p0}, LSmoothFacing;->coilPhase(Laqs;)F

    move-result v1

    mul-float/2addr v1, v0

    float-to-double v0, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x402c000000000000L    # 14.0

    mul-double/2addr v0, v2

    const-wide/high16 v2, 0x4052000000000000L    # 72.0

    sub-double/2addr v2, v0

    const/4 v0, 0x0

    invoke-static {p0, v0}, LSmoothFacing;->muzzleOffset(Laqs;Z)F

    move-result p0

    float-to-double v0, p0

    sub-double/2addr v2, v0

    return-wide v2
.end method

.method public static dragonMuzzleX(Laqs;)D
    .locals 4

    .line 96
    invoke-static {p0}, LSmoothFacing;->coilPhase(Laqs;)F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    move-result-wide v0

    const-wide/high16 v2, 0x403f000000000000L    # 31.0

    mul-double/2addr v0, v2

    const/4 v2, 0x1

    invoke-static {p0, v2}, LSmoothFacing;->muzzleOffset(Laqs;Z)F

    move-result p0

    float-to-double v2, p0

    add-double/2addr v0, v2

    return-wide v0
.end method

.method private drawDragon(Lasc;Lcar;IILaqs;)V
    .locals 17

    .line 102
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p5

    iget-object v3, v1, LSmoothFacing;->dragonCoil:Lbyq;

    const/16 v4, 0x8

    const/4 v5, 0x0

    if-nez v3, :cond_0

    .line 103
    iget-object v3, v0, Lasc;->a:[Lbyq;

    aget-object v3, v3, v5

    const-string v6, "\u9752\u9f99\u516b\u5b57\u76d8\u65cb"

    invoke-virtual {v3, v6}, Lbyq;->namedAnimation(Ljava/lang/String;)Lbyq;

    move-result-object v3

    iput-object v3, v1, LSmoothFacing;->dragonCoil:Lbyq;

    .line 104
    new-array v3, v4, [Lbyq;

    iput-object v3, v1, LSmoothFacing;->dragonAimed:[Lbyq;

    .line 105
    move v3, v5

    :goto_0
    if-ge v3, v4, :cond_0

    iget-object v6, v1, LSmoothFacing;->dragonAimed:[Lbyq;

    iget-object v7, v0, Lasc;->a:[Lbyq;

    aget-object v7, v7, v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "\u9752\u9f99\u516b\u5b57\u5410\u73e0"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lbyq;->namedAnimation(Ljava/lang/String;)Lbyq;

    move-result-object v7

    aput-object v7, v6, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 107
    :cond_0
    const-class v3, LSmoothFacing;

    monitor-enter v3

    .line 108
    :try_start_0
    invoke-static {}, LSmoothFacing;->initializeBuffers()V

    .line 109
    sget-object v0, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v5}, Landroid/graphics/Bitmap;->eraseColor(I)V

    sget-object v0, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v5}, Landroid/graphics/Bitmap;->eraseColor(I)V

    sget-object v0, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v5}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 110
    iget v11, v2, Laqs;->qinglongTick:I

    .line 111
    iget v0, v2, Laqs;->qinglongAimWeight:F

    .line 112
    iget v2, v1, LSmoothFacing;->angle:F

    const/high16 v6, 0x42340000    # 45.0f

    div-float/2addr v2, v6

    const/high16 v6, 0x41000000    # 8.0f

    rem-float/2addr v2, v6

    add-float/2addr v2, v6

    rem-float/2addr v2, v6

    .line 113
    float-to-int v12, v2

    add-int/lit8 v6, v12, 0x1

    rem-int/lit8 v4, v6, 0x8

    int-to-float v6, v12

    sub-float/2addr v2, v6

    .line 114
    iget-object v6, v1, LSmoothFacing;->dragonCoil:Lbyq;

    sget-object v7, LSmoothFacing;->graphicsA:Lcar;

    const/16 v9, 0x88

    const/4 v10, 0x0

    const/16 v8, 0x24

    invoke-virtual/range {v6 .. v11}, Lbyq;->drawVisualFrame(Lcar;IIII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 116
    const/16 v13, 0xff

    const/4 v14, 0x0

    :try_start_1
    sget-object v6, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v6, v14}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v6, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    const/high16 v15, 0x3f800000    # 1.0f

    sub-float v7, v15, v0

    const/high16 v16, 0x437f0000    # 255.0f

    mul-float v7, v7, v16

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 117
    sget-object v6, LSmoothFacing;->mixture:Landroid/graphics/Canvas;

    sget-object v7, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    sget-object v8, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    const/4 v9, 0x0

    invoke-virtual {v6, v7, v9, v9, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 118
    sget-object v6, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    sget-object v7, LSmoothFacing;->ADD:Landroid/graphics/PorterDuffXfermode;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 119
    iget-object v6, v1, LSmoothFacing;->dragonAimed:[Lbyq;

    aget-object v6, v6, v12

    sget-object v7, LSmoothFacing;->graphicsB:Lcar;

    move v8, v9

    const/16 v9, 0x88

    const/4 v10, 0x0

    move v12, v8

    const/16 v8, 0x24

    invoke-virtual/range {v6 .. v11}, Lbyq;->drawVisualFrame(Lcar;IIII)V

    .line 120
    sget-object v6, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    mul-float v0, v0, v16

    sub-float/2addr v15, v2

    mul-float/2addr v15, v0

    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 121
    sget-object v6, LSmoothFacing;->mixture:Landroid/graphics/Canvas;

    sget-object v7, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    sget-object v8, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v6, v7, v12, v12, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 122
    sget-object v6, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    invoke-virtual {v6, v5}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 123
    iget-object v5, v1, LSmoothFacing;->dragonAimed:[Lbyq;

    aget-object v6, v5, v4

    sget-object v7, LSmoothFacing;->graphicsB:Lcar;

    const/16 v9, 0x88

    const/4 v10, 0x0

    const/16 v8, 0x24

    invoke-virtual/range {v6 .. v11}, Lbyq;->drawVisualFrame(Lcar;IIII)V

    .line 124
    sget-object v4, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    mul-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 125
    sget-object v0, LSmoothFacing;->mixture:Landroid/graphics/Canvas;

    sget-object v2, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    sget-object v4, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v12, v12, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 126
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v14}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v13}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 127
    move-object/from16 v0, p2

    iget-object v0, v0, Lcar;->d:Landroid/graphics/Canvas;

    sget-object v2, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    add-int/lit8 v4, p3, -0x60

    int-to-float v4, v4

    move/from16 v5, p4

    add-int/lit16 v5, v5, -0xdc

    int-to-float v5, v5

    sget-object v6, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v2, v4, v5, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 128
    :try_start_2
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v14}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v13}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 129
    monitor-exit v3

    .line 130
    return-void

    .line 128
    :catchall_0
    move-exception v0

    sget-object v2, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v2, v14}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v2, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v2, v13}, Landroid/graphics/Paint;->setAlpha(I)V

    throw v0

    .line 129
    :catchall_1
    move-exception v0

    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0
.end method

.method private static drawPose(Lasc;Lcar;IIILbyq;)V
    .locals 2

    .line 132
    iget-object p0, p0, Lasc;->a:[Lbyq;

    sget-object v0, LSmoothFacing;->VIEWS:[I

    aget v0, v0, p4

    aget-object p0, p0, v0

    .line 133
    invoke-virtual {p0, p5}, Lbyq;->copyPlaybackPhaseFrom(Lbyq;)V

    .line 134
    const/4 p5, 0x4

    const/4 v0, 0x0

    if-lez p4, :cond_0

    if-ge p4, p5, :cond_0

    const/4 p4, 0x1

    goto :goto_0

    :cond_0
    move p4, v0

    .line 135
    :goto_0
    if-eqz p4, :cond_1

    const/16 v1, 0x3c

    goto :goto_1

    :cond_1
    const/16 v1, -0x3c

    :goto_1
    add-int/2addr p2, v1

    add-int/lit8 p3, p3, -0x54

    if-eqz p4, :cond_2

    goto :goto_2

    :cond_2
    move p5, v0

    :goto_2
    invoke-virtual {p0, p1, p2, p3, p5}, Lbyq;->a(Lcar;III)V

    .line 136
    return-void
.end method

.method private static headOffset([FFZ)F
    .locals 4

    .line 81
    const/high16 v0, 0x41000000    # 8.0f

    rem-float/2addr p1, v0

    add-float/2addr p1, v0

    rem-float/2addr p1, v0

    .line 82
    float-to-int v0, p1

    add-int/lit8 v1, v0, 0x1

    rem-int/lit8 v1, v1, 0x8

    int-to-float v2, v0

    sub-float/2addr p1, v2

    .line 83
    sget-object v2, LSmoothFacing;->VIEWS:[I

    aget v2, v2, v0

    aget v2, p0, v2

    sget-object v3, LSmoothFacing;->VIEWS:[I

    aget v3, v3, v1

    aget p0, p0, v3

    .line 84
    if-eqz p2, :cond_1

    const/4 p2, 0x4

    if-lez v0, :cond_0

    if-ge v0, p2, :cond_0

    neg-float v2, v2

    :cond_0
    if-lez v1, :cond_1

    if-ge v1, p2, :cond_1

    neg-float p0, p0

    .line 85
    :cond_1
    sub-float/2addr p0, v2

    mul-float/2addr p0, p1

    add-float/2addr v2, p0

    return v2
.end method

.method private static headX(II)F
    .locals 2

    .line 145
    const/16 v0, 0x28

    const/high16 v1, 0x42c00000    # 96.0f

    if-ne p0, v0, :cond_0

    return v1

    .line 146
    :cond_0
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_1

    sget-object p0, LSmoothFacing;->DRAGON_X:[F

    goto :goto_0

    :cond_1
    const/16 v0, 0x2c

    if-ne p0, v0, :cond_2

    sget-object p0, LSmoothFacing;->TIGER_X:[F

    goto :goto_0

    :cond_2
    const/16 v0, 0x29

    if-ne p0, v0, :cond_3

    sget-object p0, LSmoothFacing;->BIRD_X:[F

    goto :goto_0

    :cond_3
    sget-object p0, LSmoothFacing;->BEAST_X:[F

    .line 147
    :goto_0
    sget-object v0, LSmoothFacing;->VIEWS:[I

    aget v0, v0, p1

    aget p0, p0, v0

    if-lez p1, :cond_4

    const/4 v0, 0x4

    if-ge p1, v0, :cond_4

    const/4 p1, -0x1

    goto :goto_1

    :cond_4
    const/4 p1, 0x1

    :goto_1
    int-to-float p1, p1

    mul-float/2addr p0, p1

    add-float/2addr v1, p0

    return v1
.end method

.method private static headY(II)F
    .locals 2

    .line 150
    const/16 v0, 0x28

    if-ne p0, v0, :cond_0

    const/high16 p0, 0x43090000    # 137.0f

    return p0

    .line 151
    :cond_0
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_1

    sget-object v0, LSmoothFacing;->DRAGON_Y:[F

    goto :goto_0

    :cond_1
    const/16 v0, 0x2c

    if-ne p0, v0, :cond_2

    sget-object v0, LSmoothFacing;->TIGER_Y:[F

    goto :goto_0

    :cond_2
    const/16 v0, 0x29

    if-ne p0, v0, :cond_3

    sget-object v0, LSmoothFacing;->BIRD_Y:[F

    goto :goto_0

    :cond_3
    sget-object v0, LSmoothFacing;->BEAST_Y:[F

    .line 152
    :goto_0
    invoke-static {p0}, LSmoothFacing;->coreY(I)F

    move-result p0

    sget-object v1, LSmoothFacing;->VIEWS:[I

    aget p1, v1, p1

    aget p1, v0, p1

    add-float/2addr p0, p1

    return p0
.end method

.method private static influence(FFFFFF)F
    .locals 2

    .line 166
    sub-float/2addr p4, p2

    sub-float/2addr p5, p3

    mul-float v0, p4, p4

    mul-float v1, p5, p5

    add-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .line 167
    sub-float/2addr p0, p2

    mul-float p2, p0, p4

    sub-float/2addr p1, p3

    mul-float p3, p1, p5

    add-float/2addr p2, p3

    div-float/2addr p2, v0

    invoke-static {v1, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/4 p3, 0x0

    invoke-static {p3, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    .line 168
    mul-float/2addr p0, p5

    mul-float/2addr p1, p4

    sub-float/2addr p0, p1

    .line 169
    neg-float p1, p0

    mul-float/2addr p1, p0

    const/high16 p0, 0x41d00000    # 26.0f

    mul-float/2addr v0, p0

    mul-float/2addr v0, p0

    div-float/2addr p1, v0

    float-to-double p0, p1

    invoke-static {p0, p1}, Ljava/lang/Math;->exp(D)D

    move-result-wide p0

    double-to-float p0, p0

    mul-float/2addr p2, p0

    return p2
.end method

.method private static initializeBuffers()V
    .locals 3

    .line 138
    sget-object v0, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    return-void

    .line 139
    :cond_0
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v1, 0xc0

    const/16 v2, 0x100

    invoke-static {v1, v2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    sput-object v0, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    .line 140
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    sput-object v0, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    .line 141
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    sput-object v0, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    .line 142
    new-instance v0, Lcar;

    sget-object v1, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    invoke-direct {v0, v1}, Lcar;-><init>(Landroid/graphics/Bitmap;)V

    sput-object v0, LSmoothFacing;->graphicsA:Lcar;

    new-instance v0, Lcar;

    sget-object v1, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    invoke-direct {v0, v1}, Lcar;-><init>(Landroid/graphics/Bitmap;)V

    sput-object v0, LSmoothFacing;->graphicsB:Lcar;

    new-instance v0, Landroid/graphics/Canvas;

    sget-object v1, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    invoke-direct {v0, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    sput-object v0, LSmoothFacing;->mixture:Landroid/graphics/Canvas;

    .line 143
    return-void
.end method

.method public static labelBaseY(Laqs;II)I
    .locals 1

    .line 38
    iget-boolean v0, p0, Laqs;->qinglongForm:Z

    if-eqz v0, :cond_0

    const/16 p0, 0x91

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Laqs;->baihuForm:Z

    if-eqz v0, :cond_1

    const/16 p0, 0x64

    goto :goto_0

    :cond_1
    iget-boolean v0, p0, Laqs;->zhuqueForm:Z

    if-eqz v0, :cond_2

    const/16 p0, 0x92

    goto :goto_0

    :cond_2
    iget-boolean v0, p0, Laqs;->taotieForm:Z

    if-eqz v0, :cond_3

    const/16 p0, 0x50

    goto :goto_0

    :cond_3
    iget-boolean p0, p0, Laqs;->guanghanForm:Z

    if-eqz p0, :cond_4

    const/16 p0, 0x7a

    goto :goto_0

    :cond_4
    const/4 p0, 0x0

    .line 39
    :goto_0
    if-nez p0, :cond_5

    goto :goto_1

    :cond_5
    sub-int/2addr p1, p0

    add-int/lit8 p1, p1, -0x6

    sub-int/2addr p1, p2

    :goto_1
    return p1
.end method

.method private static morph(Landroid/graphics/Bitmap;IIFFFFF)V
    .locals 20

    .line 173
    invoke-static/range {p1 .. p1}, LSmoothFacing;->coreY(I)F

    move-result v3

    .line 174
    invoke-static/range {p1 .. p2}, LSmoothFacing;->headX(II)F

    move-result v4

    invoke-static/range {p1 .. p2}, LSmoothFacing;->headY(II)F

    move-result v5

    .line 175
    sub-float v6, p3, v4

    sub-float v7, p4, v5

    .line 176
    invoke-static/range {p1 .. p2}, LSmoothFacing;->tailX(II)F

    move-result v8

    invoke-static/range {p1 .. p2}, LSmoothFacing;->tailY(II)F

    move-result v9

    .line 177
    nop

    .line 178
    const/4 v0, 0x0

    const/4 v11, 0x0

    :goto_0
    const/16 v12, 0x10

    if-gt v11, v12, :cond_1

    move v13, v0

    const/4 v14, 0x0

    :goto_1
    if-gt v14, v12, :cond_0

    .line 179
    mul-int/lit16 v0, v14, 0xc0

    int-to-float v0, v0

    const/high16 v1, 0x41800000    # 16.0f

    div-float/2addr v0, v1

    mul-int/lit16 v2, v11, 0x100

    int-to-float v2, v2

    div-float v1, v2, v1

    .line 180
    const/high16 v2, 0x42c00000    # 96.0f

    invoke-static/range {v0 .. v5}, LSmoothFacing;->influence(FFFFFF)F

    move-result v15

    .line 181
    move/from16 v16, v4

    move/from16 v17, v5

    move v4, v8

    move v5, v9

    invoke-static/range {v0 .. v5}, LSmoothFacing;->influence(FFFFFF)F

    move-result v2

    .line 182
    add-float v8, v15, v2

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-static {v9, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    .line 184
    const/high16 v18, 0x43570000    # 215.0f

    sub-float v18, v18, v1

    const/high16 v19, 0x41700000    # 15.0f

    div-float v10, v18, v19

    invoke-static {v9, v10}, Ljava/lang/Math;->min(FF)F

    move-result v9

    const/4 v10, 0x0

    invoke-static {v10, v9}, Ljava/lang/Math;->max(FF)F

    move-result v9

    div-float/2addr v9, v8

    .line 185
    sget-object v8, LSmoothFacing;->mesh:[F

    add-int/lit8 v10, v13, 0x1

    mul-float v18, v6, v15

    sub-float v19, p5, v4

    mul-float v19, v19, v2

    add-float v18, v18, v19

    mul-float v18, v18, v9

    add-float v0, v0, v18

    aput v0, v8, v13

    .line 186
    sget-object v0, LSmoothFacing;->mesh:[F

    add-int/lit8 v13, v10, 0x1

    mul-float/2addr v15, v7

    sub-float v8, p6, v5

    mul-float/2addr v8, v2

    add-float/2addr v15, v8

    mul-float/2addr v15, v9

    add-float/2addr v1, v15

    aput v1, v0, v10

    .line 178
    add-int/lit8 v14, v14, 0x1

    move v8, v4

    move v9, v5

    move/from16 v4, v16

    move/from16 v5, v17

    goto :goto_1

    :cond_0
    move/from16 v16, v4

    move/from16 v17, v5

    move v4, v8

    move v5, v9

    add-int/lit8 v11, v11, 0x1

    move v0, v13

    move/from16 v4, v16

    move/from16 v5, v17

    goto :goto_0

    .line 188
    :cond_1
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    const/high16 v1, 0x437f0000    # 255.0f

    mul-float v1, v1, p7

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 189
    sget-object v2, LSmoothFacing;->mixture:Landroid/graphics/Canvas;

    sget-object v6, LSmoothFacing;->mesh:[F

    const/4 v9, 0x0

    sget-object v10, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    const/16 v4, 0x10

    const/16 v5, 0x10

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v3, p0

    invoke-virtual/range {v2 .. v10}, Landroid/graphics/Canvas;->drawBitmapMesh(Landroid/graphics/Bitmap;II[FI[IILandroid/graphics/Paint;)V

    .line 190
    return-void
.end method

.method private static muzzleOffset(Laqs;Z)F
    .locals 7

    .line 88
    invoke-static {p0}, LSmoothFacing;->coilPhase(Laqs;)F

    move-result v0

    .line 89
    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    const-wide/high16 v3, 0x403f000000000000L    # 31.0

    mul-double/2addr v1, v3

    const/high16 v3, 0x40000000    # 2.0f

    mul-float/2addr v0, v3

    float-to-double v3, v0

    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    move-result-wide v3

    const-wide/high16 v5, -0x3fc4000000000000L    # -28.0

    mul-double/2addr v3, v5

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v0

    const-wide v2, 0x3fe921fb54442d18L    # 0.7853981633974483

    div-double/2addr v0, v2

    double-to-float v0, v0

    .line 90
    iget-object v1, p0, Laqs;->smoothFacing:LSmoothFacing;

    if-nez v1, :cond_0

    invoke-virtual {p0}, Laqs;->r()I

    move-result v1

    invoke-static {v1}, LSmoothFacing;->ordinal(I)I

    move-result v1

    int-to-float v1, v1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Laqs;->smoothFacing:LSmoothFacing;

    invoke-virtual {v1}, LSmoothFacing;->angle()F

    move-result v1

    const/high16 v2, 0x42340000    # 45.0f

    div-float/2addr v1, v2

    .line 91
    :goto_0
    if-eqz p1, :cond_1

    sget-object v2, LSmoothFacing;->DRAGON_MOUTH_X:[F

    goto :goto_1

    :cond_1
    sget-object v2, LSmoothFacing;->DRAGON_MOUTH_Y:[F

    .line 92
    :goto_1
    invoke-static {v2, v0, p1}, LSmoothFacing;->headOffset([FFZ)F

    move-result v0

    invoke-static {v2, v1, p1}, LSmoothFacing;->headOffset([FFZ)F

    move-result p1

    .line 93
    sub-float/2addr p1, v0

    iget p0, p0, Laqs;->qinglongAimWeight:F

    mul-float/2addr p1, p0

    add-float/2addr v0, p1

    return v0
.end method

.method private static ordinal(I)I
    .locals 3

    .line 42
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    sget-object v2, LSmoothFacing;->DIRECTIONS:[I

    array-length v2, v2

    if-ge v1, v2, :cond_1

    sget-object v2, LSmoothFacing;->DIRECTIONS:[I

    aget v2, v2, v1

    if-ne v2, p0, :cond_0

    return v1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 43
    :cond_1
    return v0
.end method

.method private static tailX(II)F
    .locals 2

    .line 155
    const/16 v0, 0x28

    const/high16 v1, 0x42c00000    # 96.0f

    if-ne p0, v0, :cond_0

    return v1

    .line 156
    :cond_0
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_1

    sget-object p0, LSmoothFacing;->DRAGON_TAIL_X:[F

    goto :goto_0

    :cond_1
    const/16 v0, 0x2c

    if-ne p0, v0, :cond_2

    sget-object p0, LSmoothFacing;->TIGER_TAIL_X:[F

    goto :goto_0

    :cond_2
    const/16 v0, 0x29

    if-ne p0, v0, :cond_3

    sget-object p0, LSmoothFacing;->BIRD_TAIL_X:[F

    goto :goto_0

    :cond_3
    sget-object p0, LSmoothFacing;->BEAST_TAIL_X:[F

    .line 157
    :goto_0
    sget-object v0, LSmoothFacing;->VIEWS:[I

    aget v0, v0, p1

    aget p0, p0, v0

    if-lez p1, :cond_4

    const/4 v0, 0x4

    if-ge p1, v0, :cond_4

    const/4 p1, -0x1

    goto :goto_1

    :cond_4
    const/4 p1, 0x1

    :goto_1
    int-to-float p1, p1

    mul-float/2addr p0, p1

    add-float/2addr v1, p0

    return v1
.end method

.method private static tailY(II)F
    .locals 2

    .line 160
    const/16 v0, 0x28

    if-ne p0, v0, :cond_0

    const/high16 p0, 0x43390000    # 185.0f

    return p0

    .line 161
    :cond_0
    const/16 v0, 0x2b

    if-ne p0, v0, :cond_1

    sget-object v0, LSmoothFacing;->DRAGON_TAIL_Y:[F

    goto :goto_0

    :cond_1
    const/16 v0, 0x2c

    if-ne p0, v0, :cond_2

    sget-object v0, LSmoothFacing;->TIGER_TAIL_Y:[F

    goto :goto_0

    :cond_2
    const/16 v0, 0x29

    if-ne p0, v0, :cond_3

    sget-object v0, LSmoothFacing;->BIRD_TAIL_Y:[F

    goto :goto_0

    :cond_3
    sget-object v0, LSmoothFacing;->BEAST_TAIL_Y:[F

    .line 162
    :goto_0
    invoke-static {p0}, LSmoothFacing;->coreY(I)F

    move-result p0

    sget-object v1, LSmoothFacing;->VIEWS:[I

    aget p1, v1, p1

    aget p1, v0, p1

    add-float/2addr p0, p1

    return p0
.end method

.method public static tickDragon(Laqs;Lasc;)V
    .locals 2

    .line 74
    iget-boolean v0, p0, Laqs;->qinglongForm:Z

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Laqs;->n()I

    move-result v0

    if-gtz v0, :cond_0

    goto :goto_1

    .line 75
    :cond_0
    iget v0, p0, Laqs;->qinglongTick:I

    add-int/lit8 v0, v0, 0x1

    rem-int/lit8 v0, v0, 0x50

    iput v0, p0, Laqs;->qinglongTick:I

    .line 76
    instance-of p1, p1, Larx;

    if-eqz p1, :cond_1

    const/high16 p1, 0x3f800000    # 1.0f

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    .line 77
    :goto_0
    iget v0, p0, Laqs;->qinglongAimWeight:F

    iget v1, p0, Laqs;->qinglongAimWeight:F

    sub-float/2addr p1, v1

    const v1, 0x3e4ccccd    # 0.2f

    invoke-static {v1, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const v1, -0x41b33333    # -0.2f

    invoke-static {v1, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    add-float/2addr v0, p1

    iput v0, p0, Laqs;->qinglongAimWeight:F

    .line 78
    return-void

    .line 74
    :cond_2
    :goto_1
    return-void
.end method


# virtual methods
.method public advance()V
    .locals 8

    .line 58
    iget v0, p0, LSmoothFacing;->target:F

    iget v1, p0, LSmoothFacing;->angle:F

    sub-float/2addr v0, v1

    .line 59
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const v2, 0x3d4ccccd    # 0.05f

    cmpg-float v1, v1, v2

    const/4 v2, 0x0

    if-gez v1, :cond_0

    iget v1, p0, LSmoothFacing;->velocity:F

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v3, 0x3f000000    # 0.5f

    cmpg-float v1, v1, v3

    if-gez v1, :cond_0

    iget v0, p0, LSmoothFacing;->target:F

    iput v0, p0, LSmoothFacing;->angle:F

    iput v2, p0, LSmoothFacing;->velocity:F

    return-void

    .line 60
    :cond_0
    nop

    .line 61
    iget v1, p0, LSmoothFacing;->angle:F

    iget v3, p0, LSmoothFacing;->target:F

    sub-float/2addr v1, v3

    .line 62
    iget v3, p0, LSmoothFacing;->velocity:F

    const/high16 v4, 0x41900000    # 18.0f

    mul-float v5, v1, v4

    add-float/2addr v3, v5

    const v5, 0x3d23d70a    # 0.04f

    mul-float/2addr v3, v5

    .line 63
    const v6, -0x40c7ae15    # -0.71999997f

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->exp(D)D

    move-result-wide v6

    double-to-float v6, v6

    .line 64
    iget v7, p0, LSmoothFacing;->target:F

    add-float/2addr v1, v3

    mul-float/2addr v1, v6

    add-float/2addr v7, v1

    .line 65
    iget v1, p0, LSmoothFacing;->velocity:F

    mul-float/2addr v3, v4

    sub-float/2addr v1, v3

    mul-float/2addr v1, v6

    iput v1, p0, LSmoothFacing;->velocity:F

    .line 66
    iget v1, p0, LSmoothFacing;->angle:F

    sub-float v1, v7, v1

    invoke-static {v4, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v3, -0x3e700000    # -18.0f

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 67
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v3

    iget v4, p0, LSmoothFacing;->angle:F

    sub-float/2addr v7, v4

    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpg-float v3, v3, v4

    if-gez v3, :cond_1

    div-float v3, v1, v5

    iput v3, p0, LSmoothFacing;->velocity:F

    .line 68
    :cond_1
    mul-float v3, v1, v0

    cmpl-float v3, v3, v2

    if-lez v3, :cond_2

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v3

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v3, v3, v4

    if-lez v3, :cond_2

    iput v2, p0, LSmoothFacing;->velocity:F

    goto :goto_0

    .line 69
    :cond_2
    move v0, v1

    :goto_0
    iget v1, p0, LSmoothFacing;->angle:F

    add-float/2addr v1, v0

    iput v1, p0, LSmoothFacing;->angle:F

    .line 70
    iget v0, p0, LSmoothFacing;->angle:F

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/high16 v1, 0x44340000    # 720.0f

    cmpl-float v0, v0, v1

    if-lez v0, :cond_3

    iget v0, p0, LSmoothFacing;->angle:F

    const/high16 v1, 0x43b40000    # 360.0f

    div-float/2addr v0, v1

    float-to-double v2, v0

    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-float v0, v2

    mul-float/2addr v0, v1

    iget v1, p0, LSmoothFacing;->angle:F

    sub-float/2addr v1, v0

    iput v1, p0, LSmoothFacing;->angle:F

    iget v1, p0, LSmoothFacing;->target:F

    sub-float/2addr v1, v0

    iput v1, p0, LSmoothFacing;->target:F

    .line 71
    :cond_3
    return-void
.end method

.method public angle()F
    .locals 1

    .line 54
    iget v0, p0, LSmoothFacing;->angle:F

    return v0
.end method

.method public declared-synchronized draw(Lasc;Lcar;IILaqs;)V
    .locals 20

    move-object/from16 v1, p0

    move-object/from16 v0, p5

    monitor-enter p0

    .line 192
    :try_start_0
    iget-boolean v2, v0, Laqs;->qinglongForm:Z

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Laqs;->n()I

    move-result v2

    if-lez v2, :cond_0

    invoke-direct/range {p0 .. p5}, LSmoothFacing;->drawDragon(Lasc;Lcar;IILaqs;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    monitor-exit p0

    return-void

    .line 193
    :cond_0
    :try_start_1
    invoke-virtual/range {p1 .. p1}, Lasc;->e()Lbyq;

    move-result-object v7

    .line 194
    iget v2, v1, LSmoothFacing;->angle:F

    const/high16 v3, 0x43b40000    # 360.0f

    rem-float/2addr v2, v3

    add-float/2addr v2, v3

    rem-float/2addr v2, v3

    const/high16 v3, 0x42340000    # 45.0f

    div-float/2addr v2, v3

    .line 195
    float-to-double v3, v2

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    rem-int/lit8 v10, v5, 0x8

    add-int/lit8 v5, v10, 0x1

    rem-int/lit8 v13, v5, 0x8

    .line 196
    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-float v3, v3

    sub-float v18, v2, v3

    .line 197
    invoke-virtual {v0}, Laqs;->n()I

    move-result v2

    if-lez v2, :cond_6

    const v2, 0x3a83126f    # 0.001f

    cmpg-float v2, v18, v2

    if-ltz v2, :cond_6

    const v2, 0x3f7fbe77    # 0.999f

    cmpl-float v2, v18, v2

    if-lez v2, :cond_1

    move-object/from16 v4, p2

    move/from16 v6, p4

    goto/16 :goto_2

    .line 201
    :cond_1
    const-class v19, LSmoothFacing;

    monitor-enter v19
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 202
    :try_start_2
    invoke-static {}, LSmoothFacing;->initializeBuffers()V

    .line 203
    sget-object v2, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Bitmap;->eraseColor(I)V

    sget-object v2, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    invoke-virtual {v2, v3}, Landroid/graphics/Bitmap;->eraseColor(I)V

    sget-object v2, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    invoke-virtual {v2, v3}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 204
    sget-object v3, LSmoothFacing;->graphicsA:Lcar;

    const/16 v4, 0x60

    const/16 v5, 0xdc

    move-object/from16 v2, p1

    move v6, v10

    invoke-static/range {v2 .. v7}, LSmoothFacing;->drawPose(Lasc;Lcar;IIILbyq;)V

    .line 205
    sget-object v3, LSmoothFacing;->graphicsB:Lcar;

    const/16 v4, 0x60

    const/16 v5, 0xdc

    move-object/from16 v2, p1

    move v6, v13

    invoke-static/range {v2 .. v7}, LSmoothFacing;->drawPose(Lasc;Lcar;IIILbyq;)V

    .line 206
    iget-boolean v2, v0, Laqs;->qinglongForm:Z

    if-eqz v2, :cond_2

    const/16 v0, 0x2b

    :goto_0
    move v12, v0

    goto :goto_1

    :cond_2
    iget-boolean v2, v0, Laqs;->baihuForm:Z

    if-eqz v2, :cond_3

    const/16 v0, 0x2c

    goto :goto_0

    :cond_3
    iget-boolean v2, v0, Laqs;->zhuqueForm:Z

    if-eqz v2, :cond_4

    const/16 v0, 0x29

    goto :goto_0

    :cond_4
    iget-boolean v0, v0, Laqs;->taotieForm:Z

    if-eqz v0, :cond_5

    const/16 v0, 0x2a

    goto :goto_0

    :cond_5
    const/16 v0, 0x28

    goto :goto_0

    .line 207
    :goto_1
    invoke-static {v12, v10}, LSmoothFacing;->headX(II)F

    move-result v0

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float v15, v2, v18

    mul-float/2addr v0, v15

    invoke-static {v12, v6}, LSmoothFacing;->headX(II)F

    move-result v2

    mul-float v2, v2, v18

    add-float v11, v0, v2

    .line 208
    invoke-static {v12, v10}, LSmoothFacing;->headY(II)F

    move-result v0

    mul-float/2addr v0, v15

    invoke-static {v12, v6}, LSmoothFacing;->headY(II)F

    move-result v2

    mul-float v2, v2, v18

    add-float/2addr v0, v2

    .line 209
    invoke-static {v12, v10}, LSmoothFacing;->tailX(II)F

    move-result v2

    mul-float/2addr v2, v15

    invoke-static {v12, v6}, LSmoothFacing;->tailX(II)F

    move-result v3

    mul-float v3, v3, v18

    add-float v13, v2, v3

    .line 210
    invoke-static {v12, v10}, LSmoothFacing;->tailY(II)F

    move-result v2

    mul-float/2addr v2, v15

    invoke-static {v12, v6}, LSmoothFacing;->tailY(II)F

    move-result v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    mul-float v3, v3, v18

    add-float v14, v2, v3

    .line 212
    const/16 v2, 0xff

    const/4 v3, 0x0

    :try_start_3
    sget-object v4, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 213
    sget-object v8, LSmoothFacing;->poseA:Landroid/graphics/Bitmap;

    move v9, v12

    move v12, v0

    invoke-static/range {v8 .. v15}, LSmoothFacing;->morph(Landroid/graphics/Bitmap;IIFFFFF)V

    move v15, v12

    move v12, v9

    .line 214
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    sget-object v4, LSmoothFacing;->ADD:Landroid/graphics/PorterDuffXfermode;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 215
    move v0, v11

    sget-object v11, LSmoothFacing;->poseB:Landroid/graphics/Bitmap;

    move/from16 v16, v13

    move/from16 v17, v14

    move v14, v0

    move v13, v6

    invoke-static/range {v11 .. v18}, LSmoothFacing;->morph(Landroid/graphics/Bitmap;IIFFFFF)V

    .line 216
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 217
    move-object/from16 v4, p2

    iget-object v0, v4, Lcar;->d:Landroid/graphics/Canvas;

    sget-object v4, LSmoothFacing;->mixed:Landroid/graphics/Bitmap;

    add-int/lit8 v5, p3, -0x60

    int-to-float v5, v5

    move/from16 v6, p4

    add-int/lit16 v6, v6, -0xdc

    int-to-float v6, v6

    sget-object v7, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v4, v5, v6, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 218
    :try_start_4
    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v0, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 219
    monitor-exit v19
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 220
    monitor-exit p0

    return-void

    .line 218
    :catchall_0
    move-exception v0

    :try_start_5
    sget-object v4, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    sget-object v3, LSmoothFacing;->PAINT:Landroid/graphics/Paint;

    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    throw v0

    .line 219
    :catchall_1
    move-exception v0

    monitor-exit v19
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    throw v0

    .line 197
    :cond_6
    move-object/from16 v4, p2

    move/from16 v6, p4

    .line 198
    :goto_2
    invoke-virtual {v0}, Laqs;->n()I

    move-result v2

    if-gtz v2, :cond_7

    invoke-virtual {v0}, Laqs;->r()I

    move-result v0

    invoke-static {v0}, LSmoothFacing;->ordinal(I)I

    move-result v10

    goto :goto_3

    :cond_7
    const/high16 v0, 0x3f000000    # 0.5f

    cmpg-float v0, v18, v0

    if-gez v0, :cond_8

    :goto_3
    goto :goto_4

    :cond_8
    move v10, v13

    :goto_4
    move-object/from16 v2, p1

    move-object v3, v4

    move v5, v6

    move v6, v10

    move/from16 v4, p3

    invoke-static/range {v2 .. v7}, LSmoothFacing;->drawPose(Lasc;Lcar;IIILbyq;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 199
    monitor-exit p0

    return-void

    .line 191
    :catchall_2
    move-exception v0

    :try_start_7
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    throw v0
.end method

.method public turnTo(I)V
    .locals 3

    .line 50
    invoke-static {p1}, LSmoothFacing;->ordinal(I)I

    move-result p1

    int-to-float p1, p1

    const/high16 v0, 0x42340000    # 45.0f

    mul-float/2addr p1, v0

    iget v0, p0, LSmoothFacing;->angle:F

    sub-float/2addr p1, v0

    invoke-static {p1}, LSmoothFacing;->delta(F)F

    move-result p1

    .line 51
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/high16 v1, 0x43340000    # 180.0f

    sub-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const v2, 0x3a83126f    # 0.001f

    cmpg-float v0, v0, v2

    if-gez v0, :cond_0

    iget v0, p0, LSmoothFacing;->velocity:F

    const/4 v2, 0x0

    cmpl-float v0, v0, v2

    if-lez v0, :cond_0

    move p1, v1

    .line 52
    :cond_0
    iget v0, p0, LSmoothFacing;->angle:F

    add-float/2addr v0, p1

    iput v0, p0, LSmoothFacing;->target:F

    .line 53
    return-void
.end method
