.class public Laeb;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:Z

.field private c:[Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Laeb;->a:I

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Laeb;->b:Z

    return-void
.end method

.method public a([Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Laeb;->c:[Ljava/lang/String;

    return-void
.end method

.method public a()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laeb;->c:[Ljava/lang/String;

    return-object v0
.end method
