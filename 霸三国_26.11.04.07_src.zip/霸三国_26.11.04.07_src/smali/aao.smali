.class public Laao;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lald;Ljava/io/DataInputStream;)V
    .locals 4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lald;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lald;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lald;->b(Ljava/lang/String;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lald;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Laks;

    invoke-direct {v0}, Laks;-><init>()V

    invoke-static {v0, p1}, Laad;->a(Laks;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lald;->a(Laks;)V

    :cond_2
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Lalw;

    invoke-direct {v0}, Lalw;-><init>()V

    invoke-static {v0, p1}, Labg;->a(Lalw;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lald;->a(Lalw;)V

    :cond_3
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lald;->b(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    invoke-virtual {p0, v0}, Lald;->a(Z)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v2, v0, [Lalo;

    move v0, v1

    :goto_0
    array-length v3, v2

    if-ge v0, v3, :cond_5

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v3

    if-eqz v3, :cond_4

    new-instance v3, Lalo;

    invoke-direct {v3}, Lalo;-><init>()V

    aput-object v3, v2, v0

    aget-object v3, v2, v0

    invoke-static {v3, p1}, Laay;->a(Lalo;Ljava/io/DataInputStream;)V

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p0, v2}, Lald;->a([Lalo;)V

    :cond_6
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v0, v0, [Lalo;

    :goto_1
    array-length v2, v0

    if-ge v1, v2, :cond_8

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_7

    new-instance v2, Lalo;

    invoke-direct {v2}, Lalo;-><init>()V

    aput-object v2, v0, v1

    aget-object v2, v0, v1

    invoke-static {v2, p1}, Laay;->a(Lalo;Ljava/io/DataInputStream;)V

    :cond_7
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_8
    invoke-virtual {p0, v0}, Lald;->b([Lalo;)V

    :cond_9
    return-void
.end method
