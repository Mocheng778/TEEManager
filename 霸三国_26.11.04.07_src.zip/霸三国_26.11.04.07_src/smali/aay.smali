.class public Laay;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lalo;Ljava/io/DataInputStream;)V
    .locals 3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Lalo;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lalw;

    invoke-direct {v0}, Lalw;-><init>()V

    invoke-static {v0, p1}, Labg;->a(Lalw;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Lalo;->a(Lalw;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lalo;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v1, v0, [Lamz;

    const/4 v0, 0x0

    :goto_0
    array-length v2, v1

    if-ge v0, v2, :cond_2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_1

    new-instance v2, Lamz;

    invoke-direct {v2}, Lamz;-><init>()V

    aput-object v2, v1, v0

    aget-object v2, v1, v0

    invoke-static {v2, p1}, Lacj;->a(Lamz;Ljava/io/DataInputStream;)V

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {p0, v1}, Lalo;->a([Lamz;)V

    :cond_3
    return-void
.end method
