.class public Lalh;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lakt;

.field private b:[Laka;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Laka;)V
    .locals 0

    iput-object p1, p0, Lalh;->b:[Laka;

    return-void
.end method

.method public a([Lakt;)V
    .locals 0

    iput-object p1, p0, Lalh;->a:[Lakt;

    return-void
.end method

.method public a()[Lakt;
    .locals 1

    iget-object v0, p0, Lalh;->a:[Lakt;

    return-object v0
.end method

.method public b()[Laka;
    .locals 1

    iget-object v0, p0, Lalh;->b:[Laka;

    return-object v0
.end method
