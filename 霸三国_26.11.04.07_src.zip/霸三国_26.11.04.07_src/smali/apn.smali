.class public interface abstract Lapn;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lajo;)V
.end method
