.class public Laqw;
.super Laqu;


# instance fields
.field private a:I

.field private b:I

.field private c:Laqr;

.field private d:Ljava/lang/String;

.field private e:I


# direct methods
.method public constructor <init>(Laqg;Ljava/lang/String;)V
    .locals 4

    invoke-direct {p0}, Laqu;-><init>()V

    const-string v0, "_"

    invoke-static {p2, v0}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v0, 0x0

    :goto_0
    array-length v2, v1

    if-ge v0, v2, :cond_1

    packed-switch v0, :pswitch_data_0

    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :pswitch_0
    aget-object v2, v1, v0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Laqw;->a:I

    goto :goto_1

    :pswitch_1
    aget-object v2, v1, v0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Laqw;->b:I

    goto :goto_1

    :pswitch_2
    const-string v2, "1"

    aget-object v3, v1, v0

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget v2, p0, Laqw;->a:I

    invoke-virtual {p1, v2}, Laqg;->b(I)Laqs;

    move-result-object v2

    invoke-virtual {v2}, Laqs;->h()Laqr;

    move-result-object v2

    iput-object v2, p0, Laqw;->c:Laqr;

    goto :goto_1

    :cond_0
    iget v2, p0, Laqw;->a:I

    invoke-virtual {p1, v2}, Laqg;->b(I)Laqs;

    move-result-object v2

    invoke-virtual {v2}, Laqs;->i()Laqr;

    move-result-object v2

    iput-object v2, p0, Laqw;->c:Laqr;

    goto :goto_1

    :pswitch_3
    aget-object v2, v1, v0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Laqw;->e:I

    goto :goto_1

    :pswitch_4
    aget-object v2, v1, v0

    iput-object v2, p0, Laqw;->d:Ljava/lang/String;

    goto :goto_1

    :cond_1
    iget v0, p0, Laqw;->e:I

    if-eqz v0, :cond_2

    iget v0, p0, Laqw;->a:I

    iget v1, p0, Laqw;->e:I

    invoke-virtual {p1, v0, v1}, Laqg;->a(II)Laqr;

    move-result-object v0

    iput-object v0, p0, Laqw;->c:Laqr;

    :cond_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method


# virtual methods
.method public a(Laqg;)V
    .locals 3

    iget-object v0, p0, Laqw;->c:Laqr;

    iget v1, p0, Laqw;->a:I

    iget v2, p0, Laqw;->b:I

    invoke-virtual {p1, v0, v1, v2}, Laqg;->a(Laqr;II)V

    return-void
.end method
