.class public Lama;
.super Ljava/lang/Object;


# instance fields
.field private a:[I

.field private b:Z

.field private c:Lanb;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lanb;)V
    .locals 0

    iput-object p1, p0, Lama;->c:Lanb;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lama;->b:Z

    return-void
.end method

.method public a([I)V
    .locals 0

    iput-object p1, p0, Lama;->a:[I

    return-void
.end method

.method public a()[I
    .locals 1

    iget-object v0, p0, Lama;->a:[I

    return-object v0
.end method

.method public b()Z
    .locals 1

    iget-boolean v0, p0, Lama;->b:Z

    return v0
.end method

.method public c()Lanb;
    .locals 1

    iget-object v0, p0, Lama;->c:Lanb;

    return-object v0
.end method
