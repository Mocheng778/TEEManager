.class public Lapl;
.super Ljava/lang/Object;


# instance fields
.field private a:Lbxr;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private e:Lbxf;

.field private f:Ljava/lang/Object;

.field private g:Ljava/lang/String;

.field private h:Lajo;

.field private i:Lapn;

.field private j:Lbzg;


# direct methods
.method public constructor <init>(Lajo;Lbzg;Lapn;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "\u884c"

    iput-object v0, p0, Lapl;->b:Ljava/lang/String;

    const-string v0, "\u4fe1\u606f"

    iput-object v0, p0, Lapl;->c:Ljava/lang/String;

    const-string v0, "\u67e5\u770b"

    iput-object v0, p0, Lapl;->d:Ljava/lang/String;

    iput-object p1, p0, Lapl;->h:Lajo;

    iput-object p2, p0, Lapl;->j:Lbzg;

    iput-object p3, p0, Lapl;->i:Lapn;

    invoke-direct {p0}, Lapl;->b()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lapl;->g:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lapl;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapl;->c:Ljava/lang/String;

    return-object v0
.end method

.method private b()Ljava/lang/String;
    .locals 3

    const-string v0, ""

    iget-object v0, p0, Lapl;->h:Lajo;

    invoke-virtual {v0}, Lajo;->d()I

    move-result v0

    iget-object v1, p0, Lapl;->h:Lajo;

    invoke-virtual {v1}, Lajo;->e()I

    move-result v1

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->a()Z

    move-result v2

    if-eqz v2, :cond_5

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->c()Z

    move-result v2

    if-eqz v2, :cond_2

    if-le v0, v1, :cond_0

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u6210\u529f\u6392\u540d\u4e0a\u5347"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u6210\u529f\u6392\u540d\u4e0d\u53d8"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u6210\u529f\u6392\u540d\u4e0b\u964d"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    if-le v0, v1, :cond_3

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u5931\u8d25\u6392\u540d\u4e0a\u5347"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_3
    if-ne v0, v1, :cond_4

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u5931\u8d25\u6392\u540d\u4e0d\u53d8"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_4
    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u6311\u6218\u5931\u8d25\u6392\u540d\u4e0b\u964d"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_5
    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->c()Z

    move-result v2

    if-eqz v2, :cond_8

    if-le v0, v1, :cond_6

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u88ab\u51fb\u8d25\u6392\u540d\u4e0a\u5347"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_6
    if-ne v0, v1, :cond_7

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u88ab\u51fb\u8d25\u6392\u540d\u4e0d\u53d8"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_7
    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u88ab\u51fb\u8d25\u6392\u540d\u4e0b\u964d"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_8
    if-le v0, v1, :cond_9

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u9632\u5b88\u6210\u529f\u6392\u540d\u4e0a\u5347"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_9
    if-ne v0, v1, :cond_a

    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u9632\u5b88\u6210\u529f\u6392\u540d\u4e0d\u53d8"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0

    :cond_a
    iget-object v0, p0, Lapl;->j:Lbzg;

    const-string v1, "\u9632\u5b88\u6210\u529f\u6392\u540d\u4e0b\u964d"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${player}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->b()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${rank}"

    iget-object v2, p0, Lapl;->h:Lajo;

    invoke-virtual {v2}, Lajo;->e()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_0
.end method

.method static synthetic b(Lapl;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lapl;->g:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 1

    iget-object v0, p0, Lapl;->e:Lbxf;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapl;->e:Lbxf;

    invoke-virtual {v0}, Lbxf;->b()I

    move-result v0

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public a(II)V
    .locals 3

    iget-object v0, p0, Lapl;->e:Lbxf;

    iget-object v1, p0, Lapl;->e:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lapl;->e:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Lapl;->f:Ljava/lang/Object;

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->m()V

    :cond_0
    return-void
.end method

.method public a(Lcar;IIIIZ)V
    .locals 4

    if-eqz p6, :cond_0

    iget-object v0, p0, Lapl;->e:Lbxf;

    invoke-virtual {v0}, Lbxf;->m()V

    :goto_0
    iget-object v0, p0, Lapl;->e:Lbxf;

    iget-object v1, p0, Lapl;->e:Lbxf;

    invoke-virtual {v1}, Lbxf;->a()I

    move-result v1

    sub-int v1, p4, v1

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v1, p2

    iget-object v2, p0, Lapl;->e:Lbxf;

    invoke-virtual {v2}, Lbxf;->j()I

    move-result v2

    sub-int/2addr v1, v2

    iget-object v2, p0, Lapl;->e:Lbxf;

    invoke-virtual {v2}, Lbxf;->b()I

    move-result v2

    sub-int v2, p5, v2

    div-int/lit8 v2, v2, 0x2

    add-int/2addr v2, p3

    iget-object v3, p0, Lapl;->e:Lbxf;

    invoke-virtual {v3}, Lbxf;->k()I

    move-result v3

    sub-int/2addr v2, v3

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void

    :cond_0
    iget-object v0, p0, Lapl;->e:Lbxf;

    invoke-virtual {v0}, Lbxf;->n()V

    goto :goto_0
.end method

.method public a(Ljava/util/Hashtable;I)V
    .locals 3

    :try_start_0
    new-instance v0, Lbxr;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "arena_record_row.bin"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v2

    invoke-direct {v0, v1, p1, v2}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    iput-object v0, p0, Lapl;->a:Lbxr;

    iget-object v0, p0, Lapl;->a:Lbxr;

    invoke-static {v0, p1}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    iget-object v0, p0, Lapl;->a:Lbxr;

    iget-object v1, p0, Lapl;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Lapl;->e:Lbxf;

    iget-object v0, p0, Lapl;->e:Lbxf;

    invoke-virtual {v0, p2}, Lbxf;->e(I)V

    new-instance v1, Lapm;

    invoke-direct {v1, p0}, Lapm;-><init>(Lapl;)V

    iget-object v0, p0, Lapl;->a:Lbxr;

    iget-object v2, p0, Lapl;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public b(II)V
    .locals 3

    iget-object v0, p0, Lapl;->e:Lbxf;

    iget-object v1, p0, Lapl;->e:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Lapl;->e:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Lapl;->f:Ljava/lang/Object;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u67e5\u770b"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapl;->i:Lapn;

    iget-object v1, p0, Lapl;->h:Lajo;

    invoke-interface {v0, v1}, Lapn;->a(Lajo;)V

    :cond_0
    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lapl;->f:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->n()V

    :cond_1
    return-void
.end method
