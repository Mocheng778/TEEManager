.class public Lafy;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:[Lalt;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lafy;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafy;->a:I

    return-void
.end method

.method public a([Lalt;)V
    .locals 0

    iput-object p1, p0, Lafy;->c:[Lalt;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafy;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafy;->b:I

    return-void
.end method

.method public c()[Lalt;
    .locals 1

    iget-object v0, p0, Lafy;->c:[Lalt;

    return-object v0
.end method
