.class public Lafh;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lalh;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lalh;
    .locals 1

    iget-object v0, p0, Lafh;->a:Lalh;

    return-object v0
.end method

.method public a(Lalh;)V
    .locals 0

    iput-object p1, p0, Lafh;->a:Lalh;

    return-void
.end method
