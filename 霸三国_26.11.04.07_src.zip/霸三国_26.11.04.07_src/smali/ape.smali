.class Lape;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Lapd;


# direct methods
.method constructor <init>(Lapd;)V
    .locals 0

    iput-object p1, p0, Lape;->a:Lapd;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    const-string v0, "\u540d\u5b57"

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lape;->a:Lapd;

    invoke-static {v0}, Lapd;->a(Lapd;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    const-string v0, "\u7b49\u7ea7"

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lape;->a:Lapd;

    invoke-static {v0}, Lapd;->b(Lapd;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const-string v0, "\u56fd\u5bb6"

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lape;->a:Lapd;

    invoke-static {v0}, Lapd;->c(Lapd;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const-string v0, "\u519b\u56e2"

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lape;->a:Lapd;

    invoke-static {v0}, Lapd;->d(Lapd;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_3
    const-string v0, "\u6392\u884c"

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lape;->a:Lapd;

    invoke-static {v0}, Lapd;->e(Lapd;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_4
    const/4 v0, 0x0

    goto :goto_0
.end method
