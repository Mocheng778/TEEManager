.class public Lagv;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagv;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagv;->a:I

    return-void
.end method
