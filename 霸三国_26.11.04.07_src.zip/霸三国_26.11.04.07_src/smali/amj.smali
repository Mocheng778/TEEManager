.class public Lamj;
.super Ljava/lang/Object;


# instance fields
.field private a:Z

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:Z

.field private g:Ljava/lang/String;

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lamj;->k:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamj;->k:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamj;->c:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lamj;->a:Z

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamj;->l:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamj;->l:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamj;->d:Ljava/lang/String;

    return-void
.end method

.method public b(Z)V
    .locals 0

    iput-boolean p1, p0, Lamj;->f:Z

    return-void
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamj;->b:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamj;->g:Ljava/lang/String;

    return-void
.end method

.method public c()Z
    .locals 1

    iget-boolean v0, p0, Lamj;->a:Z

    return v0
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamj;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamj;->e:I

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamj;->d:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamj;->h:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamj;->e:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lamj;->i:I

    return-void
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lamj;->j:I

    return-void
.end method

.method public g()Z
    .locals 1

    iget-boolean v0, p0, Lamj;->f:Z

    return v0
.end method

.method public h()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamj;->g:Ljava/lang/String;

    return-object v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lamj;->h:I

    return v0
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lamj;->j:I

    return v0
.end method
