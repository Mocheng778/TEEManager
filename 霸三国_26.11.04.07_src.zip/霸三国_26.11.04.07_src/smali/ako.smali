.class public Lako;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Lakj;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lako;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lako;->a:I

    return-void
.end method

.method public a(Lakj;)V
    .locals 0

    iput-object p1, p0, Lako;->f:Lakj;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lako;->c:Ljava/lang/String;

    return-void
.end method

.method public b()Lakj;
    .locals 1

    iget-object v0, p0, Lako;->f:Lakj;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lako;->b:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lako;->d:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lako;->d:Ljava/lang/String;

    return-object v0
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lako;->e:Ljava/lang/String;

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lako;->e:Ljava/lang/String;

    return-object v0
.end method
