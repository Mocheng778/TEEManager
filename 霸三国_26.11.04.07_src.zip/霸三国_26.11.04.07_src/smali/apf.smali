.class public interface abstract Lapf;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lajn;)V
.end method
