.class public Larw;
.super Lars;


# instance fields
.field private b:Lank;

.field private c:I


# direct methods
.method public constructor <init>(ILank;[Lamz;)V
    .locals 1

    const/16 v0, 0xa

    invoke-direct {p0, v0, p3}, Lars;-><init>(I[Lamz;)V

    iput p1, p0, Larw;->c:I

    iput-object p2, p0, Larw;->b:Lank;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larw;->b:Lank;

    invoke-virtual {v0}, Lank;->c()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 3

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget v1, p0, Larw;->c:I

    invoke-virtual {p0, p1}, Larw;->c([Lakw;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lmm;->n(ILjava/lang/String;)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larw;->b:Lank;

    invoke-virtual {v0}, Lank;->b()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
