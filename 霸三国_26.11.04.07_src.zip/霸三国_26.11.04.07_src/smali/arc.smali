.class public Larc;
.super Lare;


# static fields
.field private static final c:[I


# instance fields
.field private a:[Lbyq;

.field private b:Lbyq;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x4

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Larc;->c:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x2
        0x3
        0x0
    .end array-data
.end method

.method public constructor <init>(Lbze;II[Lbyq;Lbyq;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lare;-><init>(Lbze;II)V

    iput-object p4, p0, Larc;->a:[Lbyq;

    iput-object p5, p0, Larc;->b:Lbyq;

    return-void
.end method

.method private k()I
    .locals 8

    const-wide v6, 0x4076800000000000L    # 360.0

    invoke-virtual {p0}, Larc;->h()D

    move-result-wide v0

    sget-object v2, Larc;->c:[I

    array-length v2, v2

    iget-object v3, p0, Larc;->a:[Lbyq;

    array-length v3, v3

    mul-int/2addr v2, v3

    mul-int/lit8 v2, v2, 0x2

    int-to-double v2, v2

    div-double v2, v6, v2

    iget-object v4, p0, Larc;->a:[Lbyq;

    array-length v4, v4

    sget-object v5, Larc;->c:[I

    array-length v5, v5

    mul-int/2addr v4, v5

    int-to-double v4, v4

    div-double v4, v6, v4

    add-double/2addr v0, v2

    rem-double/2addr v0, v6

    div-double/2addr v0, v4

    double-to-int v0, v0

    iget-object v1, p0, Larc;->a:[Lbyq;

    array-length v1, v1

    rem-int/2addr v0, v1

    return v0
.end method

.method private l()I
    .locals 8

    const-wide v6, 0x4076800000000000L    # 360.0

    invoke-virtual {p0}, Larc;->h()D

    move-result-wide v0

    sget-object v2, Larc;->c:[I

    array-length v2, v2

    int-to-double v2, v2

    div-double v2, v6, v2

    sget-object v4, Larc;->c:[I

    array-length v4, v4

    iget-object v5, p0, Larc;->a:[Lbyq;

    array-length v5, v5

    mul-int/2addr v4, v5

    mul-int/lit8 v4, v4, 0x2

    int-to-double v4, v4

    div-double v4, v6, v4

    add-double/2addr v0, v4

    rem-double/2addr v0, v6

    div-double/2addr v0, v2

    double-to-int v0, v0

    return v0
.end method


# virtual methods
.method protected d()Lbyq;
    .locals 2

    iget-object v0, p0, Larc;->a:[Lbyq;

    invoke-direct {p0}, Larc;->k()I

    move-result v1

    aget-object v0, v0, v1

    return-object v0
.end method

.method protected e()I
    .locals 2

    sget-object v0, Larc;->c:[I

    invoke-direct {p0}, Larc;->l()I

    move-result v1

    aget v0, v0, v1

    return v0
.end method

.method protected f()Lbyq;
    .locals 1

    iget-object v0, p0, Larc;->b:Lbyq;

    return-object v0
.end method

.method protected g()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
