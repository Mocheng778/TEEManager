.class public Lakx;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:J

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lakx;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakx;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lakx;->b:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakx;->c:Ljava/lang/String;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakx;->c:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakx;->d:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakx;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakx;->e:I

    return-void
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Lakx;->b:J

    return-wide v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lakx;->e:I

    return v0
.end method
