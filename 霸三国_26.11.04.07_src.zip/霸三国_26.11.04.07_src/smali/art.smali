.class public Lart;
.super Lars;


# instance fields
.field private b:I

.field private c:Z


# direct methods
.method public constructor <init>([Lamz;IZ)V
    .locals 1

    const/16 v0, 0xd

    invoke-direct {p0, v0, p1}, Lars;-><init>(I[Lamz;)V

    iput p2, p0, Lart;->b:I

    iput-boolean p3, p0, Lart;->c:Z

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    invoke-super {p0}, Lars;->f()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 5

    iput-object p1, p0, Lars;->a:[Lakw;

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget v1, p0, Lart;->b:I

    iget-boolean v2, p0, Lart;->c:Z

    invoke-static {}, Latt;->a()Latt;

    move-result-object v3

    invoke-virtual {v3}, Latt;->h()I

    move-result v3

    invoke-virtual {p0, p1}, Lart;->c([Lakw;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lmm;->b(IZILjava/lang/String;)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 1

    invoke-super {p0}, Lars;->c()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
