.class public Laef;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Lajt;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lajt;
    .locals 1

    iget-object v0, p0, Laef;->a:Lajt;

    return-object v0
.end method

.method public a(Lajt;)V
    .locals 0

    iput-object p1, p0, Laef;->a:Lajt;

    return-void
.end method
