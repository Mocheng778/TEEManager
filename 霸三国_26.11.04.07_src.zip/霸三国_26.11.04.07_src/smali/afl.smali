.class public Lafl;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:[Lamx;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lafl;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafl;->a:I

    return-void
.end method

.method public a([Lamx;)V
    .locals 0

    iput-object p1, p0, Lafl;->c:[Lamx;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafl;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafl;->b:I

    return-void
.end method

.method public c()[Lamx;
    .locals 1

    iget-object v0, p0, Lafl;->c:[Lamx;

    return-object v0
.end method
