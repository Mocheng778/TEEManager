.class public Lamw;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:I

.field private e:Z

.field private f:I

.field private g:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lamw;->d:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamw;->b:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lamw;->e:Z

    return-void
.end method

.method public a()Z
    .locals 1

    iget-boolean v0, p0, Lamw;->e:Z

    return v0
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamw;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamw;->a:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamw;->c:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamw;->d:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamw;->f:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamw;->a:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamw;->g:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamw;->f:I

    return v0
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamw;->g:I

    return v0
.end method

.method public g()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamw;->c:Ljava/lang/String;

    return-object v0
.end method
