.class public Larv;
.super Lars;


# instance fields
.field private b:Lanc;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>([Lamz;Lanc;)V
    .locals 2

    const/4 v0, 0x4

    invoke-direct {p0, v0, p1}, Lars;-><init>(I[Lamz;)V

    iput-object p2, p0, Larv;->b:Lanc;

    invoke-static {}, Lbuw;->a()Lbuw;

    move-result-object v0

    invoke-virtual {p2}, Lanc;->a()I

    move-result v1

    invoke-virtual {v0, v1}, Lbuw;->a(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Larv;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larv;->c:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 4

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v1}, Lakw;->x()I

    move-result v1

    invoke-virtual {p0, p1}, Larv;->c([Lakw;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Larv;->b:Lanc;

    invoke-virtual {v3}, Lanc;->c()I

    move-result v3

    invoke-virtual {v0, v1, v2, v3}, Lmm;->e(ILjava/lang/String;I)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
