.class public Lagu;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:[Lamt;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagu;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagu;->a:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagu;->b:Ljava/lang/String;

    return-void
.end method

.method public a([Lamt;)V
    .locals 0

    iput-object p1, p0, Lagu;->h:[Lamt;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagu;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagu;->d:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagu;->c:Ljava/lang/String;

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagu;->c:Ljava/lang/String;

    return-object v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lagu;->e:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lagu;->f:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lagu;->f:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lagu;->g:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lagu;->g:I

    return-void
.end method

.method public f()[Lamt;
    .locals 1

    iget-object v0, p0, Lagu;->h:[Lamt;

    return-object v0
.end method
