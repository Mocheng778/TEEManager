.class public Laoy;
.super Ljava/lang/Object;


# static fields
.field private static a:Laoy;


# instance fields
.field private b:Lcom/lszb/view/LoadingView;

.field private c:Laok;

.field private d:I

.field private e:Lapa;

.field private f:Lbol;


# direct methods
.method private constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Laoz;

    invoke-direct {v0, p0}, Laoz;-><init>(Laoy;)V

    iput-object v0, p0, Laoy;->f:Lbol;

    invoke-static {}, Lyu;->a()Lframework/server/game/IEventHandlerManager;

    move-result-object v0

    iget-object v1, p0, Laoy;->f:Lbol;

    invoke-interface {v0, v1}, Lframework/server/game/IEventHandlerManager;->addHandler(Lyv;)V

    return-void
.end method

.method static synthetic a(Laoy;I)I
    .locals 0

    iput p1, p0, Laoy;->d:I

    return p1
.end method

.method public static a()Laoy;
    .locals 1

    sget-object v0, Laoy;->a:Laoy;

    if-nez v0, :cond_0

    new-instance v0, Laoy;

    invoke-direct {v0}, Laoy;-><init>()V

    sput-object v0, Laoy;->a:Laoy;

    :cond_0
    sget-object v0, Laoy;->a:Laoy;

    return-object v0
.end method

.method static synthetic a(Laoy;Lapa;)Lapa;
    .locals 0

    iput-object p1, p0, Laoy;->e:Lapa;

    return-object p1
.end method

.method static synthetic a(Laoy;)Lcom/lszb/view/LoadingView;
    .locals 1

    iget-object v0, p0, Laoy;->b:Lcom/lszb/view/LoadingView;

    return-object v0
.end method

.method static synthetic b(Laoy;)Laok;
    .locals 1

    iget-object v0, p0, Laoy;->c:Laok;

    return-object v0
.end method

.method static synthetic c(Laoy;)Lapa;
    .locals 1

    iget-object v0, p0, Laoy;->e:Lapa;

    return-object v0
.end method


# virtual methods
.method public a(Laok;Lapa;)V
    .locals 1

    iput-object p1, p0, Laoy;->c:Laok;

    iput-object p2, p0, Laoy;->e:Lapa;

    new-instance v0, Lcom/lszb/view/LoadingView;

    invoke-direct {v0}, Lcom/lszb/view/LoadingView;-><init>()V

    iput-object v0, p0, Laoy;->b:Lcom/lszb/view/LoadingView;

    iget-object v0, p0, Laoy;->b:Lcom/lszb/view/LoadingView;

    invoke-virtual {p1, v0}, Laok;->a(Laoj;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-virtual {v0}, Lmm;->c()V

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Laoy;->d:I

    return v0
.end method
