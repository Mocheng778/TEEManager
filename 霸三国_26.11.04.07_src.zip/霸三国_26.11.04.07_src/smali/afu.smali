.class public Lafu;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:Z

.field private d:[Lalx;

.field private e:[Lals;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lafu;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafu;->b:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lafu;->a:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lafu;->c:Z

    return-void
.end method

.method public a([Lals;)V
    .locals 0

    iput-object p1, p0, Lafu;->e:[Lals;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lafu;->d:[Lalx;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lafu;->b:I

    return v0
.end method

.method public c()[Lalx;
    .locals 1

    iget-object v0, p0, Lafu;->d:[Lalx;

    return-object v0
.end method

.method public d()[Lals;
    .locals 1

    iget-object v0, p0, Lafu;->e:[Lals;

    return-object v0
.end method
