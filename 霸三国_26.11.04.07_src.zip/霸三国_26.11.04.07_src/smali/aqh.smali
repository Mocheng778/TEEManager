.class public abstract Laqh;
.super Lbyx;


# instance fields
.field private a:D

.field private b:D

.field private c:D


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lbyx;-><init>()V

    return-void
.end method

.method public static a(DDD)I
    .locals 1

    double-to-int v0, p0

    return v0
.end method

.method public static b(DDD)I
    .locals 2

    sub-double v0, p2, p4

    double-to-int v0, v0

    return v0
.end method


# virtual methods
.method public a()D
    .locals 2

    iget-wide v0, p0, Laqh;->a:D

    return-wide v0
.end method

.method public a(D)V
    .locals 6

    iput-wide p1, p0, Laqh;->a:D

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->a(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->d(I)V

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->b(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->e(I)V

    return-void
.end method

.method public b()D
    .locals 2

    iget-wide v0, p0, Laqh;->b:D

    return-wide v0
.end method

.method public b(D)V
    .locals 6

    iput-wide p1, p0, Laqh;->b:D

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->a(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->d(I)V

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->b(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->e(I)V

    return-void
.end method

.method public c()D
    .locals 2

    iget-wide v0, p0, Laqh;->c:D

    return-wide v0
.end method

.method public c(D)V
    .locals 6

    iput-wide p1, p0, Laqh;->c:D

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->a(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->d(I)V

    iget-wide v0, p0, Laqh;->a:D

    iget-wide v2, p0, Laqh;->b:D

    iget-wide v4, p0, Laqh;->c:D

    invoke-static/range {v0 .. v5}, Laqh;->b(DDD)I

    move-result v0

    invoke-virtual {p0, v0}, Laqh;->e(I)V

    return-void
.end method
