.class public Laax;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Laln;Ljava/io/DataInputStream;)V
    .locals 3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Laln;->b(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Laln;->a(Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Laln;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Laks;

    invoke-direct {v0}, Laks;-><init>()V

    invoke-static {v0, p1}, Laad;->a(Laks;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Laln;->a(Laks;)V

    :cond_1
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Lalw;

    invoke-direct {v0}, Lalw;-><init>()V

    invoke-static {v0, p1}, Labg;->a(Lalw;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Laln;->a(Lalw;)V

    :cond_2
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readLong()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Laln;->a(J)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Laju;

    invoke-direct {v0}, Laju;-><init>()V

    invoke-static {v0, p1}, Lzf;->a(Laju;Ljava/io/DataInputStream;)V

    invoke-virtual {p0, v0}, Laln;->a(Laju;)V

    :cond_3
    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Laln;->b(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v1, v0, [Lamz;

    const/4 v0, 0x0

    :goto_0
    array-length v2, v1

    if-ge v0, v2, :cond_5

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_4

    new-instance v2, Lamz;

    invoke-direct {v2}, Lamz;-><init>()V

    aput-object v2, v1, v0

    aget-object v2, v1, v0

    invoke-static {v2, p1}, Lacj;->a(Lamz;Ljava/io/DataInputStream;)V

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p0, v1}, Laln;->a([Lamz;)V

    :cond_6
    return-void
.end method
