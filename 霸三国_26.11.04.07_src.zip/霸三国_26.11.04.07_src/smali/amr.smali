.class public Lamr;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Lakj;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lamr;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamr;->a:I

    return-void
.end method

.method public a(Lakj;)V
    .locals 0

    iput-object p1, p0, Lamr;->d:Lakj;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamr;->c:Ljava/lang/String;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamr;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamr;->b:I

    return-void
.end method
