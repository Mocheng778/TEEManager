.class public Laqe;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/util/Vector;

.field private b:I

.field private c:Laqg;

.field private final d:I

.field private final e:I

.field private final f:I

.field private final g:I

.field private final h:I

.field private final i:I

.field private final j:I

.field private final k:I


# direct methods
.method public constructor <init>(Lbyr;Ljava/util/Hashtable;Ljava/lang/String;Laqg;)V
    .locals 13

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Ljava/util/Vector;

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    iput-object v1, p0, Laqe;->a:Ljava/util/Vector;

    const/4 v1, 0x1

    iput v1, p0, Laqe;->d:I

    const/4 v1, 0x2

    iput v1, p0, Laqe;->e:I

    const/4 v1, 0x3

    iput v1, p0, Laqe;->f:I

    const/4 v1, 0x4

    iput v1, p0, Laqe;->g:I

    const/4 v1, 0x5

    iput v1, p0, Laqe;->h:I

    const/4 v1, 0x6

    iput v1, p0, Laqe;->i:I

    const/4 v1, 0x7

    iput v1, p0, Laqe;->j:I

    const/16 v1, 0x8

    iput v1, p0, Laqe;->k:I

    :try_start_0
    const-string v1, "\r\n"

    move-object/from16 v0, p3

    invoke-static {v0, v1}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v1, 0x1

    move v4, v1

    :goto_0
    array-length v1, v5

    if-ge v4, v1, :cond_3

    packed-switch v4, :pswitch_data_0

    iget-object v1, p0, Laqe;->a:Ljava/util/Vector;

    new-instance v2, Laqf;

    aget-object v3, v5, v4

    move-object/from16 v0, p4

    invoke-direct {v2, v0, v3}, Laqf;-><init>(Laqg;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :cond_0
    :goto_1
    add-int/lit8 v1, v4, 0x1

    move v4, v1

    goto :goto_0

    :pswitch_0
    aget-object v1, v5, v4

    move-object/from16 v0, p4

    invoke-virtual {v0, v1}, Laqg;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    :goto_2
    return-void

    :pswitch_1
    :try_start_1
    aget-object v1, v5, v4

    move-object/from16 v0, p4

    invoke-virtual {v0, v1}, Laqg;->b(Ljava/lang/String;)V

    goto :goto_1

    :pswitch_2
    invoke-virtual/range {p4 .. p4}, Laqg;->f()Laqk;

    move-result-object v1

    aget-object v2, v5, v4

    invoke-virtual {v1, v2}, Laqk;->a(Ljava/lang/String;)V

    goto :goto_1

    :pswitch_3
    invoke-virtual/range {p4 .. p4}, Laqg;->f()Laqk;

    move-result-object v1

    aget-object v2, v5, v4

    invoke-virtual {v1, v2}, Laqk;->c(Ljava/lang/String;)V

    goto :goto_1

    :pswitch_4
    invoke-virtual/range {p4 .. p4}, Laqg;->f()Laqk;

    move-result-object v1

    aget-object v2, v5, v4

    invoke-virtual {v1, v2}, Laqk;->b(Ljava/lang/String;)V

    goto :goto_1

    :pswitch_5
    const/4 v1, 0x7

    if-ne v4, v1, :cond_1

    const/4 v1, 0x0

    move v3, v1

    :goto_3
    aget-object v1, v5, v4

    const-string v2, "!"

    invoke-static {v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v1, 0x0

    move v2, v1

    :goto_4
    array-length v1, v6

    if-ge v2, v1, :cond_0

    aget-object v1, v6, v2

    const-string v7, ":"

    invoke-static {v1, v7}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    array-length v7, v1

    const/4 v8, 0x1

    if-le v7, v8, :cond_2

    new-instance v7, Laqo;

    const/4 v8, 0x0

    aget-object v8, v1, v8

    invoke-direct {v7, v3, v8}, Laqo;-><init>(ZLjava/lang/String;)V

    const/4 v8, 0x1

    aget-object v1, v1, v8

    const-string v8, "|"

    invoke-static {v1, v8}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/4 v1, 0x0

    :goto_5
    array-length v9, v8

    if-ge v1, v9, :cond_2

    aget-object v9, v8, v1

    move-object/from16 v0, p4

    invoke-static {p1, p2, v0, v7, v9}, Laqt;->a(Lbyr;Ljava/util/Hashtable;Laqg;Laqo;Ljava/lang/String;)Laqs;

    move-result-object v9

    invoke-virtual {v7, v9}, Laqo;->a(Laqs;)V

    move-object/from16 v0, p4

    invoke-virtual {v0, v9}, Laqg;->a(Laqs;)V

    invoke-virtual/range {p4 .. p4}, Laqg;->f()Laqk;

    move-result-object v9

    invoke-virtual {v9}, Laqk;->i()Ljava/util/Vector;

    move-result-object v9

    new-instance v10, Laqi;

    invoke-virtual {v7}, Laqo;->c()Ljava/lang/String;

    move-result-object v11

    aget-object v12, v8, v1

    invoke-direct {v10, v3, v11, v12}, Laqi;-><init>(ZLjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v9, v10}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_1
    const/4 v1, 0x1

    move v3, v1

    goto :goto_3

    :cond_2
    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_4

    :pswitch_6
    aget-object v1, v5, v4

    const-string v2, ":"

    invoke-static {v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aget-object v2, v1, v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    move-object/from16 v0, p4

    invoke-virtual {v0, v2, v3}, Laqg;->a(J)V

    const/4 v2, 0x1

    aget-object v1, v1, v2

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    move-object/from16 v0, p4

    invoke-virtual {v0, v1, v2}, Laqg;->c(J)V

    goto/16 :goto_1

    :cond_3
    move-object/from16 v0, p4

    iput-object v0, p0, Laqe;->c:Laqg;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_2

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method


# virtual methods
.method public a()Z
    .locals 4

    const/4 v1, 0x0

    iget v0, p0, Laqe;->b:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Laqe;->b:I

    iget-object v0, p0, Laqe;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Laqe;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->firstElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laqf;

    iget v2, p0, Laqe;->b:I

    invoke-virtual {v0}, Laqf;->a()I

    move-result v3

    if-lt v2, v3, :cond_0

    iget-object v2, p0, Laqe;->c:Laqg;

    invoke-virtual {v0, v2}, Laqf;->a(Laqg;)V

    iget-object v2, p0, Laqe;->a:Ljava/util/Vector;

    invoke-virtual {v2, v0}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    :cond_0
    iget-object v0, p0, Laqe;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    iput v1, p0, Laqe;->b:I

    :cond_1
    move v0, v1

    :goto_0
    return v0

    :cond_2
    iget v0, p0, Laqe;->b:I

    const/16 v2, 0x3e8

    sget v3, Laoe;->a:I

    div-int/2addr v2, v3

    if-lt v0, v2, :cond_1

    const/4 v0, 0x1

    goto :goto_0
.end method
