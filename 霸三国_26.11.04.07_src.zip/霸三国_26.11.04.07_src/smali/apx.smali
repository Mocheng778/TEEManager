.class public Lapx;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/barracks/view/BarracksProduceListView;


# direct methods
.method public constructor <init>(Lcom/lszb/barracks/view/BarracksProduceListView;)V
    .locals 0

    iput-object p1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lain;)V
    .locals 3

    invoke-virtual {p1}, Lain;->a()I

    move-result v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->a(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v1

    invoke-virtual {v1}, Latv;->j()I

    move-result v1

    if-ne v0, v1, :cond_0

    invoke-virtual {p1}, Lain;->b()Lamf;

    move-result-object v0

    invoke-virtual {v0}, Lamf;->b()I

    move-result v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->b(Lcom/lszb/barracks/view/BarracksProduceListView;)Lamf;

    move-result-object v1

    invoke-virtual {v1}, Lamf;->b()I

    move-result v1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {p1}, Lain;->b()Lamf;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->a(Lcom/lszb/barracks/view/BarracksProduceListView;Lamf;)Lamf;

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->b(Lcom/lszb/barracks/view/BarracksProduceListView;)Lamf;

    move-result-object v0

    invoke-virtual {v0}, Lamf;->a()[Lame;

    move-result-object v0

    array-length v0, v0

    if-lez v0, :cond_1

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->c(Lcom/lszb/barracks/view/BarracksProduceListView;)V

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    invoke-virtual {v0}, Laok;->c()Laoj;

    move-result-object v0

    instance-of v0, v0, Lcom/lszb/view/LoadingView;

    if-nez v0, :cond_0

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/barracks/view/BarracksListView;

    iget-object v2, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarracksProduceListView;->d(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/barracks/view/BarracksListView;-><init>(Latv;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public aZ(Laej;)V
    .locals 3

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->b(Lcom/lszb/barracks/view/BarracksProduceListView;)Lamf;

    move-result-object v0

    invoke-virtual {v0}, Lamf;->a()[Lame;

    move-result-object v0

    array-length v0, v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/barracks/view/BarracksListView;

    iget-object v2, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarracksProduceListView;->e(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/barracks/view/BarracksListView;-><init>(Latv;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method

.method public bf(Laej;)V
    .locals 3

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laej;->get_ok()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->b(Lcom/lszb/barracks/view/BarracksProduceListView;)Lamf;

    move-result-object v0

    invoke-virtual {v0}, Lamf;->a()[Lame;

    move-result-object v0

    array-length v0, v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v1}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/barracks/view/BarracksListView;

    iget-object v2, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarracksProduceListView;->f(Lcom/lszb/barracks/view/BarracksProduceListView;)Latv;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/barracks/view/BarracksListView;-><init>(Latv;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :cond_0
    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    iget-object v2, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-static {v2}, Lcom/lszb/barracks/view/BarracksProduceListView;->g(Lcom/lszb/barracks/view/BarracksProduceListView;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Lapx;->a:Lcom/lszb/barracks/view/BarracksProduceListView;

    invoke-virtual {v0}, Lcom/lszb/barracks/view/BarracksProduceListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laej;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_0
.end method
