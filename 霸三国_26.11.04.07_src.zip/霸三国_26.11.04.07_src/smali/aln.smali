.class public Laln;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Laks;

.field private c:Lalw;

.field private d:Laju;

.field private e:[Lamz;

.field private f:I

.field private g:J

.field private h:J

.field private i:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Laks;
    .locals 1

    iget-object v0, p0, Laln;->b:Laks;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Laln;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Laln;->g:J

    return-void
.end method

.method public a(Laju;)V
    .locals 0

    iput-object p1, p0, Laln;->d:Laju;

    return-void
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Laln;->b:Laks;

    return-void
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Laln;->c:Lalw;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Laln;->i:Ljava/lang/String;

    return-void
.end method

.method public a([Lamz;)V
    .locals 0

    iput-object p1, p0, Laln;->e:[Lamz;

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Laln;->g:J

    return-wide v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Laln;->f:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Laln;->h:J

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laln;->i:Ljava/lang/String;

    return-object v0
.end method

.method public d()Laju;
    .locals 1

    iget-object v0, p0, Laln;->d:Laju;

    return-object v0
.end method

.method public e()[Lamz;
    .locals 1

    iget-object v0, p0, Laln;->e:[Lamz;

    return-object v0
.end method

.method public f()I
    .locals 1

    iget v0, p0, Laln;->a:I

    return v0
.end method

.method public g()I
    .locals 1

    iget v0, p0, Laln;->f:I

    return v0
.end method

.method public h()J
    .locals 2

    iget-wide v0, p0, Laln;->h:J

    return-wide v0
.end method
