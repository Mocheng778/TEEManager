.class public Lagd;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:[Lami;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagd;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagd;->a:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lagd;->b:Ljava/lang/String;

    return-void
.end method

.method public a([Lami;)V
    .locals 0

    iput-object p1, p0, Lagd;->d:[Lami;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lagd;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagd;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lagd;->c:I

    return v0
.end method

.method public d()[Lami;
    .locals 1

    iget-object v0, p0, Lagd;->d:[Lami;

    return-object v0
.end method
