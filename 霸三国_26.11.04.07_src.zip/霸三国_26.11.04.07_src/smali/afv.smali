.class public Lafv;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:I

.field private d:Lake;

.field private e:Z

.field private f:[Lake;

.field private g:[Lalx;

.field private h:[Lamx;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lafv;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lafv;->a:I

    return-void
.end method

.method public a(Lake;)V
    .locals 0

    iput-object p1, p0, Lafv;->d:Lake;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lafv;->b:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lafv;->e:Z

    return-void
.end method

.method public a([Lake;)V
    .locals 0

    iput-object p1, p0, Lafv;->f:[Lake;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lafv;->g:[Lalx;

    return-void
.end method

.method public a([Lamx;)V
    .locals 0

    iput-object p1, p0, Lafv;->h:[Lamx;

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lafv;->b:Ljava/lang/String;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafv;->c:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lafv;->c:I

    return v0
.end method

.method public d()Lake;
    .locals 1

    iget-object v0, p0, Lafv;->d:Lake;

    return-object v0
.end method

.method public e()[Lake;
    .locals 1

    iget-object v0, p0, Lafv;->f:[Lake;

    return-object v0
.end method

.method public f()[Lalx;
    .locals 1

    iget-object v0, p0, Lafv;->g:[Lalx;

    return-object v0
.end method

.method public g()[Lamx;
    .locals 1

    iget-object v0, p0, Lafv;->h:[Lamx;

    return-object v0
.end method
