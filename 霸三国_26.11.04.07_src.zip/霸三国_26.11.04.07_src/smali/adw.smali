.class public Ladw;
.super Ljava/lang/Object;

# interfaces
.implements Lads;
.implements Lframework/server/game/IResourceHandlerManager;


# static fields
.field private static a:Ladw;


# instance fields
.field private b:Ljava/util/Vector;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Ladw;->b:Ljava/util/Vector;

    return-void
.end method

.method public static a()Lframework/server/game/IResourceHandlerManager;
    .locals 1

    sget-object v0, Ladw;->a:Ladw;

    if-nez v0, :cond_0

    new-instance v0, Ladw;

    invoke-direct {v0}, Ladw;-><init>()V

    sput-object v0, Ladw;->a:Ladw;

    :cond_0
    sget-object v0, Ladw;->a:Ladw;

    return-object v0
.end method


# virtual methods
.method public a(Laej;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads;

    invoke-interface {v0, p1}, Lads;->a(Laej;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0

    :cond_0
    return-void
.end method

.method public a(Lagr;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads;

    invoke-interface {v0, p1}, Lads;->a(Lagr;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0

    :cond_0
    return-void
.end method

.method public addHandler(Lads;)V
    .locals 1

    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public removeHandler(Lads;)V
    .locals 1

    iget-object v0, p0, Ladw;->b:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    return-void
.end method
