.class public Laji;
.super Ljava/lang/Object;


# direct methods
.method public static a(I)I
    .locals 4

    int-to-double v0, p0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    div-double/2addr v0, v2

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    mul-double/2addr v0, v2

    const-wide v2, 0x40d3880000000000L    # 20000.0

    mul-double/2addr v0, v2

    double-to-int v0, v0

    return v0
.end method

.method public static a(J)J
    .locals 6

    const-wide/16 v0, 0x1

    long-to-float v2, p0

    const/high16 v3, 0x40400000    # 3.0f

    div-float v4, v2, v3

    float-to-long v2, v4

    long-to-float v5, v2

    cmpl-float v4, v4, v5

    if-lez v4, :cond_0

    add-long/2addr v2, v0

    :cond_0
    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-gtz v4, :cond_1

    :goto_0
    const-wide/16 v2, 0xa

    mul-long/2addr v0, v2

    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method

.method public static b(I)I
    .locals 1

    invoke-static {p0}, Laji;->a(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x3

    return v0
.end method

.method public static b(J)J
    .locals 6

    const-wide/16 v0, 0x1

    long-to-float v2, p0

    const/high16 v3, 0x41200000    # 10.0f

    div-float v4, v2, v3

    float-to-long v2, v4

    long-to-float v5, v2

    cmpl-float v4, v4, v5

    if-lez v4, :cond_0

    add-long/2addr v2, v0

    :cond_0
    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-gtz v4, :cond_1

    :goto_0
    const-wide/16 v2, 0x3

    mul-long/2addr v0, v2

    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method

.method public static c(I)I
    .locals 1

    mul-int/lit16 v0, p0, 0x3e8

    return v0
.end method

.method public static c(J)J
    .locals 6

    const-wide/16 v0, 0x1

    long-to-float v2, p0

    const/high16 v3, 0x41c80000    # 25.0f

    div-float v4, v2, v3

    float-to-long v2, v4

    long-to-float v5, v2

    cmpl-float v4, v4, v5

    if-lez v4, :cond_0

    add-long/2addr v2, v0

    :cond_0
    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-gtz v4, :cond_1

    :goto_0
    const-wide/16 v2, 0xa

    mul-long/2addr v0, v2

    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method

.method public static d(I)I
    .locals 1

    mul-int/lit16 v0, p0, 0x9c4

    return v0
.end method

.method public static d(J)J
    .locals 6

    const-wide/16 v0, 0x1

    long-to-float v2, p0

    const/high16 v3, 0x41200000    # 10.0f

    div-float v4, v2, v3

    float-to-long v2, v4

    long-to-float v5, v2

    cmpl-float v4, v4, v5

    if-lez v4, :cond_0

    add-long/2addr v2, v0

    :cond_0
    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-gtz v4, :cond_1

    :goto_0
    const-wide/16 v2, 0x19

    mul-long/2addr v0, v2

    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method
