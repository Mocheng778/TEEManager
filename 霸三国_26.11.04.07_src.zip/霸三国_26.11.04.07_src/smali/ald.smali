.class public Lald;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Laks;

.field private c:Lalw;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:[Lalo;

.field private g:[Lalo;

.field private h:J

.field private i:J

.field private j:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lald;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lald;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lald;->h:J

    return-void
.end method

.method public a(Laks;)V
    .locals 0

    iput-object p1, p0, Lald;->b:Laks;

    return-void
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Lald;->c:Lalw;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lald;->d:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lald;->j:Z

    return-void
.end method

.method public a([Lalo;)V
    .locals 0

    iput-object p1, p0, Lald;->f:[Lalo;

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lald;->i:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lald;->e:Ljava/lang/String;

    return-void
.end method

.method public b([Lalo;)V
    .locals 0

    iput-object p1, p0, Lald;->g:[Lalo;

    return-void
.end method

.method public b()[Lalo;
    .locals 1

    iget-object v0, p0, Lald;->f:[Lalo;

    return-object v0
.end method

.method public c()[Lalo;
    .locals 1

    iget-object v0, p0, Lald;->g:[Lalo;

    return-object v0
.end method

.method public d()J
    .locals 2

    iget-wide v0, p0, Lald;->h:J

    return-wide v0
.end method

.method public e()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lald;->d:Ljava/lang/String;

    return-object v0
.end method

.method public f()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lald;->e:Ljava/lang/String;

    return-object v0
.end method

.method public g()Z
    .locals 1

    iget-boolean v0, p0, Lald;->j:Z

    return v0
.end method
