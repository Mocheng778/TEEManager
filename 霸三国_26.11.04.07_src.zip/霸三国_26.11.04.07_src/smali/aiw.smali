.class public Laiw;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lamt;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lamt;)V
    .locals 0

    iput-object p1, p0, Laiw;->a:[Lamt;

    return-void
.end method

.method public a()[Lamt;
    .locals 1

    iget-object v0, p0, Laiw;->a:[Lamt;

    return-object v0
.end method
