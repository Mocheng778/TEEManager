.class public Lagf;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:[Lajl;

.field private i:[Lala;

.field private j:[Lalx;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagf;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagf;->a:I

    return-void
.end method

.method public a([Lajl;)V
    .locals 0

    iput-object p1, p0, Lagf;->h:[Lajl;

    return-void
.end method

.method public a([Lala;)V
    .locals 0

    iput-object p1, p0, Lagf;->i:[Lala;

    return-void
.end method

.method public a([Lalx;)V
    .locals 0

    iput-object p1, p0, Lagf;->j:[Lalx;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lagf;->b:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagf;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lagf;->c:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lagf;->c:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lagf;->d:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lagf;->d:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lagf;->e:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lagf;->e:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lagf;->f:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lagf;->f:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lagf;->g:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lagf;->g:I

    return-void
.end method

.method public h()[Lajl;
    .locals 1

    iget-object v0, p0, Lagf;->h:[Lajl;

    return-object v0
.end method

.method public i()[Lala;
    .locals 1

    iget-object v0, p0, Lagf;->i:[Lala;

    return-object v0
.end method

.method public j()[Lalx;
    .locals 1

    iget-object v0, p0, Lagf;->j:[Lalx;

    return-object v0
.end method
