.class public Laiz;
.super Ljava/lang/Object;


# instance fields
.field private a:Land;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Land;
    .locals 1

    iget-object v0, p0, Laiz;->a:Land;

    return-object v0
.end method

.method public a(Land;)V
    .locals 0

    iput-object p1, p0, Laiz;->a:Land;

    return-void
.end method
