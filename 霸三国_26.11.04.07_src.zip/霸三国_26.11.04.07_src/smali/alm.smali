.class public Lalm;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:I

.field private i:J

.field private j:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lalm;->g:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalm;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lalm;->i:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalm;->g:Ljava/lang/String;

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Lalm;->i:J

    return-wide v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lalm;->b:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lalm;->j:J

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lalm;->f:Ljava/lang/String;

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Lalm;->j:J

    return-wide v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lalm;->c:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lalm;->a:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lalm;->d:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lalm;->b:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lalm;->e:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lalm;->c:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lalm;->h:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lalm;->d:I

    return v0
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lalm;->e:I

    return v0
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lalm;->h:I

    return v0
.end method
