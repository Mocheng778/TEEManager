.class public Lajs;
.super Ljava/lang/Object;


# instance fields
.field private a:Lamy;

.field private b:Lams;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lamy;
    .locals 1

    iget-object v0, p0, Lajs;->a:Lamy;

    return-object v0
.end method

.method public a(Lams;)V
    .locals 0

    iput-object p1, p0, Lajs;->b:Lams;

    return-void
.end method

.method public a(Lamy;)V
    .locals 0

    iput-object p1, p0, Lajs;->a:Lamy;

    return-void
.end method

.method public b()Lams;
    .locals 1

    iget-object v0, p0, Lajs;->b:Lams;

    return-object v0
.end method
