.class public Larp;
.super Lars;


# instance fields
.field private b:Ljava/lang/String;

.field private c:I

.field private d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;II[Lamz;)V
    .locals 1

    const/4 v0, 0x2

    invoke-direct {p0, v0, p4}, Lars;-><init>(I[Lamz;)V

    iput p2, p0, Larp;->c:I

    iput p3, p0, Larp;->d:I

    iput-object p1, p0, Larp;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Larp;->b:Ljava/lang/String;

    return-object v0
.end method

.method public a([Lakw;)V
    .locals 5

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    iget v1, p0, Larp;->c:I

    iget v2, p0, Larp;->d:I

    const/4 v3, 0x0

    aget-object v3, p1, v3

    invoke-virtual {v3}, Lakw;->x()I

    move-result v3

    invoke-virtual {p0, p1}, Larp;->c([Lakw;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lmm;->a(IIILjava/lang/String;)V

    invoke-static {}, Lcom/lszb/GameMIDlet;->e()Lbom;

    move-result-object v0

    invoke-virtual {v0}, Lbom;->a()Lmm;

    move-result-object v0

    invoke-static {}, Latt;->a()Latt;

    move-result-object v1

    invoke-virtual {v1}, Latt;->h()I

    move-result v1

    iget v2, p0, Larp;->c:I

    iget v3, p0, Larp;->d:I

    invoke-virtual {v0, v1, v2, v3}, Lmm;->g(III)V

    return-void
.end method

.method public b([Lakw;)I
    .locals 7

    invoke-static {}, Latt;->a()Latt;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v1, p1, v1

    invoke-virtual {v1}, Lakw;->x()I

    move-result v1

    invoke-virtual {v0, v1}, Latt;->a(I)Lakr;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v2

    invoke-virtual {v2}, Laks;->i()I

    move-result v2

    invoke-virtual {v0}, Lakr;->f()Laks;

    move-result-object v0

    invoke-virtual {v0}, Laks;->j()I

    move-result v3

    iget v4, p0, Larp;->c:I

    iget v5, p0, Larp;->d:I

    move-object v0, p0

    move-object v6, p1

    invoke-virtual/range {v0 .. v6}, Larp;->a(ZIIII[Lakw;)I

    move-result v0

    return v0
.end method

.method public d()I
    .locals 1

    iget v0, p0, Larp;->c:I

    return v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Larp;->d:I

    return v0
.end method
