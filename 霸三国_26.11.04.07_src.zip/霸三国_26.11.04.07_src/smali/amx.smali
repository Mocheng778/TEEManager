.class public Lamx;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:Ljava/lang/String;

.field private m:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lamx;->l:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lamx;->k:I

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lamx;->l:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lamx;->m:Z

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamx;->j:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lamx;->j:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lamx;->a:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lamx;->g:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lamx;->b:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lamx;->a:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lamx;->c:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lamx;->b:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lamx;->d:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lamx;->c:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lamx;->e:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lamx;->d:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lamx;->h:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lamx;->e:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lamx;->i:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lamx;->f:I

    return-void
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lamx;->h:I

    return-void
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lamx;->i:I

    return-void
.end method
