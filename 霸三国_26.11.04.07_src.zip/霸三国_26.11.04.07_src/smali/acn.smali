.class public Lacn;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Land;Ljava/io/DataInputStream;)V
    .locals 3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    invoke-virtual {p0, v0}, Land;->a(I)V

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readInt()I

    move-result v0

    new-array v1, v0, [Lanc;

    const/4 v0, 0x0

    :goto_0
    array-length v2, v1

    if-ge v0, v2, :cond_1

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readBoolean()Z

    move-result v2

    if-eqz v2, :cond_0

    new-instance v2, Lanc;

    invoke-direct {v2}, Lanc;-><init>()V

    aput-object v2, v1, v0

    aget-object v2, v1, v0

    invoke-static {v2, p1}, Lacm;->a(Lanc;Ljava/io/DataInputStream;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v1}, Land;->a([Lanc;)V

    :cond_2
    return-void
.end method
