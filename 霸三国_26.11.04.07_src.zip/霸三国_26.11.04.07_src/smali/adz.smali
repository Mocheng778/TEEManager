.class public Ladz;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:Ljava/lang/String;

.field private b:J

.field private c:J

.field private d:I

.field private e:I

.field private f:Lajn;

.field private g:I

.field private h:[I

.field private i:[Ljava/lang/String;

.field private j:[Lajn;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Ladz;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Ladz;->d:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Ladz;->b:J

    return-void
.end method

.method public a(Lajn;)V
    .locals 0

    iput-object p1, p0, Ladz;->f:Lajn;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Ladz;->a:Ljava/lang/String;

    return-void
.end method

.method public a([I)V
    .locals 0

    iput-object p1, p0, Ladz;->h:[I

    return-void
.end method

.method public a([Lajn;)V
    .locals 0

    iput-object p1, p0, Ladz;->j:[Lajn;

    return-void
.end method

.method public a([Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Ladz;->i:[Ljava/lang/String;

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Ladz;->b:J

    return-wide v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Ladz;->e:I

    return-void
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Ladz;->c:J

    return-void
.end method

.method public c()J
    .locals 2

    iget-wide v0, p0, Ladz;->c:J

    return-wide v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Ladz;->g:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Ladz;->d:I

    return v0
.end method

.method public e()I
    .locals 1

    iget v0, p0, Ladz;->e:I

    return v0
.end method

.method public f()Lajn;
    .locals 1

    iget-object v0, p0, Ladz;->f:Lajn;

    return-object v0
.end method

.method public g()I
    .locals 1

    iget v0, p0, Ladz;->g:I

    return v0
.end method

.method public h()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Ladz;->i:[Ljava/lang/String;

    return-object v0
.end method

.method public i()[Lajn;
    .locals 1

    iget-object v0, p0, Ladz;->j:[Lajn;

    return-object v0
.end method
