.class public Lagm;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:[Lalw;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lagm;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lagm;->a:I

    return-void
.end method

.method public a([Lalw;)V
    .locals 0

    iput-object p1, p0, Lagm;->d:[Lalw;

    return-void
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lagm;->c:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lagm;->b:I

    return-void
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lagm;->c:I

    return-void
.end method

.method public c()[Lalw;
    .locals 1

    iget-object v0, p0, Lagm;->d:[Lalw;

    return-object v0
.end method
