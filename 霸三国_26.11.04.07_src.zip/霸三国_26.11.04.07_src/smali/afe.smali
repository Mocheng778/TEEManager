.class public Lafe;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:I

.field private b:I

.field private c:[Lalg;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lafe;->a:I

    return-void
.end method

.method public a([Lalg;)V
    .locals 0

    iput-object p1, p0, Lafe;->c:[Lalg;

    return-void
.end method

.method public a()[Lalg;
    .locals 1

    iget-object v0, p0, Lafe;->c:[Lalg;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lafe;->b:I

    return-void
.end method
