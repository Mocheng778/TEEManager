.class public Lajv;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:J

.field private c:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lajv;->a:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lajv;->a:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lajv;->b:J

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Lajv;->b:J

    return-wide v0
.end method

.method public b(J)V
    .locals 0

    iput-wide p1, p0, Lajv;->c:J

    return-void
.end method
