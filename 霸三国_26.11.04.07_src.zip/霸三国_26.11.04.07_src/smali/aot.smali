.class public Laot;
.super Ljava/lang/Object;


# static fields
.field public static a:Laor;

.field public static b:Ljava/lang/String;

.field public static c:Ljava/lang/String;

.field public static d:Laos;

.field static e:Landroid/net/ConnectivityManager;

.field public static f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x0

    sput-object v0, Laot;->a:Laor;

    sput-object v0, Laot;->b:Ljava/lang/String;

    sput-object v0, Laot;->c:Ljava/lang/String;

    sput-object v0, Laot;->d:Laos;

    sput-object v0, Laot;->e:Landroid/net/ConnectivityManager;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/DCIM/Camera/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Laot;->f:Ljava/lang/String;

    return-void
.end method
