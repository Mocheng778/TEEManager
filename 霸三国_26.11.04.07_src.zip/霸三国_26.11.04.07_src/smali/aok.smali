.class public Laok;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/util/Vector;

.field private b:Lanv;

.field private c:I

.field private d:I

.field private e:Lcas;

.field private f:I

.field private g:I

.field private h:Z

.field private i:I


# direct methods
.method public constructor <init>(IILanv;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Laok;->a:Ljava/util/Vector;

    iput p1, p0, Laok;->c:I

    iput p2, p0, Laok;->d:I

    iput-object p3, p0, Laok;->b:Lanv;

    :try_start_0
    const-string v0, "/mengban.png"

    invoke-static {v0}, Lcas;->a(Ljava/lang/String;)Lcas;

    move-result-object v0

    iput-object v0, p0, Laok;->e:Lcas;

    iget-object v0, p0, Laok;->e:Lcas;

    invoke-virtual {v0}, Lcas;->c()I

    move-result v0

    div-int v0, p1, v0

    iput v0, p0, Laok;->f:I

    iget-object v0, p0, Laok;->e:Lcas;

    invoke-virtual {v0}, Lcas;->c()I

    move-result v0

    rem-int v0, p1, v0

    if-eqz v0, :cond_0

    iget v0, p0, Laok;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Laok;->f:I

    :cond_0
    iget-object v0, p0, Laok;->e:Lcas;

    invoke-virtual {v0}, Lcas;->b()I

    move-result v0

    div-int v0, p2, v0

    iput v0, p0, Laok;->g:I

    iget-object v0, p0, Laok;->e:Lcas;

    invoke-virtual {v0}, Lcas;->b()I

    move-result v0

    rem-int v0, p2, v0

    if-eqz v0, :cond_1

    iget v0, p0, Laok;->g:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Laok;->g:I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method private b(Lcar;)V
    .locals 7

    const/4 v1, 0x0

    move v0, v1

    :goto_0
    iget v2, p0, Laok;->f:I

    if-ge v0, v2, :cond_1

    move v2, v1

    :goto_1
    iget v3, p0, Laok;->g:I

    if-ge v2, v3, :cond_0

    iget-object v3, p0, Laok;->e:Lcas;

    iget-object v4, p0, Laok;->e:Lcas;

    invoke-virtual {v4}, Lcas;->c()I

    move-result v4

    mul-int/2addr v4, v0

    iget-object v5, p0, Laok;->e:Lcas;

    invoke-virtual {v5}, Lcas;->b()I

    move-result v5

    mul-int/2addr v5, v2

    const/16 v6, 0x14

    invoke-virtual {p1, v3, v4, v5, v6}, Lcar;->a(Lcas;III)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Laok;->h:Z

    iput v0, p0, Laok;->i:I

    return-void
.end method

.method public a(I)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Laok;->b:Lanv;

    if-nez v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->b:Lanv;

    invoke-interface {v0, p1}, Lanv;->a(I)I

    move-result v1

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0, v1}, Laoj;->a(I)V

    goto :goto_0
.end method

.method public a(II)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_1
    if-ltz v1, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoi;

    invoke-interface {v0, p1, p2}, Laoi;->a_(II)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_2
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-nez v0, :cond_4

    :cond_3
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0, p1, p2}, Laoj;->b(II)V

    goto :goto_0

    :cond_4
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_1
.end method

.method public a(Laoj;)V
    .locals 2

    if-nez p1, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    if-eq p1, v0, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    :goto_1
    invoke-virtual {p1}, Laoj;->f()Z

    move-result v0

    if-eqz v0, :cond_3

    const/4 v0, 0x0

    move v1, v0

    :goto_2
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_3

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    if-eq v0, p1, :cond_3

    invoke-virtual {v0}, Laoj;->j()V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_2

    :cond_2
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto :goto_1

    :cond_3
    invoke-static {}, Ljava/lang/System;->gc()V

    iget v0, p0, Laok;->c:I

    iget v1, p0, Laok;->d:I

    invoke-virtual {p1, p0, v0, v1}, Laoj;->a(Laok;II)V

    invoke-virtual {p1}, Laoj;->i()V

    invoke-virtual {p0}, Laok;->a()V

    goto :goto_0
.end method

.method public a(Lcar;)V
    .locals 3

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    :goto_0
    return-void

    :cond_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    iget-boolean v1, p0, Laok;->h:Z

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Laoj;->h()Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_1
    const/4 v2, 0x0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    add-int/lit8 v1, v0, -0x1

    :goto_1
    if-ltz v1, :cond_7

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->f()Z

    move-result v0

    if-eqz v0, :cond_3

    move v0, v1

    :goto_2
    move v1, v0

    :goto_3
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_4

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ne v1, v2, :cond_2

    invoke-virtual {v0}, Laoj;->g()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-direct {p0, p1}, Laok;->b(Lcar;)V

    :cond_2
    invoke-virtual {v0, p1}, Laoj;->a(Lcar;)V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_3

    :cond_3
    add-int/lit8 v1, v1, -0x1

    goto :goto_1

    :cond_4
    iget v0, p0, Laok;->i:I

    const/4 v1, 0x5

    if-lt v0, v1, :cond_5

    const/4 v0, 0x1

    iput-boolean v0, p0, Laok;->h:Z

    goto :goto_0

    :cond_5
    iget v0, p0, Laok;->i:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Laok;->i:I

    goto :goto_0

    :cond_6
    invoke-virtual {v0, p1}, Laoj;->a(Lcar;)V

    goto :goto_0

    :cond_7
    move v0, v2

    goto :goto_2
.end method

.method public a(Ljava/lang/Class;)Z
    .locals 3

    const/4 v1, 0x0

    move v0, v1

    :goto_0
    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v0, v2, :cond_0

    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v2, p1, :cond_1

    const/4 v1, 0x1

    :cond_0
    return v1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0
.end method

.method public b(Ljava/lang/Class;)Laoj;
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v1, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-ne v1, p1, :cond_0

    iget-object v1, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v1, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    :goto_1
    return-object v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    goto :goto_1
.end method

.method public b()V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->j()V

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->k()V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->removeAllElements()V

    invoke-virtual {p0}, Laok;->a()V

    return-void
.end method

.method public b(I)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Laok;->b:Lanv;

    if-nez v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->b:Lanv;

    invoke-interface {v0, p1}, Lanv;->a(I)I

    move-result v1

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0, v1}, Laoj;->b(I)V

    goto :goto_0
.end method

.method public b(II)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_1
    if-ltz v1, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoi;

    invoke-interface {v0, p1, p2}, Laoi;->a_(II)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_2
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-nez v0, :cond_4

    :cond_3
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0, p1, p2}, Laoj;->c(II)V

    goto :goto_0

    :cond_4
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_1
.end method

.method public b(Laoj;)V
    .locals 3

    if-nez p1, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1}, Laoj;->j()V

    invoke-virtual {p1}, Laoj;->k()V

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    invoke-static {}, Ljava/lang/System;->gc()V

    invoke-virtual {p1}, Laoj;->f()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    move v1, v0

    :goto_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    sub-int/2addr v2, v1

    invoke-virtual {v0, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->i()V

    invoke-virtual {v0}, Laoj;->f()Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    invoke-virtual {p0}, Laok;->a()V

    goto :goto_0

    :cond_3
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1
.end method

.method public c()Laoj;
    .locals 1

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->lastElement()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    goto :goto_0
.end method

.method public c(II)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    :goto_0
    return-void

    :cond_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_1
    if-ltz v1, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-eqz v0, :cond_2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoi;

    invoke-interface {v0, p1, p2}, Laoi;->a_(II)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_2
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Laoi;

    if-nez v0, :cond_4

    :cond_3
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0, p1, p2}, Laoj;->d(II)V

    goto :goto_0

    :cond_4
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_1
.end method

.method public c(Laoj;)V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    :goto_0
    invoke-virtual {p0}, Laok;->c()Laoj;

    move-result-object v0

    if-eq v0, p1, :cond_1

    invoke-virtual {p0}, Laok;->c()Laoj;

    move-result-object v0

    invoke-virtual {p0, v0}, Laok;->b(Laoj;)V

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "WARNING---can not back to view ,because view is not in the list"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method public c(Ljava/lang/Class;)V
    .locals 3

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-nez v0, :cond_1

    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v2, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v2, p1, :cond_0

    const/4 v0, 0x1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    if-nez v0, :cond_3

    sget-object v0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v1, "WARNING---can not back to view ,because view is not in the list"

    invoke-virtual {v0, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_2
    return-void

    :cond_3
    :goto_1
    invoke-virtual {p0}, Laok;->c()Laoj;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    if-eq v0, p1, :cond_2

    invoke-virtual {p0}, Laok;->c()Laoj;

    move-result-object v0

    invoke-virtual {p0, v0}, Laok;->b(Laoj;)V

    goto :goto_1
.end method

.method public d()V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    :goto_0
    return-void

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    :goto_1
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_1

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->d_()V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Laok;->a()V

    goto :goto_0
.end method

.method public e()V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    return-void

    :cond_1
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->c_()V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0
.end method

.method public f()Z
    .locals 1

    iget-boolean v0, p0, Laok;->h:Z

    return v0
.end method

.method public g()V
    .locals 2

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-boolean v0, p0, Laok;->h:Z

    if-nez v0, :cond_1

    :cond_0
    return-void

    :cond_1
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    if-ge v1, v0, :cond_0

    iget-object v0, p0, Laok;->a:Ljava/util/Vector;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Laoj;

    invoke-virtual {v0}, Laoj;->l()V

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0
.end method
