.class public Lamf;
.super Ljava/lang/Object;


# instance fields
.field private a:[Lame;

.field private b:I

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lamf;->b:I

    return-void
.end method

.method public a(Z)V
    .locals 0

    iput-boolean p1, p0, Lamf;->c:Z

    return-void
.end method

.method public a([Lame;)V
    .locals 0

    iput-object p1, p0, Lamf;->a:[Lame;

    return-void
.end method

.method public a()[Lame;
    .locals 1

    iget-object v0, p0, Lamf;->a:[Lame;

    return-object v0
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lamf;->b:I

    return v0
.end method
