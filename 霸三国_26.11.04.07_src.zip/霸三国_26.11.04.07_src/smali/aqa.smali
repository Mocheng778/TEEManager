.class public Laqa;
.super Ljava/lang/Object;


# instance fields
.field protected a:Lbxr;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private g:Lbxf;

.field private h:Ljava/lang/Object;

.field private i:Lapz;

.field private j:I

.field private k:Lame;

.field private l:Ljava/lang/String;

.field private m:I

.field private n:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lapz;ILame;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "\u884c"

    iput-object v0, p0, Laqa;->b:Ljava/lang/String;

    const-string v0, "\u5175\u79cd"

    iput-object v0, p0, Laqa;->c:Ljava/lang/String;

    const-string v0, "\u6570\u91cf"

    iput-object v0, p0, Laqa;->d:Ljava/lang/String;

    const-string v0, "\u65f6\u95f4"

    iput-object v0, p0, Laqa;->e:Ljava/lang/String;

    const-string v0, "\u53d6\u6d88"

    iput-object v0, p0, Laqa;->f:Ljava/lang/String;

    iput-object p1, p0, Laqa;->i:Lapz;

    iput p2, p0, Laqa;->j:I

    iput-object p3, p0, Laqa;->k:Lame;

    invoke-direct {p0}, Laqa;->b()V

    return-void
.end method

.method static synthetic a(Laqa;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqa;->c:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic b(Laqa;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqa;->l:Ljava/lang/String;

    return-object v0
.end method

.method private b()V
    .locals 4

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v0

    iget-object v1, p0, Laqa;->k:Lame;

    invoke-virtual {v1}, Lame;->a()I

    move-result v1

    invoke-virtual {v0, v1}, Lapp;->c(I)Lapr;

    move-result-object v0

    invoke-virtual {v0}, Lapr;->c()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laqa;->l:Ljava/lang/String;

    iget-object v0, p0, Laqa;->k:Lame;

    invoke-virtual {v0}, Lame;->b()I

    move-result v0

    iput v0, p0, Laqa;->m:I

    iget-object v0, p0, Laqa;->k:Lame;

    invoke-virtual {v0}, Lame;->d()J

    move-result-wide v0

    iget-object v2, p0, Laqa;->k:Lame;

    invoke-virtual {v2}, Lame;->b()I

    move-result v2

    int-to-long v2, v2

    mul-long/2addr v0, v2

    const-wide/16 v2, 0x3e8

    div-long/2addr v0, v2

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    invoke-static {v0, v1}, Lbwd;->a(J)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Laqa;->n:Ljava/lang/String;

    return-void
.end method

.method static synthetic c(Laqa;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqa;->d:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic d(Laqa;)I
    .locals 1

    iget v0, p0, Laqa;->m:I

    return v0
.end method

.method static synthetic e(Laqa;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqa;->e:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic f(Laqa;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Laqa;->n:Ljava/lang/String;

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 1

    iget-object v0, p0, Laqa;->g:Lbxf;

    invoke-virtual {v0}, Lbxf;->b()I

    move-result v0

    return v0
.end method

.method public a(II)V
    .locals 3

    iget-object v0, p0, Laqa;->g:Lbxf;

    iget-object v1, p0, Laqa;->g:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Laqa;->g:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Laqa;->h:Ljava/lang/Object;

    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->m()V

    :cond_0
    return-void
.end method

.method public a(Lanx;Ljava/util/Hashtable;I)V
    .locals 3

    :try_start_0
    new-instance v0, Lbxr;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "barracks_produce_row.bin"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lbvz;->a()Lbxl;

    move-result-object v2

    invoke-direct {v0, v1, p2, v2}, Lbxr;-><init>(Ljava/lang/String;Ljava/util/Hashtable;Lbxl;)V

    iput-object v0, p0, Laqa;->a:Lbxr;

    iget-object v0, p0, Laqa;->a:Lbxr;

    invoke-static {v0, p2}, Lbvy;->a(Lbxr;Ljava/util/Hashtable;)V

    iget-object v0, p0, Laqa;->a:Lbxr;

    iget-object v1, p0, Laqa;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    iput-object v0, p0, Laqa;->g:Lbxf;

    iget-object v0, p0, Laqa;->g:Lbxf;

    invoke-virtual {v0, p3}, Lbxf;->e(I)V

    new-instance v1, Laqb;

    invoke-direct {v1, p0}, Laqb;-><init>(Laqa;)V

    iget-object v0, p0, Laqa;->a:Lbxr;

    iget-object v2, p0, Laqa;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Laqa;->a:Lbxr;

    iget-object v2, p0, Laqa;->d:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V

    iget-object v0, p0, Laqa;->a:Lbxr;

    iget-object v2, p0, Laqa;->e:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    invoke-virtual {v0, v1}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method

.method public a(Lcar;IIZ)V
    .locals 3

    if-eqz p4, :cond_0

    iget-object v0, p0, Laqa;->g:Lbxf;

    invoke-virtual {v0}, Lbxf;->m()V

    :goto_0
    iget-object v0, p0, Laqa;->g:Lbxf;

    iget-object v1, p0, Laqa;->g:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    sub-int v1, p2, v1

    iget-object v2, p0, Laqa;->g:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    sub-int v2, p3, v2

    invoke-virtual {v0, p1, v1, v2}, Lbxf;->a(Lcar;II)V

    return-void

    :cond_0
    iget-object v0, p0, Laqa;->g:Lbxf;

    invoke-virtual {v0}, Lbxf;->n()V

    goto :goto_0
.end method

.method public b(II)V
    .locals 3

    iget-object v0, p0, Laqa;->g:Lbxf;

    iget-object v1, p0, Laqa;->g:Lbxf;

    invoke-virtual {v1}, Lbxf;->j()I

    move-result v1

    neg-int v1, v1

    iget-object v2, p0, Laqa;->g:Lbxf;

    invoke-virtual {v2}, Lbxf;->k()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v0, v1, v2, p1, p2}, Lbxf;->b(IIII)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Laqa;->h:Ljava/lang/Object;

    if-eqz v1, :cond_0

    iget-object v1, p0, Laqa;->h:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->h()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u53d6\u6d88"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqa;->i:Lapz;

    iget v1, p0, Laqa;->j:I

    invoke-interface {v0, v1}, Lapz;->c(I)V

    :cond_0
    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    instance-of v0, v0, Lcom/lzlm/component/ButtonComponent;

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqa;->h:Ljava/lang/Object;

    check-cast v0, Lcom/lzlm/component/ButtonComponent;

    invoke-virtual {v0}, Lcom/lzlm/component/ButtonComponent;->n()V

    :cond_1
    return-void
.end method
