.class public Lado;
.super Ljava/lang/Object;

# interfaces
.implements Lframework/server/game/IReader;


# instance fields
.field final synthetic a:Ladg;


# direct methods
.method public constructor <init>(Ladg;)V
    .locals 0

    iput-object p1, p0, Lado;->a:Ladg;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public read(Ljava/io/DataInputStream;)V
    .locals 2

    new-instance v0, Laej;

    invoke-direct {v0}, Laej;-><init>()V

    invoke-static {v0, p1}, Lframework/server/game/ControllerResponse;->read(Lframework/server/game/ControllerResponse;Ljava/io/DataInputStream;)V

    iget-object v1, p0, Lado;->a:Ladg;

    invoke-static {v1}, Ladg;->a(Ladg;)Ladf;

    move-result-object v1

    invoke-interface {v1, v0}, Ladf;->c(Laej;)V

    return-void
.end method
