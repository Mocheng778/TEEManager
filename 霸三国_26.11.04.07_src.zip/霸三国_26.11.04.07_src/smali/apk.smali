.class public Lapk;
.super Lbol;


# instance fields
.field final synthetic a:Lcom/lszb/arena/view/ArenaRecordListView;


# direct methods
.method public constructor <init>(Lcom/lszb/arena/view/ArenaRecordListView;)V
    .locals 0

    iput-object p1, p0, Lapk;->a:Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-direct {p0}, Lbol;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Laeb;)V
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lapk;->a:Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaRecordListView;->e()Laok;

    move-result-object v0

    iget-object v1, p0, Lapk;->a:Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-virtual {v1}, Lcom/lszb/arena/view/ArenaRecordListView;->e()Laok;

    move-result-object v1

    invoke-virtual {v1}, Laok;->c()Laoj;

    move-result-object v1

    invoke-virtual {v0, v1}, Laok;->b(Laoj;)V

    invoke-virtual {p1}, Laeb;->get_ok()I

    move-result v0

    if-ne v0, v3, :cond_2

    invoke-virtual {p1}, Laeb;->a()[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Laeb;->a()[Ljava/lang/String;

    move-result-object v0

    array-length v0, v0

    if-lez v0, :cond_1

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Laeb;->a()[Ljava/lang/String;

    move-result-object v2

    array-length v2, v2

    if-ge v0, v2, :cond_0

    invoke-virtual {p1}, Laeb;->a()[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lapk;->a:Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaRecordListView;->e()Laok;

    move-result-object v0

    new-instance v2, Lcom/lszb/battle/view/BattleFieldView;

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1, v3}, Lcom/lszb/battle/view/BattleFieldView;-><init>(Ljava/lang/String;Z)V

    invoke-virtual {v0, v2}, Laok;->a(Laoj;)V

    :cond_1
    :goto_1
    return-void

    :cond_2
    iget-object v0, p0, Lapk;->a:Lcom/lszb/arena/view/ArenaRecordListView;

    invoke-virtual {v0}, Lcom/lszb/arena/view/ArenaRecordListView;->e()Laok;

    move-result-object v0

    new-instance v1, Lcom/lszb/view/InfoDialogView;

    invoke-virtual {p1}, Laeb;->get_errorMsg()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/lszb/view/InfoDialogView;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Laok;->a(Laoj;)V

    goto :goto_1
.end method
