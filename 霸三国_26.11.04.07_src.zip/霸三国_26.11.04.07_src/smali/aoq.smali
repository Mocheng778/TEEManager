.class public interface abstract Laoq;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ljava/lang/String;)I
.end method

.method public abstract a(I)Landroid/view/View;
.end method

.method public abstract a(Landroid/widget/TextView;)V
.end method

.method public abstract a(Ljava/lang/Runnable;)V
.end method

.method public abstract b()Landroid/os/Handler;
.end method
