.class public Lapt;
.super Laqc;


# instance fields
.field private final d:Ljava/lang/String;

.field private e:Lanq;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    invoke-direct {p0, p1}, Laqc;-><init>(I)V

    const-string v0, "\u63d0\u793a"

    iput-object v0, p0, Lapt;->d:Ljava/lang/String;

    invoke-static {}, Lapp;->a()Lapp;

    move-result-object v0

    invoke-virtual {v0, p1}, Lapp;->a(I)Lanq;

    move-result-object v0

    iput-object v0, p0, Lapt;->e:Lanq;

    return-void
.end method


# virtual methods
.method protected a()Ljava/lang/String;
    .locals 1

    const-string v0, "barracks_disable_row.bin"

    return-object v0
.end method

.method protected a(Lbxr;II)V
    .locals 4

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/lszb/GameMIDlet;->h()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "ui_barracks.properties"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "utf-8"

    invoke-static {v0, v1}, Lbzg;->a(Ljava/lang/String;Ljava/lang/String;)Lbzg;

    move-result-object v0

    const-string v1, "ui_barracks.\u65e0\u6cd5\u62db\u52df\u5175\u79cd\u63d0\u793a"

    invoke-virtual {v0, v1}, Lbzg;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${level}"

    iget-object v2, p0, Lapt;->e:Lanq;

    invoke-virtual {v2}, Lanq;->b()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "${building}"

    invoke-static {}, Latp;->a()Latp;

    move-result-object v2

    iget-object v3, p0, Lapt;->e:Lanq;

    invoke-virtual {v3}, Lanq;->a()I

    move-result v3

    invoke-virtual {v2, v3}, Latp;->e(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lbzp;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v0, "\u63d0\u793a"

    invoke-virtual {p1, v0}, Lbxr;->a(Ljava/lang/String;)Lbxf;

    move-result-object v0

    check-cast v0, Lcom/lzlm/component/TextComponent;

    new-instance v2, Lapu;

    invoke-direct {v2, p0, v1}, Lapu;-><init>(Lapt;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcom/lzlm/component/TextComponent;->a(Lbyi;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    goto :goto_0
.end method
