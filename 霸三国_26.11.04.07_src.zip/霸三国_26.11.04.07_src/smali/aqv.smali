.class public Laqv;
.super Ljava/lang/Object;


# direct methods
.method public static a(Laqg;ILjava/lang/String;)Laqu;
    .locals 1

    packed-switch p1, :pswitch_data_0

    const/4 v0, 0x0

    :goto_0
    return-object v0

    :pswitch_0
    new-instance v0, Laqy;

    invoke-direct {v0, p2}, Laqy;-><init>(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_1
    new-instance v0, Lara;

    invoke-direct {v0, p2}, Lara;-><init>(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_2
    new-instance v0, Laqw;

    invoke-direct {v0, p0, p2}, Laqw;-><init>(Laqg;Ljava/lang/String;)V

    goto :goto_0

    :pswitch_3
    new-instance v0, Laqx;

    invoke-direct {v0, p2}, Laqx;-><init>(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_4
    new-instance v0, Laqz;

    invoke-direct {v0, p0, p2}, Laqz;-><init>(Laqg;Ljava/lang/String;)V

    goto :goto_0

    :pswitch_5
    new-instance v0, Larb;

    invoke-direct {v0, p2}, Larb;-><init>(Ljava/lang/String;)V

    goto :goto_0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method
