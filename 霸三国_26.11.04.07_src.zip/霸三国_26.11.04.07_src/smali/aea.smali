.class public Laea;
.super Lframework/server/game/ControllerResponse;


# instance fields
.field private a:[Lanp;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lframework/server/game/ControllerResponse;-><init>()V

    return-void
.end method


# virtual methods
.method public a([Lanp;)V
    .locals 0

    iput-object p1, p0, Laea;->a:[Lanp;

    return-void
.end method

.method public a()[Lanp;
    .locals 1

    iget-object v0, p0, Laea;->a:[Lanp;

    return-object v0
.end method
