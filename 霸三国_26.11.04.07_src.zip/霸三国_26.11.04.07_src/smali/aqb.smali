.class Laqb;
.super Ljava/lang/Object;

# interfaces
.implements Lbyi;


# instance fields
.field final synthetic a:Laqa;


# direct methods
.method constructor <init>(Laqa;)V
    .locals 0

    iput-object p1, p0, Laqb;->a:Laqa;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/lzlm/component/TextComponent;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqb;->a:Laqa;

    invoke-static {v1}, Laqa;->a(Laqa;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Laqb;->a:Laqa;

    invoke-static {v0}, Laqa;->b(Laqa;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqb;->a:Laqa;

    invoke-static {v1}, Laqa;->c(Laqa;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Laqb;->a:Laqa;

    invoke-static {v0}, Laqa;->d(Laqa;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Lcom/lzlm/component/TextComponent;->h()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Laqb;->a:Laqa;

    invoke-static {v1}, Laqa;->e(Laqa;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Laqb;->a:Laqa;

    invoke-static {v0}, Laqa;->f(Laqa;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    goto :goto_0
.end method
