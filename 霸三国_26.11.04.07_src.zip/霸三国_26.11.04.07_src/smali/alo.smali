.class public Lalo;
.super Ljava/lang/Object;


# instance fields
.field private a:Lalw;

.field private b:[Lamz;

.field private c:I

.field private d:J


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 1

    iget v0, p0, Lalo;->c:I

    return v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lalo;->c:I

    return-void
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lalo;->d:J

    return-void
.end method

.method public a(Lalw;)V
    .locals 0

    iput-object p1, p0, Lalo;->a:Lalw;

    return-void
.end method

.method public a([Lamz;)V
    .locals 0

    iput-object p1, p0, Lalo;->b:[Lamz;

    return-void
.end method

.method public b()J
    .locals 2

    iget-wide v0, p0, Lalo;->d:J

    return-wide v0
.end method

.method public c()Lalw;
    .locals 1

    iget-object v0, p0, Lalo;->a:Lalw;

    return-object v0
.end method

.method public d()[Lamz;
    .locals 1

    iget-object v0, p0, Lalo;->b:[Lamz;

    return-object v0
.end method
