.class public abstract Laoj;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:Laok;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method protected a(I)V
    .locals 0

    return-void
.end method

.method a(Laok;II)V
    .locals 0

    iput-object p1, p0, Laoj;->c:Laok;

    iput p2, p0, Laoj;->a:I

    iput p3, p0, Laoj;->b:I

    invoke-virtual {p0, p2, p3}, Laoj;->e(II)V

    return-void
.end method

.method protected abstract a(Lcar;)V
.end method

.method protected b(I)V
    .locals 0

    return-void
.end method

.method protected b(II)V
    .locals 0

    return-void
.end method

.method protected c(II)V
    .locals 0

    return-void
.end method

.method protected c_()V
    .locals 0

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Laoj;->b:I

    return v0
.end method

.method public d(II)V
    .locals 0

    return-void
.end method

.method protected d_()V
    .locals 0

    return-void
.end method

.method public e()Laok;
    .locals 1

    iget-object v0, p0, Laoj;->c:Laok;

    return-object v0
.end method

.method protected abstract e(II)V
.end method

.method protected e_()I
    .locals 1

    iget v0, p0, Laoj;->a:I

    return v0
.end method

.method public f()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public g()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public h()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method protected i()V
    .locals 0

    return-void
.end method

.method protected j()V
    .locals 0

    return-void
.end method

.method protected abstract k()V
.end method

.method protected abstract l()V
.end method
