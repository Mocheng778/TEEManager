.class public interface abstract Lapz;
.super Ljava/lang/Object;


# virtual methods
.method public abstract c(I)V
.end method
