.class public Lakg;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:[Lakh;

.field private d:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 0

    iput p1, p0, Lakg;->a:I

    return-void
.end method

.method public a([Lakh;)V
    .locals 0

    iput-object p1, p0, Lakg;->c:[Lakh;

    return-void
.end method

.method public a()[Lakh;
    .locals 1

    iget-object v0, p0, Lakg;->c:[Lakh;

    return-object v0
.end method

.method public b()I
    .locals 1

    iget v0, p0, Lakg;->a:I

    return v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakg;->b:I

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakg;->b:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakg;->d:I

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lakg;->d:I

    return v0
.end method
