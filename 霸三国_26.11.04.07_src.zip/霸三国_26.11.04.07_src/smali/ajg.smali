.class public Lajg;
.super Ljava/lang/Object;


# direct methods
.method public static a(J)I
    .locals 5

    const/high16 v4, 0x41200000    # 10.0f

    long-to-float v0, p0

    float-to-double v0, v0

    const-wide/high16 v2, 0x4004000000000000L    # 2.5

    mul-double/2addr v0, v2

    const-wide/high16 v2, 0x404e000000000000L    # 60.0

    div-double/2addr v0, v2

    double-to-float v0, v0

    mul-float v1, v0, v4

    rem-float/2addr v1, v4

    float-to-int v1, v1

    const/4 v2, 0x5

    if-lt v1, v2, :cond_0

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    :cond_0
    float-to-int v0, v0

    return v0
.end method

.method public static b(J)I
    .locals 3

    const/high16 v2, 0x41200000    # 10.0f

    long-to-float v0, p0

    const/high16 v1, 0x42700000    # 60.0f

    div-float/2addr v0, v1

    mul-float v1, v0, v2

    rem-float/2addr v1, v2

    float-to-int v1, v1

    const/4 v2, 0x5

    if-lt v1, v2, :cond_0

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    :cond_0
    float-to-int v0, v0

    return v0
.end method
