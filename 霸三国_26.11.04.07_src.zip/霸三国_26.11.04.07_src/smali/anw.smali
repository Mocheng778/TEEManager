.class public abstract Lanw;
.super Ljava/lang/Object;


# instance fields
.field private a:Lanx;


# virtual methods
.method final a(Lanx;)V
    .locals 0

    iput-object p1, p0, Lanw;->a:Lanx;

    return-void
.end method

.method public abstract a(Ljava/lang/String;)V
.end method
