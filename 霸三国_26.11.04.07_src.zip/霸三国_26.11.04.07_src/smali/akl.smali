.class public Lakl;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:I

.field private k:I

.field private l:I

.field private m:Lakm;

.field private n:I

.field private o:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakl;->a:Ljava/lang/String;

    return-object v0
.end method

.method public a(I)V
    .locals 0

    iput p1, p0, Lakl;->l:I

    return-void
.end method

.method public a(Lakm;)V
    .locals 0

    iput-object p1, p0, Lakl;->m:Lakm;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakl;->a:Ljava/lang/String;

    return-void
.end method

.method public b()Lakm;
    .locals 1

    iget-object v0, p0, Lakl;->m:Lakm;

    return-object v0
.end method

.method public b(I)V
    .locals 0

    iput p1, p0, Lakl;->k:I

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakl;->h:Ljava/lang/String;

    return-void
.end method

.method public c()I
    .locals 1

    iget v0, p0, Lakl;->l:I

    return v0
.end method

.method public c(I)V
    .locals 0

    iput p1, p0, Lakl;->b:I

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lakl;->i:Ljava/lang/String;

    return-void
.end method

.method public d()I
    .locals 1

    iget v0, p0, Lakl;->b:I

    return v0
.end method

.method public d(I)V
    .locals 0

    iput p1, p0, Lakl;->j:I

    return-void
.end method

.method public e()I
    .locals 1

    iget v0, p0, Lakl;->k:I

    return v0
.end method

.method public e(I)V
    .locals 0

    iput p1, p0, Lakl;->c:I

    return-void
.end method

.method public f()I
    .locals 1

    iget v0, p0, Lakl;->c:I

    return v0
.end method

.method public f(I)V
    .locals 0

    iput p1, p0, Lakl;->d:I

    return-void
.end method

.method public g()I
    .locals 1

    iget v0, p0, Lakl;->j:I

    return v0
.end method

.method public g(I)V
    .locals 0

    iput p1, p0, Lakl;->e:I

    return-void
.end method

.method public h()I
    .locals 1

    iget v0, p0, Lakl;->d:I

    return v0
.end method

.method public h(I)V
    .locals 0

    iput p1, p0, Lakl;->f:I

    return-void
.end method

.method public i()I
    .locals 1

    iget v0, p0, Lakl;->e:I

    return v0
.end method

.method public i(I)V
    .locals 0

    iput p1, p0, Lakl;->g:I

    return-void
.end method

.method public j()I
    .locals 1

    iget v0, p0, Lakl;->f:I

    return v0
.end method

.method public j(I)V
    .locals 0

    iput p1, p0, Lakl;->n:I

    return-void
.end method

.method public k()I
    .locals 1

    iget v0, p0, Lakl;->g:I

    return v0
.end method

.method public k(I)V
    .locals 0

    iput p1, p0, Lakl;->o:I

    return-void
.end method

.method public l()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakl;->h:Ljava/lang/String;

    return-object v0
.end method

.method public m()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lakl;->i:Ljava/lang/String;

    return-object v0
.end method
