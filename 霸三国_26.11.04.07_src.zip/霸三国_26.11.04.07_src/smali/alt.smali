.class public Lalt;
.super Ljava/lang/Object;


# instance fields
.field private a:J

.field private b:Lajt;

.field private c:Lajp;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lajt;
    .locals 1

    iget-object v0, p0, Lalt;->b:Lajt;

    return-object v0
.end method

.method public a(J)V
    .locals 0

    iput-wide p1, p0, Lalt;->a:J

    return-void
.end method

.method public a(Lajp;)V
    .locals 0

    iput-object p1, p0, Lalt;->c:Lajp;

    return-void
.end method

.method public a(Lajt;)V
    .locals 0

    iput-object p1, p0, Lalt;->b:Lajt;

    return-void
.end method

.method public b()Lajp;
    .locals 1

    iget-object v0, p0, Lalt;->c:Lajp;

    return-object v0
.end method
