#!/system/bin/sh
# TEEManager 3绿密钥远程更新脚本
# 从 GitHub 仓库下载最新 keybox 并部署到生效路径

REPO_BASE="https://raw.githubusercontent.com/Mocheng778/TEEManager/main"
TMP="/data/local/tmp/teemanager_keybox.xml"
SAVE_PATH="/data/adb/TEEManager/data/adb/mochenTee/keybox.xml"
EFFECT_PATH="/data/misc/keystore/omk/keybox.xml"
STATE_DIR="/data/adb/TEEManager"
TS="$(date +%s)"
URL="${REPO_BASE}/keybox.xml?t=${TS}"

echo "正在从仓库下载3绿密钥..."
rm -f "$TMP"

# 尝试下载，带重试
success=0
for attempt in 1 2 3; do
  curl -s -L -k --connect-timeout 15 --max-time 60 \
    -H "Cache-Control: no-cache, no-store, must-revalidate" \
    -H "Pragma: no-cache" \
    -H "Expires: 0" \
    -o "$TMP" "$URL" 2>/dev/null
  if [ -f "$TMP" ] && [ -s "$TMP" ]; then
    # 验证是XML格式
    if head -1 "$TMP" | grep -q "<?xml"; then
      success=1
      break
    fi
  fi
  echo "下载尝试 $attempt 失败，重试..."
  sleep 2
done

if [ "$success" -ne 1 ]; then
  echo "❌ 密钥下载失败，请检查网络后重试"
  rm -f "$TMP"
  exit 1
fi

# 保存到用户指定路径
mkdir -p "$(dirname "$SAVE_PATH")"
cp "$TMP" "$SAVE_PATH"
chmod 0600 "$SAVE_PATH"

# 部署到生效路径（keymint 实际读取的位置）
mkdir -p "$(dirname "$EFFECT_PATH")"
cp "$TMP" "$EFFECT_PATH"
chmod 0600 "$EFFECT_PATH"
# 尝试设置正确的所有者（keystore UID，通常1017，部分机型不同）
KEYSTORE_UID=$(id -u keystore 2>/dev/null || echo 1017)
chown "${KEYSTORE_UID}:${KEYSTORE_UID}" "$EFFECT_PATH" 2>/dev/null || chown 1017:1017 "$EFFECT_PATH" 2>/dev/null

# 触发守护进程重启，使新密钥立即生效
mkdir -p "$STATE_DIR"
touch "$STATE_DIR/restart.all"

rm -f "$TMP"
echo "✅ 3绿密钥更新成功，已部署并触发重启"
echo "保存路径: $SAVE_PATH"
echo "生效路径: $EFFECT_PATH"
echo "请重启设备以完全生效"
