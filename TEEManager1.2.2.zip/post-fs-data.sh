#!/system/bin/sh
MODDIR=${0%/*}
TARGET_DIR=/data/misc/keystore/omk
LOG_DIR=$TARGET_DIR/logs
TARGET_KEYBOX=$TARGET_DIR/keybox.xml
TARGET_INJECTOR_CONFIG=$TARGET_DIR/injector.toml
STATE_DIR=/data/adb/TEEManager
REMOTE_KEYBOX="/data/adb/TEEManager/data/adb/mochenTee/keybox.xml"

# ============================================================
# 早期 BL 属性修正（双保险，与 yosteebl 配合）
# ============================================================
check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -n "$VALUE" ] && [ "$VALUE" != "$EXPECTED" ] && resetprop -n "$NAME" "$EXPECTED" 2>/dev/null
}

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "sys.oem_unlock_allowed" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.bootmode" "normal"

# ============================================================
# 动态检测 keystore UID（不同厂商/机型可能不同）
# 标准是 1017，但部分定制 ROM 可能不同
# ============================================================
KEYSTORE_UID=1017
if command -v id >/dev/null 2>&1; then
  DETECTED_UID=$(id -u keystore 2>/dev/null)
  if [ -n "$DETECTED_UID" ] && [ "$DETECTED_UID" -gt 0 ] 2>/dev/null; then
    KEYSTORE_UID=$DETECTED_UID
  fi
fi
# 备选：从 /data/misc/keystore 目录所有者推断
if [ -d /data/misc/keystore ]; then
  DIR_UID=$(stat -c '%u' /data/misc/keystore 2>/dev/null)
  if [ -n "$DIR_UID" ] && [ "$DIR_UID" -gt 0 ] 2>/dev/null; then
    KEYSTORE_UID=$DIR_UID
  fi
fi

# ============================================================
# 创建目录并设置正确权限
# ============================================================
mkdir -p "$TARGET_DIR"
chmod 0770 "$TARGET_DIR"
chown "${KEYSTORE_UID}:${KEYSTORE_UID}" "$TARGET_DIR" 2>/dev/null || chown 1017:1017 "$TARGET_DIR"

mkdir -p "$LOG_DIR"
chmod 0770 "$LOG_DIR"
chown "${KEYSTORE_UID}:${KEYSTORE_UID}" "$LOG_DIR" 2>/dev/null || chown 1017:1017 "$LOG_DIR"

mkdir -p "$STATE_DIR"
rm -f "$STATE_DIR/keymint-daemon.pid" "$STATE_DIR/injector-daemon.pid"
rm -f "$STATE_DIR/restart.keymint" "$STATE_DIR/restart.injector" "$STATE_DIR/restart.all"

# ============================================================
# 部署 keybox
# 优先级：远程更新的 keybox > 模块自带 keybox
# ============================================================
if [ -f "$REMOTE_KEYBOX" ] && [ -s "$REMOTE_KEYBOX" ]; then
  # 远程更新的 keybox 优先（用户通过 WebUI 更新的）
  cp "$REMOTE_KEYBOX" "$TARGET_KEYBOX"
elif [ ! -f "$TARGET_KEYBOX" ] && [ -f "$MODDIR/keybox.xml" ]; then
  # 首次安装：复制模块自带 keybox
  cp "$MODDIR/keybox.xml" "$TARGET_KEYBOX"
fi

if [ -f "$TARGET_KEYBOX" ]; then
  chmod 0600 "$TARGET_KEYBOX"
  chown "${KEYSTORE_UID}:${KEYSTORE_UID}" "$TARGET_KEYBOX" 2>/dev/null || chown 1017:1017 "$TARGET_KEYBOX"
fi

# ============================================================
# 部署 injector.toml
# ============================================================
if [ ! -f "$TARGET_INJECTOR_CONFIG" ] && [ -f "$MODDIR/injector.toml" ]; then
  cp "$MODDIR/injector.toml" "$TARGET_INJECTOR_CONFIG"
fi

if [ -f "$TARGET_INJECTOR_CONFIG" ]; then
  chmod 0644 "$TARGET_INJECTOR_CONFIG"
  chown "${KEYSTORE_UID}:${KEYSTORE_UID}" "$TARGET_INJECTOR_CONFIG" 2>/dev/null || chown 1017:1017 "$TARGET_INJECTOR_CONFIG"
fi

# ============================================================
# 修复 SELinux 上下文（部分机型需要）
# ============================================================
if command -v restorecon >/dev/null 2>&1; then
  restorecon -R "$TARGET_DIR" 2>/dev/null
fi
