# shellcheck disable=SC2034
SKIPUNZIP=1
SONAME="TEEManager"
SUPPORTED_ABIS="arm64 arm64-v8a"
MIN_SDK=28

if [ "$BOOTMODE" ]; then
  if [ "$KSU" ]; then
    ui_print "- Root管理器: KernelSU 系列"
    ui_print "- 兼容: KernelSU / KernelSU Next / SukiSU-Ultra / ApkeSU"
    [ -n "$KSU_KERNEL_VER_CODE" ] && ui_print "- 内核: $KSU_KERNEL_VER_CODE  ksud: $KSU_VER_CODE"
  elif [ "$MAGISK_VER_CODE" ]; then
    ui_print "- Root管理器: Magisk 系列"
    ui_print "- 兼容: Magisk / Alpha  版本: $MAGISK_VER_CODE"
  else
    ui_print "- Root管理器: 未知（尝试继续安装）"
    ui_print "- 兼容列表: Magisk / Alpha / KernelSU / KernelSU Next / SukiSU-Ultra / ApkeSU"
  fi
else
  ui_print "*********************************************************"
  ui_print "! 不支持在 Recovery 模式下安装"
  ui_print "! 请在 Magisk / KernelSU 管理器中安装"
  abort    "*********************************************************"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- Installing $SONAME $VERSION"

# 检测设备信息
BRAND=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
MODEL=$(getprop ro.product.model 2>/dev/null)
DEVICE=$(getprop ro.product.device 2>/dev/null)
ui_print "- 设备: ${BRAND} ${MODEL} (${DEVICE})"

# check architecture
support=false
for abi in $SUPPORTED_ABIS
do
  if [ "$ARCH" == "$abi" ]; then
    support=true
  fi
done
if [ "$support" == "false" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

# check android
if [ "$API" -lt $MIN_SDK ]; then
  ui_print "! Unsupported sdk: $API"
  abort "! Minimal supported sdk is $MIN_SDK"
else
  ui_print "- Device sdk: $API"
fi

ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"

extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"

ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh'      "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule'   "$MODPATH"
extract "$ZIPFILE" 'daemon'          "$MODPATH"
extract "$ZIPFILE" 'daemon-injector' "$MODPATH"
extract "$ZIPFILE" 'injector.toml'   "$MODPATH"
extract "$ZIPFILE" 'keybox.xml'      "$MODPATH"
extract "$ZIPFILE" 'action.sh'      "$MODPATH"
extract "$ZIPFILE" 'webroot/index.html' "$MODPATH"
extract "$ZIPFILE" 'webroot/script3.sh' "$MODPATH"

chmod 755 "$MODPATH/daemon" "$MODPATH/daemon-injector" \
  "$MODPATH/post-fs-data.sh" "$MODPATH/service.sh" \
  "$MODPATH/action.sh" "$MODPATH/webroot/script3.sh"

if [ "$ARCH" = "x64" ] || [ "$ARCH" = "x86_64" ]; then
  ui_print "- Using packaged x64 binaries"
  BINDIR="$MODPATH/libs/x86_64"
  extract "$ZIPFILE" 'libs/x86_64/keymint' "$MODPATH"
  extract "$ZIPFILE" 'libs/x86_64/inject'  "$MODPATH"
elif [ "$ARCH" = "arm64" ] || [ "$ARCH" = "arm64-v8a" ]; then
  ui_print "- Using packaged arm64 binaries"
  BINDIR="$MODPATH/libs/arm64-v8a"
  extract "$ZIPFILE" 'libs/arm64-v8a/keymint' "$MODPATH"
  extract "$ZIPFILE" 'libs/arm64-v8a/inject'  "$MODPATH"
else
  abort "! Unsupported platform: $ARCH"
fi

[ -f "$BINDIR/keymint" ] || abort "! Missing $BINDIR/keymint"
[ -f "$BINDIR/inject" ] || abort "! Missing $BINDIR/inject"
chmod 755 "$BINDIR/keymint" "$BINDIR/inject"

CONFIG_DIR=/data/adb/TEEManager
mkdir -p "$CONFIG_DIR"
rm -f "$CONFIG_DIR/restart.keymint" "$CONFIG_DIR/restart.injector" "$CONFIG_DIR/restart.all"
rm -f "$CONFIG_DIR/keymint" "$CONFIG_DIR/inject" "$CONFIG_DIR/injector"

if [ ! -e "$CONFIG_DIR/fpdata" ] && [ ! -L "$CONFIG_DIR/fpdata" ]; then
  ln -s /data/misc/keystore/omk "$CONFIG_DIR/fpdata"
fi

# ============================================================
# yosteebl 模块：Bootloader 属性早期修正
# 采用 post-fs-data（早期）+ service（兜底）双阶段修正
# ============================================================
ui_print "- Prepare yosteebl (post-fs-data + service dual-stage)"
YBL_DIR=/data/adb/modules/yosteebl
mkdir -p "$YBL_DIR"

cat > "$YBL_DIR/module.prop" <<'EOF'
id=yosteebl
name=yosteebl
version=1.2
versionCode=12
author=莫晨
description=Bootloader属性早期修正模块（post-fs-data双阶段修正，支持全机型）
EOF

# post-fs-data.sh：在系统服务启动前修正属性，确保 keystore/keymint 读到 locked
cat > "$YBL_DIR/post-fs-data.sh" <<'EOF'
#!/system/bin/sh
# 早期修正：keystore/keymint 启动前执行，这是最关键的阶段
check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -n "$VALUE" ] && [ "$VALUE" != "$EXPECTED" ] && resetprop -n "$NAME" "$EXPECTED" 2>/dev/null
}

# Bootloader 状态相关（核心）
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"
check_reset_prop "ro.boot.vbmeta.avb_version" "1.0"
check_reset_prop "ro.boot.vbmeta.digest" ""

# 厂商特有属性
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.boot.frp.state" "0"
check_reset_prop "sys.oem_unlock_allowed" "0"
check_reset_prop "ro.oem_unlock_supported" "0"
check_reset_prop "ro.boot.revision" "0"

# 小米/红米特有
check_reset_prop "ro.secureboot" "1"
check_reset_prop "ro.boot.securebootlock" "1"
check_reset_prop "persist.sys.oem.unlock" "0"

# 三星特有
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.boot.emmc.checksum" "1"

# Debug/安全相关
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "persist.sys.usb.config" "mtp"
check_reset_prop "sys.usb.config" "mtp"

# 构建属性
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.build.selinux" "1"
check_reset_prop "ro.bootmode" "normal"
check_reset_prop "ro.boot.bootreason" "reboot"

# 禁用 ADB（安全）
settings put global adb_enabled 0 >/dev/null 2>&1
stop adbd >/dev/null 2>&1
setprop ctl.stop adbd >/dev/null 2>&1
EOF

# service.sh：开机完成后兜底修正，防止部分服务缓存旧属性
cat > "$YBL_DIR/service.sh" <<'EOF'
#!/system/bin/sh
# 兜底修正：开机完成后再执行一次，确保所有属性最终正确
wait_for_boot() {
  local i=0
  while [ "$i" -lt 60 ]; do
    local boot=$(getprop sys.boot_completed 2>/dev/null)
    [ "$boot" = "1" ] && break
    i=$((i + 1))
    sleep 1
  done
}

check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -n "$VALUE" ] && [ "$VALUE" != "$EXPECTED" ] && resetprop -n "$NAME" "$EXPECTED" 2>/dev/null
}

wait_for_boot

# 等待额外时间确保所有服务启动完成
sleep 5

# 再次修正所有属性（与 post-fs-data 保持一致）
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "sys.oem_unlock_allowed" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.bootmode" "normal"

# 最终禁用 ADB
settings put global adb_enabled 0 >/dev/null 2>&1
stop adbd >/dev/null 2>&1
setprop ctl.stop adbd >/dev/null 2>&1
EOF

chmod 755 "$YBL_DIR/post-fs-data.sh" "$YBL_DIR/service.sh"

ui_print "- 安装完成，请重启设备"
ui_print "- TEEManager v1.2.2 by 莫晨"
