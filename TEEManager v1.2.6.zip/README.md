# TEEManager

[![Version](https://img.shields.io/badge/version-1.2.6-blue)](https://github.com/Mocheng778/TEEManager)
[![Author](https://img.shields.io/badge/author-莫晨-orange)](https://github.com/Mocheng778)
[![Android](https://img.shields.io/badge/Android-9%20~%2017-green)](https://www.android.com/)
[![Architecture](https://img.shields.io/badge/arch-arm64--v8a-red)](https://developer.android.com/ndk/guides/abis)

自定义密钥伪装安卓密钥状态并修正解锁 BL 后的异常系统属性，深度隐藏 Root 痕迹。

## 功能特性

- **密钥伪装**：完整实现 KeyMint AIDL 接口，伪造硬件密钥认证
- **BL 状态隐藏**：三阶段修正（post-fs-data 早期 + service 首次 + 后台循环持续），修复"开机5分钟后BL被检测"问题
- **全机型适配**：动态检测 keystore UID，自动修复 SELinux 上下文和目录权限
- **应用拦截**：自动拦截所有第三方应用 + 已知检测工具的密钥操作
- **WebUI 管理**：内置精美 WebUI，一键更新 3 绿密钥
- **在线更新**：支持 updateJson 在线检测更新

## 支持列表

### Root 管理器
- Magisk / Magisk Alpha
- KernelSU / KernelSU Next
- SukiSU-Ultra
- ApkeSU

### 支持机型
一加 / 真我 / OPPO / vivo / IQOO / 小米 / 红米 / 红魔 / 联想 / 魅族 / 三星 / 索尼 / 华硕 / 摩托罗拉

### 系统版本
Android 9 ~ Android 17（API 28+）

### 架构
仅支持 arm64-v8a

## 安装方法

1. 在 Magisk / KernelSU 管理器中选择安装本模块 zip
2. 安装完成后重启设备
3. 打开模块 WebUI 即可使用

## 使用说明

### 一键更新 3 绿密钥
1. 打开 TEEManager WebUI
2. 点击「一键更新3绿密钥」按钮
3. 等待下载完成，重启设备生效

> 密钥从 GitHub 仓库 `https://raw.githubusercontent.com/Mocheng778/TEEManager/main/keybox.xml` 下载

### 生成完整拦截配置
执行 `action.sh` 可自动将所有第三方应用加入拦截列表：
```sh
sh /data/adb/modules/TEEManager/action.sh
```

### 手动重启守护进程
```sh
# 重启 keymint
touch /data/adb/TEEManager/restart.keymint
# 重启 injector
touch /data/adb/TEEManager/restart.injector
# 重启全部
touch /data/adb/TEEManager/restart.all
```

### 查看 BL 属性修正日志
yosteebl 后台循环守护进程会记录每次属性被恢复并修正的日志：
```sh
cat /data/adb/TEEManager/yosteebl.log
```

## 文件结构

```
TEEManager/
├── module.prop              # 模块配置（含 updateJson）
├── TEEManager.json          # 在线更新配置
├── customize.sh             # 安装脚本（自动创建 yosteebl）
├── post-fs-data.sh          # 早期初始化（属性修正+keybox部署）
├── service.sh               # 启动守护进程
├── daemon                   # keymint 守护进程
├── daemon-injector          # injector 守护进程
├── action.sh                # 生成完整 injector 配置
├── injector.toml            # 拦截配置
├── keybox.xml               # 默认密钥
├── sepolicy.rule            # SELinux 规则
├── verify.sh                # 文件校验
├── libs/arm64-v8a/
│   ├── keymint              # KeyMint 实现二进制
│   └── inject               # keystore2 注入工具
├── webroot/
│   ├── index.html           # WebUI 单页应用
│   └── script3.sh           # 3绿密钥更新脚本
└── META-INF/                # 安装入口
```

## 运行时路径

| 路径 | 用途 |
|------|------|
| `/data/adb/modules/TEEManager/` | 模块安装目录 |
| `/data/adb/TEEManager/` | 运行状态目录 |
| `/data/adb/TEEManager/yosteebl.log` | BL 属性修正日志 |
| `/data/misc/keystore/omk/` | keystore 数据目录 |
| `/data/adb/modules/yosteebl/` | BL 属性修正模块（自动创建，含后台循环守护） |

## 工作原理

### 三阶段 BL 属性修正
1. **post-fs-data 阶段**（TEEManager + yosteebl）：系统服务启动前修正属性，确保 keystore/keymint 启动时读到 locked
2. **service 首次修正**（yosteebl）：开机完成后立即修正一次
3. **后台循环持续修正**（yosteebl）：每30秒检查一次，发现属性被系统服务恢复立即修正——修复"开机5分钟后BL被检测"问题

### 密钥伪装流程
1. post-fs-data：部署 keybox 和 injector 配置到 `/data/misc/keystore/omk/`
2. service：启动 keymint 守护进程（替换系统 KeyMint）→ 启动 injector 守护进程（注入 keystore2）
3. 运行时：所有在 scoop 列表中的应用调用密钥接口时，被注入的 hook 拦截并返回伪装结果

## 注意事项

- 本模块仅用于学习和研究目的
- 使用前请确保已备份重要数据
- 部分银行/支付应用可能有额外的检测手段，本模块不保证 100% 绕过
- 公开 keybox 可能被 Google 吊销，建议使用从未解锁设备提取的私有 keybox
- 刷入前请先卸载旧的 yosteebl 模块，安装时会自动创建新的三阶段版本

## 致谢

基于 [Oh My Keymint](https://github.com/qwq233/OhMyKeymint) 二次开发。

## License

AGPL-3.0-or-later + Oh My Keymint License
