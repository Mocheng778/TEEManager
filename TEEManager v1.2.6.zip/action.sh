#!/system/bin/sh
echo "正在生成完整 injector.toml 配置..."
DIR="/data/adb/TEEManager/fpdata"
mkdir -p "$DIR"
T="$DIR/injector.tmp"
OUT="$DIR/injector.toml"

# 已知的密钥/BL/Root 检测应用基础列表
BASE_SCOOP_RAW="io.github.vvb2060.keyattestation
io.github.qwq233.keyattestation
com.android.keyattestation
io.github.vvb2060.mahoshojo
icu.nullptr.nativetest
com.reveny.nativecheck
com.zhenxi.hunter
com.android.nativetest
io.liankong.riskdetector
luna.safe.luna
com.eltavine.duckdetector
com.scottyab.rootbeer
com.topjohnwu.magisk
io.github.huskydg.magisk
me.weishu.kernelsu
com.google.android.gsf
com.google.android.gms
com.android.vending
com.google.android.play.games
com.google.android.apps.playconsole
com.google.android.gms.policy_sidecar_aps
com.greenpoint.android.mc10086.activity
com.android.bankabc
com.eg.android.AlipayGphone
com.tencent.mm
com.tencent.mobileqq
com.unionpay
com.chinamworld.main
com.icbc
com.ccb.android
com.boc.mobile
com.abc.cmb
cmb.pb
com.cmbchina.ccd.pluto.cmbActivity
com.pingan.paces.ccms
com.spdb.mobilebank.per
com.cmbc.mobilebank
com.cebbank.mobile.ceb
com.cib.cibmb
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.sgame
com.tencent.tmgp.kgame
com.miHoYo.GenshinImpact
com.miHoYo.hkrpg
com.tencent.tmgp.cod
com.garena.game.codm
com.dts.freefireth
com.pubg.imobile
com.tencent.tmgp.speedmobile
com.tencent.tmgp.cf
com.samsung.android.fmm
com.miui.securitycenter
com.miui.securityadd
com.coloros.safecenter
com.heytap.safecenter
com.iqoo.safecenter
com.vivo.safecenter
com.oppo.safecenter"

# 获取所有第三方应用（用户安装的应用）
THIRD_PARTY=$(pm list packages -3 2>/dev/null | sed 's/^package://')

# 合并并去重
ALL_SCOOP=$(printf "%s\n%s" "$BASE_SCOOP_RAW" "$THIRD_PARTY" | sort -u | grep -v '^$')

SCOOP_COUNT=$(echo "$ALL_SCOOP" | wc -l)
echo "拦截应用数量: $SCOOP_COUNT (基础检测 + 全部第三方应用)"

cat > "$T" <<'EOF'
# TEEManager injector 配置（自动生成）
# 所有在 scoop 列表中的应用，其密钥操作都会被拦截
version = 1
scoop = [
EOF
echo "$ALL_SCOOP" | sed 's/^/  "/;s/$/",/' >> "$T"
cat >> "$T" <<'EOF'
]

[main]
enabled = true
log_level = "error"

[filter]
enabled = true
deny_packages = []
block_android_package = true
allow_unknown_package = false

[intercept]
get_security_level = true
get_key_entry = true
update_subcomponent = true
list_entries = true
delete_key = true
grant = true
ungrant = true
get_number_of_entries = true
list_entries_batched = true
get_supplementary_attestation_info = true
EOF

mv "$T" "$OUT"
chmod 644 "$OUT"
chown system:system "$OUT" 2>/dev/null || chown 1000:1000 "$OUT"

# 触发注入器重启使配置生效
mkdir -p /data/adb/TEEManager
touch /data/adb/TEEManager/restart.injector

echo "✅ injector.toml 完整配置生成成功：$OUT"
echo "✅ 已触发注入器重启，新配置立即生效"
